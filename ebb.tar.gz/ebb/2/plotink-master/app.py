import sys
sys.path.insert(1, '/plotink')
import ebb_serial