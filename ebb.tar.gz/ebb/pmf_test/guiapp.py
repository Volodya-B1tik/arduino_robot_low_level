# -*- coding: utf-8 -*-
"""
Created on Mon Nov 20 12:26:48 2017

@author: gubatenko
"""

from __future__ import print_function

import Tkinter as tk
import rs
import serial
import pmf_test as pt

def set_mode_extended():
    global ser
    rs.set_mode(ser, u'расширенный')

def brightness_max():
    global ser
    rs.set_brit(ser, 0xFE)

def brightness_min():
    global ser
    rs.set_brit(ser, 0x00)

def sts_description():
    global ser
    log = pt.logger_init()
    pt.sts_decription(ser, log)


with serial.Serial('COM16', baudrate=9600) as ser:
    w = tk.Tk()
    mode_button = tk.Button(w)
    mode_button['text'] = 'EXTENDED MODE'
    mode_button['command'] = set_mode_extended
    mode_button.pack()
    
    brt_max_button = tk.Button(w)
    brt_max_button['text'] = 'BRIGHTNESS MAX'
    brt_max_button['command'] = brightness_max
    brt_max_button.pack()
    
    brt_min_button = tk.Button(w)
    brt_min_button['text'] = 'BRIGHTNESS MIN'
    brt_min_button['command'] = brightness_min
    brt_min_button.pack()
    
    test_button = tk.Button(w)
    test_button['text'] = 'RUN TEST'
    test_button['command'] = sts_description
    test_button.pack()
    w.mainloop()    
