# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 22:02:55 2017

@author: User
"""

from test import *

def temperature_reading(ser):
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    rs.set_heater(ser, [0x00, 0x01])
    clear_all_q()
    while 1:
        rs.req_sts(ser)
        time.sleep(2)
        sts = rx_specific_packet('STS_PMF', '232')        
        tmp_ts_raw = sts[24]
        tmp_mi_raw = sts[25] + ((sts[26] << 7) & 0x80)
        if (tmp_ts_raw & 0x80) == 0x80:
            tmp_ts = tmp_ts_raw - 256
        else:
            tmp_ts = tmp_ts_raw
        if (tmp_mi_raw & 0x80) == 0x80:
            tmp_mi = tmp_mi_raw - 256
        else:
            tmp_mi = tmp_mi_raw
        print('ts = %s  mi = %s' % (tmp_ts, tmp_mi))



def pmf32_set_pwrcodes(ser, glass_resistance, pmin, pmax, ton, toff, time_pmax):

    Vmax = 19.85
    R = glass_resistance
    Pmin = pmin
    Pmax = pmax
    T_ON = ton
    T_OFF = toff
    
    assert (T_ON < T_OFF), 'temperature limits are wrong'
    assert (0 <= time_pmax <= 254), 'time pmax is wrong'

    t_on_hex = T_ON & 0xff
    t_off_hex = T_OFF & 0xff
        
    #print(t_on_hex, t_off_hex)
        
    t_on_hex_U8b_2B_l = t_on_hex & 0x7F
    t_on_hex_U8b_2B_h = (t_on_hex & 0x80) >> 7
    
    t_off_hex_U8b_2B_l = t_off_hex & 0x7F
    t_off_hex_U8b_2B_h = (t_off_hex & 0x80) >> 7
        
    code_min = int(((math.sqrt(Pmin * R) / Vmax) * 100 - 50) * (126 / 50) + 1)
    code_max = int(((math.sqrt(Pmax * R) / Vmax) * 100 - 50) * (126 / 50) + 1)

    #print(code_min, code_max)

    # защита от переполнения    
    if code_min > 127: code_min = 127
    if code_max > 127: code_max = 127

    # защита от недопустимых значений
    if code_min < 1: 
        code_min = 0
        print('CODE_MIN = 0')
    if code_max < 1:
        code_max = 0
        print('CODE_MAX = 0')
        
    data = [code_min, code_max, code_max, code_min, t_off_hex_U8b_2B_l,
            t_off_hex_U8b_2B_h, t_on_hex_U8b_2B_l,
            t_on_hex_U8b_2B_h, time_pmax]

    rs.set_pwrcodes(ser,data)
    

def pmf32_set_btnbrt(ser, context_btn_brt, on_btn_brt):
    assert (0 <= context_btn_brt <= 0xfe), 'context buttons brightness is wrong'
    assert (0 <= on_btn_brt <= 0xfe), 'power on button brightness is wrong'
    data = [context_btn_brt, on_btn_brt, 0, 0]
    rs.set_btnbrt(ser, data)


def simulation_heater(ser):
    dt = 0.25
    def set_t(ser):
        time.sleep(1)
        while temp_run:        
            t = t_sim & 0xFF
            t_low = t & 0x7F
            t_high = (t & 0x80) >> 7
            data = [0xFE, 0xFE, t_low, t_high]
            rs.set_btnbrt(ser, data)
            time.sleep(0.5)

    while 1:    
        
        print(u'Выберите тест')
        print(u'1  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=10c')
        print(u'2  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=10c')
        print(u'3  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MAX; HENA=0; Pmaxtime=10c')
        print(u'4  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MIN; HENA=0; Pmaxtime=10c')
        print(u'5  - Т=-5..+1..-5; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'6  - Т=-5..+1..-5; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'7  - Т=+5..-2..+5; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'8  - Т=+5..-4..+5; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'9  - Т=+127..-64; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'10 - Т=+127..-64; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'12 - Т=-2..0..-2; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'13 - Т=-10; t_on=-3>>-15; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'14 - Т=0; t_on=-3>>5; t_off=0>>10; U2U1=MAX; HENA=1; Pmaxtime=600c')        
        print(u'15 - Т=-50; t_on=-3; t_off=0; U2U1=MAX>>MIN>>MAX; HENA=1; Pmaxtime=10c')        
        
        test_n = int(raw_input('>>'))
        
        temp_run = True
        t_sim = 0
        tmp_th = threading.Thread(name='ttt', target=set_t, args=(ser,))
        tmp_th.start()        
        
        if test_n == 1:
            rs.set_heater(ser,[0x01, 0x01])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127): 
                t_sim = t
                time.sleep(dt)

        elif test_n == 2:
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
        elif test_n == 3:
            rs.set_heater(ser,[0x01, 0x00])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
        elif test_n == 4:
            rs.set_heater(ser,[0x00, 0x00])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
        elif test_n == 5:
            rs.set_heater(ser,[0x01, 0x01])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(-5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(1, -5, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)                
        elif test_n == 6:
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(-5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(1, -5, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)            
        elif test_n == 7:
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(5, -2, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(-2, 5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)            
        elif test_n == 8:
            print(u'8  - Т=+5..-4..+5; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(5, -5, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(-4, 5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)            
        elif test_n == 9:
            print(u'9  - Т=+127..-64; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(127, -65, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            
        elif test_n == 10:
            pass
        elif test_n == 11:
            pass
        elif test_n == 12:
            pass
        elif test_n == 13:
            print(u'13 - Т=-10; t_on=-3>>-15; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)        
            set_t(ser, 0xFE, 0xFE, -10)
            rs.set_heater(ser,[0x01, 0x01])
            raw_input('heater must be max for 10s then min')
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=20, pmax=40, ton=-15, toff=0, time_pmax=1)
            raw_input('heater must be off')
            
        elif test_n == 14:
            print(u'14 - Т=0; t_on=-3>>5; t_off=0>>10; U2U1=MAX; HENA=1; Pmaxtime=10c') 
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=20, pmax=40, ton=-3, toff=0, time_pmax=1)        
            set_t(ser, 0xFE, 0xFE, 0)
            rs.set_heater(ser,[0x01, 0x01])
            raw_input('heater must be off')
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=5, toff=10, time_pmax=1)
            raw_input('heater must be max for 10s then min')
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            raw_input('heater must be off')
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=5, toff=10, time_pmax=1)
            raw_input('heater must be max for 10s then min')
            
        elif test_n == 15:
            print(u'15 - Т=-50; t_on=-3; t_off=0; U2U1=MAX>>MIN>>MAX; HENA=1; Pmaxtime=600c') 
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)        
            set_t(ser, 0xFE, 0xFE, -50)
            rs.set_heater(ser,[0x01, 0x01])
            raw_input('heater must be max for 600s')
            rs.set_heater(ser,[0x00, 0x01])
            raw_input('heater must be min')
            rs.set_heater(ser,[0x02, 0x01])
            raw_input('heater must be max for 600s')            
            rs.set_heater(ser,[0x03, 0x01])
            raw_input('heater must be min')
            rs.set_heater(ser,[0x01, 0x01])
            raw_input('heater must be max for 600s')
            rs.set_heater(ser,[0x00, 0x01])
            raw_input('heater must be min')
            rs.set_heater(ser,[0x02, 0x01])
            raw_input('heater must be max for 600s')            
            rs.set_heater(ser,[0x03, 0x01])
            raw_input('heater must be min')
            
        elif test_n == 16:
            #1
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=2)        
            rs.set_heater(ser,[0x00, 0x00])
            t_sim = -50
            raw_input('heater must be off')
            rs.set_heater(ser,[0x00, 0x01])
            raw_input('heater must be min')
            rs.set_heater(ser,[0x00, 0x00])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x01, 0x01])            
            raw_input('heater must be max 10 sec then min')
            rs.set_heater(ser,[0x00, 0x00])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x02, 0x01])            
            raw_input('heater must be max 10 sec then min')
            rs.set_heater(ser,[0x00, 0x00])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x03, 0x01])            
            raw_input('heater must be min')
            rs.set_heater(ser,[0x00, 0x00])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x01, 0x00])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x02, 0x00])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x03, 0x00])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x00, 0x00])
            raw_input('heater must be off')
            t_sim = 50
            raw_input('heater must be off')
            t_sim = -1
            raw_input('heater must be off')
            t_sim = -50
            raw_input('heater must be off')
            rs.set_heater(ser,[0x01, 0x01])
            time.sleep(3)
            rs.set_heater(ser,[0x00, 0x01])
            raw_input('heater must be min')
            rs.set_heater(ser,[0x00, 0x00])
            rs.set_heater(ser,[0x01, 0x01])
            time.sleep(5)
            rs.set_heater(ser,[0x00, 0x01])
            time.sleep(5)
            rs.set_heater(ser,[0x01, 0x01])
            time.sleep(5)
            rs.set_heater(ser,[0x00, 0x01])
            time.sleep(5)
            rs.set_heater(ser,[0x01, 0x01])
            time.sleep(5)
            rs.set_heater(ser,[0x00, 0x01])
            time.sleep(5)
            rs.set_heater(ser,[0x01, 0x01])
            raw_input('heater must be max 10 sec then min')
        elif test_n == 17:
            #2
            pmf32_set_pwrcodes(ser, glass_resistance=4.315, pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)        
            set_t(ser, 0xFE, 0xFE, 0)
            rs.set_heater(ser,[0x00, 0x01])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x01, 0x01])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x02, 0x01])
            raw_input('heater must be off')
            rs.set_heater(ser,[0x03, 0x01])
            raw_input('heater must be off')
        else:
            pass
        temp_run = False
        

def off_by_cmd(ser):
    Tuderj_vykl = 3
    rs.set_off_mode(ser, Tuderj_vykl)
    
    Toff = 5
    data = [Toff, 0x55, Toff, 0xE7]
    rs.cmd_off_timeout(ser, data)    
    
    pack = rx_specific_packet('RECEIPT_OFF', '232')
    if pack[4] == Toff:
        print(u' выключаемся через %s секунд' % pack[4]) 


def off_by_button_hold(ser):
    Tuderj_vykl = 5
    rs.set_off_mode(ser, Tuderj_vykl)
