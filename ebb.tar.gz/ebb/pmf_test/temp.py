for fr in xrange(10):
    print ' \n'
    for ln in xrange(1024):
        print (ln+fr)%1024,
    