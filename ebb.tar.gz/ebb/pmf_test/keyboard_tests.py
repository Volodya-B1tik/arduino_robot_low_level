# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 22:05:29 2017

@author: User
"""

from test import *
from var import *
import logging
import rs
# =============================================================================
# Тесты атомарные
# =============================================================================
def key_test(ser, one_point=True):
    """Тест клавиатуры \n
    Отображает анимацию нажатия клавиш и считает количество нажатий для \
каждой клавиши. Анализ нажатия ведется независимо для всех каналов: \
RS-232, RS-422, CAN.\n
    Тест содержит два субтеста: \

    1) проверка в режиме "одна клавиша" \

    2) проверка в режиме "все клавиши" \n
    Тестирование продолжается пока пользователь не нажмет на все клавиши\
не менее 3-х раз.\n
    Тест не принимает решение о работоспособности клавиатуры и \
не возвращает количество ошибок.
"""
    log = logging.getLogger(__name__)
#    rs.set_mode(ser, u'технологический')
    PRESS_REQ_TO_STOP = 3

    def key_get(key_out):
        return key_out[4]

    def key_out_get(key_out):
        return (key_out[5] << 7) + key_out[4]

    class button():
        def __init__(self, x0, y0, width, height, color, txt, interface):
            self.pressed_cnt = 0
            self.isPressed = False
            self.time_last_press = 0
            self.time_release = 0.1 #0.15
            self.x = x0
            self.y = y0
            self.dx = width
            self.dy = height
            self.color = color
            self.pressed_color = cGreen
            self.txt = txt
            self.txt_size = 16
            self.screen_sizeX = 1024
            self.screen_sizeY = 768
            self.vx = 0
            self.vy = 0
            self.exist = False
            self.interface = interface

        def make(self):
            self.btn = gr.Rectangle(gr.Point(self.x, self.y),
                                    gr.Point(self.x + self.dx,
                                             self.y + self.dy))
            self.btn.setFill(self.color)
            self.btn_txt = gr.Text(gr.Point(self.x + int(self.dx / 2),
                                            self.y + int(self.dy / 2)),
                                   self.txt)
            self.btn_txt.setSize(self.txt_size)
            self.btn.draw(window)
            self.btn_txt.draw(window)
            self.exist = True

        def pressed(self):
            self.pressed_cnt += 1
            self.btn_txt.setText(self.txt + '\n%s' % str(self.pressed_cnt))
            self.isPressed = True
            self.btn.setFill(self.pressed_color)
            self.time_last_press = time.clock()
            self.shakeitbaby()

        def shakeitbaby(self):
            pass
            self.btn.move(0, -5)
            #time.sleep(0.025)
            time.sleep(0.005)
            self.btn.move(0, 8)
            time.sleep(0.005)
            self.btn.move(0, -3)

        def release(self):
            self.btn.setFill(self.color)
            self.isPressed = False

        def moveto(self, x, y):
            self.btn_txt.move(x - self.x, y - self.y)
            self.btn.move(x - self.x, y - self.y)
            self.x = x
            self.y = y

        def move(self, dx, dy):
            self.btn_txt.move(dx, dy)
            self.btn.move(dx, dy)
            self.x = self.x + dx
            self.y = self.y + dy
            if self.x > self.screen_sizeX or self.y > self.screen_sizeY:
                self.erase()
                self.exist = False

        def update(self):
            if self.isPressed is True:
                if time.clock() > self.time_last_press + self.time_release:
                    self.release()

        def erase(self):
            self.btn_txt.undraw()
            self.btn.undraw()

    window = gr.GraphWin("PMF-6.0 Key test", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    if one_point:
        log.info(u'тест клавиатуры часть 1')
        tt = gr.Text(gr.Point(511, 60), u'Проверка кнопок в режиме \
"одна кнопка" \n нажми кнопки F1-F5, K1-K5 \n не менее 3-х раз')
        tt.draw(window)
        tt.setTextColor(cWhite)
        tt.setSize(16)
    else:
        log.info(u'тест клавиатуры часть 2')
        tt = gr.Text(gr.Point(511, 60), u'Проверка кнопок в режиме \
"все кнопки" \n нажми кнопки F1-F5, K1-K5 \n не менее 3-х раз \n \
нажимай несколько кнопок одновременно')
        tt.draw(window)
        tt.setTextColor(cWhite)
        tt.setSize(16)

    # tmr = gr.Text(gr.Point(511, 150), u'60')
    # tmr.draw(window)
    # tmr.setTextColor(cYellow)
    # tmr.setSize(36)

    tt = gr.Text(gr.Point(40, 15), u'RS-232')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(107, 15), u'RS-422')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(174, 15), u'CAN')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(1024 - 40, 15), u'RS-232')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(1024 - 107, 15), u'RS-422')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(1024 - 174, 15), u'CAN')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    spx = 8
    x0 = spx
    y0 = 30
    dy = 150
    sp = 4
    size_x = 60
    size_y = 60
    # RS-232 BUTTONS
    b_232 = {}
    for i in xrange(0x21, 0x26):
        b_232[i] = button(x0, y0, size_x, size_y, cWhite, 'F%s' % (i - 0x20),
                          'RS-232')
        b_232[i].make()
        y0 += dy + sp

    x0 = 1023 - spx - size_x
    y0 = 30

    for i in xrange(0x26, 0x2B):
        b_232[i] = button(x0, y0, size_x, size_y, cWhite, 'K%s' % (i - 0x25),
                          'RS-232')
        b_232[i].make()
        y0 += dy + sp

    # RS-422 BUTTONS
    x0 = spx * 2 + size_x
    y0 = 30
    dy = 150
    sp = 4

    b_422 = {}
    for i in xrange(0x21, 0x26):
        b_422[i] = button(x0, y0, size_x, size_y, cWhite, 'F%s' % (i - 0x20),
                          'RS-422')
        b_422[i].make()
        y0 += dy + sp

    x0 = 1023 - size_x * 2 - spx * 2
    y0 = 30

    b_422 = {}
    for i in xrange(0x26, 0x2B):
        b_422[i] = button(x0, y0, size_x, size_y, cWhite, 'K%s' % (i - 0x25),
                          'RS-422')
        b_422[i].make()
        y0 += dy + sp

    # CAN BUTTONS
    x0 = spx * 3 + size_x * 2
    y0 = 30
    dy = 150
    sp = 4

    b_can = {}
    for i in xrange(0x21, 0x26):
        b_can[i] = button(x0, y0, size_x, size_y, cGrey, 'F%s' % (i - 0x20),
                          'CAN')
        b_can[i].make()
        y0 += dy + sp

    x0 = 1023 - size_x * 3 - spx * 3
    y0 = 30

    b_can = {}
    for i in xrange(0x26, 0x2B):
        b_can[i] = button(x0, y0, size_x, size_y, cGrey, 'K%s' % (i - 0x25),
                          'CAN')
        b_can[i].make()
        y0 += dy + sp

#    start_time = time.clock()
#    while (time.clock() < start_time + TEST_TIME) and not test_stop:
#        tmr.setText(str(int(round(TEST_TIME - (time.clock() - start_time)))))

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        for b in b_232: b_232[b].update()
        for b in b_422: b_422[b].update()

        if one_point is True:
            if rs232_key_out_q:
                key = key_get(rs232_key_out_q.popleft())
                try:
                    b_232[key].pressed()
                except Exception as e:
                    print(u'ошибка 232: %s' % str(e))

            if rs422_key_out_q:
                key = key_get(rs422_key_out_q.popleft())
                try:
                    b_422[key].pressed()
                except Exception as e:
                    print(u'ошибка 422: %s' % str(e))

            if can_key_out_q:
                key = key_get(can_key_out_q.popleft())
                try:
                    b_can[key].pressed()
                except Exception as e:
                    print(u'ошибка can: %s' % str(e))
        else:
            if rs232_key_set_out_q:
                key = key_out_get(rs232_key_set_out_q.popleft())
                try:
                    if key & 0x0001 > 0: b_232[0x21].pressed()
                    if key & 0x0002 > 0: b_232[0x22].pressed()
                    if key & 0x0004 > 0: b_232[0x23].pressed()
                    if key & 0x0008 > 0: b_232[0x24].pressed()
                    if key & 0x0010 > 0: b_232[0x25].pressed()
                    if key & 0x0020 > 0: b_232[0x26].pressed()
                    if key & 0x0040 > 0: b_232[0x27].pressed()
                    if key & 0x0080 > 0: b_232[0x28].pressed()
                    if key & 0x0100 > 0: b_232[0x29].pressed()
                    if key & 0x0200 > 0: b_232[0x2A].pressed()
                except Exception as e:
                    print(u'ошибка 232 key_set_out: %s' % str(e))

        if ((b_232[0x21].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x22].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x23].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x24].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x25].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x26].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x27].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x28].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x29].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x2A].pressed_cnt >= PRESS_REQ_TO_STOP)):
            break

    window.close()
