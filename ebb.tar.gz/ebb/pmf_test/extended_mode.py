# -*- coding: utf-8 -*-
"""
Created on Thu Jul 14 14:07:52 2016

@author: gubatenko
"""

def main():
    pass


if __name__ == "__main__":
    main()