# -*- coding: utf-8 -*-
"""
Created on Tue Feb 21 21:04:29 2017

@author: User
"""

from test import *

#class QtHandler(logging.Handler):
#    def __init__(self):
#        logging.Handler.__init__(self)
#    def emit(self, record):
#        record = self.format(record)
#        if record: XStream.stdout().write('%s\n' % record)
#
#handler = QtHandler()
#handler.setFormatter(formatter)
#log.addHandler(handler)
#
#class XStream(QtCore.QObject):
#    _stdout = None
#    _stderr = None
#    messageWritten = QtCore.pyqtSignal(str)
#    def flush(self):
#        pass
#    def fileno(self):
#        return -1
#    def write(self, msg):
#        if (not self.signalsBlocked()):
#            self.messageWritten.emit(unicode(msg))
#    @staticmethod
#    def stdout():
#        if (not XStream._stdout):
#            XStream._stdout = XStream()
#            sys.stdout = XStream._stdout
#        return XStream._stdout
#    @staticmethod
#    def stderr():
#        if (not XStream._stderr):
#            XStream._stderr = XStream()
#            sys.stderr = XStream._stderr
#        return XStream._stderr


def run_gui(ser):
    def run_tests():
        global test_stop
        global test_next
        if (ui.ch_t1.isChecked() or ui.ch_t2.isChecked() or
            ui.ch_t3.isChecked() or ui.ch_t4.isChecked() or
            ui.ch_t5.isChecked() or ui.ch_t6.isChecked() or
            ui.ch_t7.isChecked() or ui.ch_t8.isChecked() or
            ui.ch_t9.isChecked() or ui.ch_t10.isChecked() or
            ui.ch_t11.isChecked() or ui.ch_t12.isChecked() or
            ui.ch_t13.isChecked() or ui.ch_t14.isChecked() or
            ui.ch_t15.isChecked() or ui.ch_t16.isChecked() or
            ui.ch_t15.isChecked() or ui.ch_t16.isChecked() or
            ui.ch_t17.isChecked() or ui.ch_t18.isChecked() or
            ui.ch_t19.isChecked() or ui.ch_t20.isChecked() or
            ui.ch_t21.isChecked() or ui.ch_t22.isChecked() or
            ui.ch_t23.isChecked() or ui.ch_t24.isChecked() or
            ui.ch_t25.isChecked() or ui.ch_t26.isChecked() or
            ui.ch_t27.isChecked() or ui.ch_t28.isChecked()):
            ui.btn_start.setEnabled(False)
            ui.btn_stop.setEnabled(True)
            ui.btn_skip.setEnabled(True)
            test_stop = False
            rs232_sts_out_q.clear()
            if ui.ch_t1.isChecked():
                if test_stop is False:
                    rs.set_key_mode(ser, u'одна кнопка')
                    key_test(one_point=True)
                    test_next = False
                    rs.set_key_mode(ser, u'все кнопки')
                    key_test(one_point=False)
                    rs.set_key_mode(ser, u'одна кнопка')
                    test_next = False
            if ui.ch_t2.isChecked():
                if test_stop is False:
                    #chk18_random_flood_rs232(ser)
                    coord_resolution_slide()
                    test_next = False
            if ui.ch_t3.isChecked():
                if test_stop is False:
                    coord_zone()
                    test_next = False
            if ui.ch_t4.isChecked():
                if test_stop is False:
                    coord_delay_test()
                    test_next = False
            if ui.ch_t5.isChecked():
                if test_stop is False:
                    coord_drawer_232()
                    test_next = False
            if ui.ch_t6.isChecked():
                if test_stop is False:
                    response_time_move()
                    test_next = False
            if ui.ch_t7.isChecked():
                if test_stop is False:
                    response_time_blink(ser)
                    test_next = False
            if ui.ch_t8.isChecked():
                if test_stop is False:
                    picture_set()
                    test_next = False
            if ui.ch_t9.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t10.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t11.isChecked():
                if test_stop is False:
                    chk04_vga_resolution()
                    test_next = False
            if ui.ch_t12.isChecked():
                if test_stop is False:
                    chk00_start_time(ser, timeout=5)
                    test_next = False
            if ui.ch_t13.isChecked():
                if test_stop is False:
                    chk01_set_mode(ser)
                    test_next = False
            if ui.ch_t14.isChecked():
                if test_stop is False:
                    chk02_stats(ser)
                    test_next = False
            if ui.ch_t15.isChecked():
                if test_stop is False:
                    chk03_runtime(ser, 5, 1)
                    test_next = False
            if ui.ch_t16.isChecked():
                if test_stop is False:
                    chk05_toprosa(ser)
                    test_next = False
            if ui.ch_t17.isChecked():
                if test_stop is False:
                    chk06_brightness(ser)
                    test_next = False
            if ui.ch_t18.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t19.isChecked():
                if test_stop is False:
                    chk08_splashscreen(ser)
                    test_next = False
            if ui.ch_t20.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t21.isChecked():
                if test_stop is False:
                    chk10_save_settings()
                    test_next = False
            if ui.ch_t22.isChecked():
                if test_stop is False:
                    chk12_videoswitch()
                    test_next = False
            if ui.ch_t23.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t24.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t25.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t26.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t27.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t28.isChecked():
                if test_stop is False:
                    chk17_corrupted_packets(ser)
                    test_next = False

            test_stop = False
            ui.btn_start.setEnabled(True)
            ui.btn_stop.setEnabled(False)
            ui.btn_skip.setEnabled(False)

    def stop_test():
        global test_stop
        test_stop = True

    def next_test():
        global test_next
        test_next = True

    des1 = key_test.__doc__.decode(encoding='utf-8')
    des2 = coord_resolution_slide.__doc__.decode(encoding='utf-8')
    des3 = coord_zone.__doc__.decode(encoding='utf-8')
    des4 = coord_delay_test.__doc__.decode(encoding='utf-8')
    des5 = coord_drawer_232.__doc__.decode(encoding='utf-8')
    des6 = response_time_move.__doc__.decode(encoding='utf-8')
    des7 = response_time_blink.__doc__.decode(encoding='utf-8')
    des8 = picture_set.__doc__.decode(encoding='utf-8')
    des9 = u'x'
    des10 = u'x'
    des11 = u'x'
    des12 = chk00_start_time.__doc__.decode(encoding='utf-8')
    des13 = chk01_set_mode.__doc__.decode(encoding='utf-8')
    des14 = chk02_stats.__doc__.decode(encoding='utf-8')
    des15 = chk03_runtime.__doc__.decode(encoding='utf-8')
    des16 = chk05_toprosa.__doc__.decode(encoding='utf-8')
    des17 = chk06_brightness.__doc__.decode(encoding='utf-8')
    des18 = chk07_power_consumption.__doc__.decode(encoding='utf-8')
    des19 = chk08_splashscreen.__doc__.decode(encoding='utf-8')
    des20 = chk09_default.__doc__.decode(encoding='utf-8')
    des21 = chk10_save_settings.__doc__.decode(encoding='utf-8')
    des22 = chk12_videoswitch.__doc__.decode(encoding='utf-8')
    des23 = u'x'
    des24 = u'x'
    des25 = u'x'
    des26 = u'x'
    des27 = u'x'
    des28 = u'x'

    def descr_t1(): ui.plainTextEdit.setPlainText(des1)
    def descr_t2(): ui.plainTextEdit.setPlainText(des2)
    def descr_t3(): ui.plainTextEdit.setPlainText(des3)
    def descr_t4(): ui.plainTextEdit.setPlainText(des4)
    def descr_t5(): ui.plainTextEdit.setPlainText(des5)
    def descr_t6(): ui.plainTextEdit.setPlainText(des6)
    def descr_t7(): ui.plainTextEdit.setPlainText(des7)
    def descr_t8(): ui.plainTextEdit.setPlainText(des8)
    def descr_t9(): ui.plainTextEdit.setPlainText(des9)
    def descr_t10(): ui.plainTextEdit.setPlainText(des10)
    def descr_t11(): ui.plainTextEdit.setPlainText(des11)
    def descr_t12(): ui.plainTextEdit.setPlainText(des12)
    def descr_t13(): ui.plainTextEdit.setPlainText(des13)
    def descr_t14(): ui.plainTextEdit.setPlainText(des14)
    def descr_t15(): ui.plainTextEdit.setPlainText(des15)
    def descr_t16(): ui.plainTextEdit.setPlainText(des16)
    def descr_t17(): ui.plainTextEdit.setPlainText(des17)
    def descr_t18(): ui.plainTextEdit.setPlainText(des18)
    def descr_t19(): ui.plainTextEdit.setPlainText(des19)
    def descr_t20(): ui.plainTextEdit.setPlainText(des20)
    def descr_t21(): ui.plainTextEdit.setPlainText(des21)
    def descr_t22(): ui.plainTextEdit.setPlainText(des22)
    def descr_t23(): ui.plainTextEdit.setPlainText(des23)
    def descr_t24(): ui.plainTextEdit.setPlainText(des24)
    def descr_t25(): ui.plainTextEdit.setPlainText(des25)
    def descr_t26(): ui.plainTextEdit.setPlainText(des26)
    def descr_t27(): ui.plainTextEdit.setPlainText(des27)
    def descr_t28(): ui.plainTextEdit.setPlainText(des28)

    def fade_up():
        for i in xrange(50):
            MainWindow.setWindowOpacity(i / 50)
            time.sleep(0.001)

    def scroll():
        ui.textBrowser.moveCursor(QtGui.QTextCursor.End)

    def kill():
        global run
        print('last word')
        run = False
        for i in xrange(50, 0, -1):
            MainWindow.setWindowOpacity(i / 50)
            time.sleep(0.001)

    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = gui.Ui_MainWindow()
    ui.setupUi(MainWindow)

    #XStream.stdout().messageWritten.connect(ui.textBrowser.insertPlainText)
    #XStream.stderr().messageWritten.connect(ui.textBrowser.insertPlainText)

    QtCore.QObject.connect(ui.btn_start, QtCore.SIGNAL("clicked()"), run_tests)
    QtCore.QObject.connect(ui.btn_stop, QtCore.SIGNAL("clicked()"), stop_test)
    QtCore.QObject.connect(ui.btn_skip, QtCore.SIGNAL("clicked()"), next_test)
    QtCore.QObject.connect(ui.textBrowser, QtCore.SIGNAL("textChanged()"),
                           scroll)
    QtCore.QObject.connect(ui.centralwidget, QtCore.SIGNAL("closeEmitApp()"), kill)

    ui.btn_stop.setEnabled(False)
    ui.btn_skip.setEnabled(False)

    QtCore.QObject.connect(ui.ch_t1, QtCore.SIGNAL("clicked()"), descr_t1)
    QtCore.QObject.connect(ui.ch_t2, QtCore.SIGNAL("clicked()"), descr_t2)
    QtCore.QObject.connect(ui.ch_t3, QtCore.SIGNAL("clicked()"), descr_t3)
    QtCore.QObject.connect(ui.ch_t4, QtCore.SIGNAL("clicked()"), descr_t4)
    QtCore.QObject.connect(ui.ch_t5, QtCore.SIGNAL("clicked()"), descr_t5)
    QtCore.QObject.connect(ui.ch_t6, QtCore.SIGNAL("clicked()"), descr_t6)
    QtCore.QObject.connect(ui.ch_t7, QtCore.SIGNAL("clicked()"), descr_t7)
    QtCore.QObject.connect(ui.ch_t8, QtCore.SIGNAL("clicked()"), descr_t8)
    QtCore.QObject.connect(ui.ch_t9, QtCore.SIGNAL("clicked()"), descr_t9)
    QtCore.QObject.connect(ui.ch_t10, QtCore.SIGNAL("clicked()"), descr_t10)
    QtCore.QObject.connect(ui.ch_t11, QtCore.SIGNAL("clicked()"), descr_t11)
    QtCore.QObject.connect(ui.ch_t12, QtCore.SIGNAL("clicked()"), descr_t12)
    QtCore.QObject.connect(ui.ch_t13, QtCore.SIGNAL("clicked()"), descr_t13)
    QtCore.QObject.connect(ui.ch_t14, QtCore.SIGNAL("clicked()"), descr_t14)
    QtCore.QObject.connect(ui.ch_t15, QtCore.SIGNAL("clicked()"), descr_t15)
    QtCore.QObject.connect(ui.ch_t16, QtCore.SIGNAL("clicked()"), descr_t16)
    QtCore.QObject.connect(ui.ch_t17, QtCore.SIGNAL("clicked()"), descr_t17)
    QtCore.QObject.connect(ui.ch_t18, QtCore.SIGNAL("clicked()"), descr_t18)
    QtCore.QObject.connect(ui.ch_t19, QtCore.SIGNAL("clicked()"), descr_t19)
    QtCore.QObject.connect(ui.ch_t20, QtCore.SIGNAL("clicked()"), descr_t20)
    QtCore.QObject.connect(ui.ch_t21, QtCore.SIGNAL("clicked()"), descr_t21)
    QtCore.QObject.connect(ui.ch_t22, QtCore.SIGNAL("clicked()"), descr_t22)
    QtCore.QObject.connect(ui.ch_t23, QtCore.SIGNAL("clicked()"), descr_t23)
    QtCore.QObject.connect(ui.ch_t24, QtCore.SIGNAL("clicked()"), descr_t24)
    QtCore.QObject.connect(ui.ch_t25, QtCore.SIGNAL("clicked()"), descr_t25)
    QtCore.QObject.connect(ui.ch_t26, QtCore.SIGNAL("clicked()"), descr_t26)
    QtCore.QObject.connect(ui.ch_t27, QtCore.SIGNAL("clicked()"), descr_t27)
    QtCore.QObject.connect(ui.ch_t28, QtCore.SIGNAL("clicked()"), descr_t28)

    MainWindow.setWindowOpacity(0)
    MainWindow.show()
    MainWindow.setFixedSize(866, 500)
    fade_up()

    app.exec_()