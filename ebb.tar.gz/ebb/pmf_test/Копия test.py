# -*- coding: utf-8 -*-
"""
Created on Thu Mar 10 20:28:12 2016

@author: gubatenko
Набор тестов для проверки ПМФ-6.0
"""

# TODO проверить что тесты независимы от предыдущего состояния ПМФ,
# чтобы можно было запускать их в произвольном порядке
from __future__ import division, print_function

from PyQt4 import QtCore, QtGui

import serial
import rs
import psh
import vga
import time
import logging
import sys
import getcomports
import graphics as gr
import collections as coll
import binascii
import threading
import gui
import random
import math


COM_RS232 = 'COM1'
COM_RS422 = 'COM1'
PMF_ID = 0x10
PMF_SN = [48, 48, 48, 50, 0, 0, 0, 0, 0]
PACKET_TTL = 1
MAX_VAL = 1
delay_sts_readback = 0.08
limiter = u'_________________________________________________________________________________'

# очереди входных каналов для развязки потоков
mbx_232 = coll.deque()
mbx_422 = coll.deque()
mbx_can = coll.deque()
mbx_mdc = coll.deque()

# очереди пакетов (наполняются функцией inq_switch)
rs232_old_q = coll.deque()
old_xy = coll.deque()
rs232_coord_out_q = coll.deque()
rs232_key_out_q = coll.deque()
rs232_key_set_out_q = coll.deque()
rs232_sts_out_q = coll.deque()
rs232_sts_pmf_q = coll.deque()
rs232_sts_vpipe_q = coll.deque()
rs232_sts_vpr1_q = coll.deque()
rs232_sts_vpr2_q = coll.deque()
rs232_sts_vpr3_q = coll.deque()
rs232_sts_vpr4_q = coll.deque()
rs232_sts_vglv_q = coll.deque()
rs232_sts_eth1_q = coll.deque()
rs232_sts_eth2_q = coll.deque()
rs232_sts_ovhp_q = coll.deque()
rs232_key_off_clicked_q = coll.deque()
rs232_receipt_off_q = coll.deque()

rs422_coord_out_q = coll.deque()
rs422_key_out_q = coll.deque()
rs422_key_set_out_q = coll.deque()
rs422_sts_out_q = coll.deque()
rs422_sts_pmf_q = coll.deque()
rs422_sts_vpipe_q = coll.deque()
rs422_sts_vpr1_q = coll.deque()
rs422_sts_vpr2_q = coll.deque()
rs422_sts_vpr3_q = coll.deque()
rs422_sts_vpr4_q = coll.deque()
rs422_sts_vglv_q = coll.deque()
rs422_sts_eth1_q = coll.deque()
rs422_sts_eth2_q = coll.deque()
rs422_sts_ovhp_q = coll.deque()

can_coord_out_q = coll.deque()
can_key_out_q = coll.deque()

# константы с которыми сравниваем выдаваемые ПМФ значения
# TODO сдеать их подгружаемыми из *.ini файла
exp_pmf_id = 0x10
exp_soft_id = [2, 0, 0, 0, 0]
exp_hard_id = [1, 0, 0, 0, 0]
exp_serial_id = [48, 48, 48, 49, 0, 0, 0, 0, 0]
exp_temp_MD = [10, 40]
exp_temp_MI = [10, 50]

# цвета
cBlack = gr.color_rgb(0, 0, 0)
cGrey = gr.color_rgb(80, 80, 80)
cRed = gr.color_rgb(255, 0, 0)
cBlue = gr.color_rgb(0, 0, 255)
cWhite = gr.color_rgb(255, 255, 255)
cGreen = gr.color_rgb(0, 255, 0)
cYellow = gr.color_rgb(255, 255, 0)
cCian = gr.color_rgb(0, 255, 255)
rsdot_pressed_color = gr.color_rgb(0, 0, 255)
mdcdot_pressed_color = gr.color_rgb(0, 255, 0)
mdcdot_released_color = gr.color_rgb(255, 0, 0)
rsdot_released_color = gr.color_rgb(255, 255, 255)
# параметры заводских настроек
defaults = {
    'mode': 0x00,
    'key_mode': 0x00,
    'gainR': 0x80,
    'gainG': 0x80,
    'gainB': 0x80,
    'offsetR': 0x40,
    'offsetG': 0x40,
    'offsetB': 0x40,
    'phase': 0x50,
    'offsetH': 0x00,
    'offsetV': 0x00,
    'brightness': 0xFE,
    'vidparam': 0xFE,
    'vidinterface': 0xFE,
    'topros': 0x0A,
    'tavtopovtor': 0x06}

# создаем логгер в консоль и файл


log = logging.getLogger()
log.setLevel(logging.DEBUG)
consoleHandler = logging.StreamHandler(sys.stdout)
consoleHandler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s %(name)-6s %(levelname)-6s '
                              '%(message)s', datefmt='%H:%M:%S')
consoleHandler.setFormatter(formatter)
log.addHandler(consoleHandler)
fileHandler = logging.FileHandler('test.log', mode='w')
fileHandler.setFormatter(formatter)
log.addHandler(fileHandler)

class QtHandler(logging.Handler):
    def __init__(self):
        logging.Handler.__init__(self)
    def emit(self, record):
        record = self.format(record)
        if record: XStream.stdout().write('%s\n' % record)

handler = QtHandler()
handler.setFormatter(formatter)
log.addHandler(handler)

class XStream(QtCore.QObject):
    _stdout = None
    _stderr = None
    messageWritten = QtCore.pyqtSignal(str)
    def flush(self):
        pass
    def fileno(self):
        return -1
    def write(self, msg):
        if (not self.signalsBlocked()):
            self.messageWritten.emit(unicode(msg))
    @staticmethod
    def stdout():
        if (not XStream._stdout):
            XStream._stdout = XStream()
            sys.stdout = XStream._stdout
        return XStream._stdout
    @staticmethod
    def stderr():
        if (not XStream._stderr):
            XStream._stderr = XStream()
            sys.stderr = XStream._stderr
        return XStream._stderr


run = True  # переменная для остановки потоков перед выходом
test_stop = False  # принудительная остановка текущего теста
test_next = False  # переход к следующему тесту


# =============================================================================
# Сервисные функции
# =============================================================================
def inq(ser, mbx):
    """ Качалка данных из входного буфера COM-порта в FIFO-канала.
    Выполняется бесконечно, должна запускаться в отдельном потоке.
    1) ser - [serial.Serial] COM-порт с которого будем читать
    2) mbx - [collections.deque] FIFO-канала в которую будем писать
    """
    while run:
        if ser.inWaiting() > 0:
            dat = ser.read(ser.inWaiting())
            chunk = coll.deque([int(binascii.hexlify(dat[i]), 16)
                                for i in xrange(len(dat))])
            while True:
                try:
                    mbx.append(chunk.popleft())
                except IndexError:
                    break


def inq_switch(mbx, channel):
    """ Разбиралка FIFO-канала на несколько FIFO с однотипными пакетами.
    Выполняется бесконечно, должна запускаться в отдельном потоке.
    1) mbx - [collections.deque] FIFO-канала из которой будем доставать
             данные, из них лепить пакеты и складывать каждый пакет в
             свою очередь:
             ххх_coord_out_q   - очередь пакетов координат (COORD_OUT)
             ххх_key_out_q     - очередь пакетов нажатых клавиш (KEY_OUT)
             ххх_sts_out_q     - очередь пакетов статуса (STS_OUT)
             ххх_sts_pmf_q     - очередь пакетов статуса (STS_PMF)
             ххх_key_set_out_q - очередь пакетов нажатых клавиш (KEY_SET_OUT)
             , где ххх - название канала (rs232, rs422, can)
             у всех пакетов в этих очередях следующие отличия от протокола:
             а) вместо FF FF в начале каждого пакета идет FF FF FF
             это сделано чтобы индексы слов пакетов совпали с номерами
             слов в протоколе ИЛВ;
             б) последнее слово (контрольная сумма) отброшена, т.к. уже
             проверена на этапе приема пакета и чтобы количество байт в
             пакете не поменялось из-за добавленного FF в начале.
    2) channel - [str] канал которому соответствует очередь
                 ('232', '422', 'CAN')
    """

    ff1 = False
    ff2 = False
    rx_cnt = 0
    packet_in_progress = False
    packet = coll.deque()
    while run:
        if mbx:
            rx_byte = mbx.popleft()
            #rs232_old_q.append(rx_byte)
            if not packet_in_progress:
                if ff1 is False and rx_byte == 0xFF:
                    ff1 = True
                    rx_cnt = 1
                elif ff1 is True and ff2 is False and rx_byte == 0xFF:
                    ff2 = True
                    rx_cnt += 1
                elif ff1 is True and ff2 is False and rx_byte != 0xFF:
                    ff1 = False
                elif ff1 is True and ff2 is True:
                    if rx_byte != 0xFF:
                        rx_cnt += 1
                        packet_id = rs.decode_packet_id(rx_byte)
                        if packet_id != '':
                            packet.append(rx_byte)
                            packet_in_progress = True
                            packet_start_time = time.clock()
                        else:
                            ff1, ff2 = False, False
            else:
                packet.append(rx_byte)
                #print(rx_byte)
                rx_cnt += 1
                if rx_cnt == rs.packet_size[packet_id]:
                    if True: #rs.packet_cs_check(packet): #True
                        [packet.appendleft(0xFF) for i in xrange(3)]
                        if channel == '232':
                            if packet_id == 'COORD_OUT': rs232_coord_out_q.append(packet)
                            elif packet_id == 'KEY_OUT': rs232_key_out_q.append(packet)
                            elif packet_id == 'STS_OUT': rs232_sts_out_q.append(packet)
                            elif packet_id == 'KEY_SET_OUT': rs232_key_set_out_q.append(packet)
                            elif packet_id == 'STS_PMF':  rs232_sts_pmf_q.append(packet)
                            elif packet_id == 'STS_VPIPE': rs232_sts_vpipe_q.append(packet)
                            elif packet_id == 'STS_VPr1': rs232_sts_vpr1_q.append(packet)
                            elif packet_id == 'STS_VPr2': rs232_sts_vpr2_q.append(packet)
                            elif packet_id == 'STS_VPr3': rs232_sts_vpr3_q.append(packet)
                            elif packet_id == 'STS_VPr4': rs232_sts_vpr4_q.append(packet)
                            elif packet_id == 'STS_VGLV': rs232_sts_vglv_q.append(packet)
                            elif packet_id == 'STS_ETH1': rs232_sts_eth1_q.append(packet)
                            elif packet_id == 'STS_ETH2': rs232_sts_eth2_q.append(packet)
                            elif packet_id == 'STS_OVHP': rs232_sts_ovhp_q.append(packet)
                            elif packet_id == 'KEY_OFF_CLICKED': rs232_key_off_clicked_q.append(packet)
                            elif packet_id == 'RECEIPT_OFF': rs232_receipt_off_q.append(packet)
                                
                        elif channel == '422': 
                            if packet_id == 'COORD_OUT': rs422_coord_out_q.append(packet)
                            elif packet_id == 'KEY_OUT': rs422_key_out_q.append(packet)
                            elif packet_id == 'STS_OUT': rs422_sts_out_q.append(packet)
                            elif packet_id == 'KEY_SET_OUT': rs422_key_set_out_q.append(packet)
                            elif packet_id == 'STS_PMF': rs422_sts_pmf_q.append(packet)
                            elif packet_id == 'STS_VPIPE': rs422_sts_vpipe_q.append(packet)
                            elif packet_id == 'STS_VPr1': rs422_sts_vpr1_q.append(packet)
                            elif packet_id == 'STS_VPr2': rs422_sts_vpr2_q.append(packet)
                            elif packet_id == 'STS_VPr3': rs422_sts_vpr3_q.append(packet)
                            elif packet_id == 'STS_VPr4': rs422_sts_vpr4_q.append(packet)
                            elif packet_id == 'STS_VGLV': rs422_sts_vglv_q.append(packet)
                            elif packet_id == 'STS_ETH1': rs422_sts_eth1_q.append(packet)
                            elif packet_id == 'STS_ETH2': rs422_sts_eth2_q.append(packet)
                            elif packet_id == 'STS_OVHP': rs422_sts_ovhp_q.append(packet)

                        elif channel == 'CAN':
                            pass  # TODO допилить CAN
                        ff1, ff2 = False, False
                        packet_in_progress = False
                        packet = coll.deque()
        else:
            if packet_in_progress:
                if time.clock() > packet_start_time + PACKET_TTL:
                        ff1, ff2 = False, False
                        packet_in_progress = False
                        log.critical(u'Превышено время ожидания пакета, принято: % s' % packet)
                        packet = coll.deque()


def old_packet_parser():
    first_byte = False
    bytes_in_old_packet = 0
    old_packet = coll.deque()
    while run:
        if rs232_old_q:
            rx_old = rs232_old_q.popleft()
            if not first_byte:
                if rx_old == 0xBF or rx_old == 0xFF:
                    first_byte = True
                    flag = rx_old
            else:
                if rx_old == 0xFF:
                    first_byte = True
                    flag = rx_old
                else:
                    old_packet.append(rx_old)
                    bytes_in_old_packet += 1
                    if bytes_in_old_packet == 4:
                        x_coord = (old_packet[2] << 7) + old_packet[3]
                        y_coord = (old_packet[0] << 7) + old_packet[1]
                        old_xy.append((flag, x_coord, y_coord))
                        bytes_in_old_packet = 0
                        old_packet.clear()
                        first_byte = False
                        if len(old_xy) > 100:
                            old_xy.clear()


def fifo_size_out():
    pass
    while run:
        if len(rs232_coord_out_q) > 0:
            print('COORD_OUT: %s' % len(rs232_coord_out_q))
        if len(rs232_key_out_q) > 0:
            print('KEY_OUT: %s' % len(rs232_key_out_q))
        if len(rs232_sts_out_q) > 0:
            print('STS_OUT: %s' % len(rs232_sts_out_q))
        time.sleep(10)


def resp_yes_no():
    resp = None
    while True:
        try:
            resp = int(raw_input())
            if (resp == 0) or (resp == 1):
                break
            else:
                print(u'>>> Значение должно быть 0 или 1, повторите ввод:',)
        except ValueError:
            print(u'>>> Введено недопустимое значение, повторите ввод:',)
    return resp


def resp_0_255():
    resp = None
    while True:
        try:
            resp = int(raw_input())
            if (resp >= 0) and (resp < 256):
                break
            else:
                print(u'>>> Значение должно быть от 0 до 255, '
                      u'повторите ввод:',)
        except ValueError:
            print(u'>>> Введено недопустимое значение, повторите ввод:',)
    return resp


def rx_specific_packet(packet, channel, timeout=1):
    packet_data = []
    start_time = time.clock()
    while time.clock() < start_time + timeout:
        QtCore.QCoreApplication.processEvents()
        if channel == '232':
            if packet == 'STS_OUT':
                if rs232_sts_out_q:
                    packet_data = rs232_sts_out_q.pop()
                    break
            elif packet == 'STS_PMF':
                if rs232_sts_pmf_q:
                    packet_data = rs232_sts_pmf_q.pop()
                    break
            elif packet == 'KEY_OUT':
                if rs232_key_out_q:
                    packet_data = rs232_key_out_q.pop()
                    break
            elif packet == 'KEY_SET_OUT':
                if rs232_key_set_out_q:
                    packet_data = rs232_key_set_out_q.pop()
                    break
            elif packet == 'COORD_OUT':
                if rs232_coord_out_q:
                    packet_data = rs232_coord_out_q.pop()
                    break
            elif packet == 'KEY_OFF_CLICKED':
                if rs232_key_off_clicked_q:
                    packet_data = rs232_key_off_clicked_q.pop()
                    break
                
            elif packet == 'STS_VGLV':
                if rs232_sts_vglv_q:
                    packet_data = rs232_sts_vglv_q.pop()
                    break
            elif packet == 'STS_ETH1':
                if rs232_sts_eth1_q:
                    packet_data = rs232_sts_eth1_q.pop()
                    break
            elif packet == 'STS_ETH2':
                if rs232_sts_eth2_q:
                    packet_data = rs232_sts_eth2_q.pop()
                    break
            elif packet == 'STS_VPr1':
                if rs232_sts_vpr1_q:
                    packet_data = rs232_sts_vpr1_q.pop()
                    break
            elif packet == 'STS_VPr2':
                if rs232_sts_vpr2_q:
                    packet_data = rs232_sts_vpr2_q.pop()
                    break
            elif packet == 'STS_VPr3':
                if rs232_sts_vpr3_q:
                    packet_data = rs232_sts_vpr3_q.pop()
                    break
            elif packet == 'STS_VPr4':
                if rs232_sts_vpr4_q:
                    packet_data = rs232_sts_vpr4_q.pop()
                    break
            elif packet == 'STS_VPIPE':
                if rs232_sts_vpipe_q:
                    packet_data = rs232_sts_vpipe_q.pop()
                    break
            elif packet == 'STS_OVHP':
                if rs232_sts_ovhp_q:
                    packet_data = rs232_sts_ovhp_q.pop()
                    break

        elif channel == '422':
            if packet == 'STS_OUT':
                if rs422_sts_out_q:
                    packet_data = rs422_sts_out_q.pop()
                    break
            elif packet == 'STS_PMF':
                if rs422_sts_pmf_q:
                    packet_data = rs422_sts_pmf_q.pop()
                    break
            elif packet == 'KEY_OUT':
                if rs422_key_out_q:
                    packet_data = rs422_key_out_q.pop()
                    break
            elif packet == 'KEY_SET_OUT':
                if rs422_key_set_out_q:
                    packet_data = rs422_key_set_out_q.pop()
                    break
            elif packet == 'COORD_OUT':
                if rs422_coord_out_q:
                    packet_data = rs422_coord_out_q.pop()
                    break
        elif channel == 'CAN':
            pass  # TODO допилить CAN
        else:
            log.exception('BAD CHANNEL')
    return packet_data


def init(comports_required_n=2):
    """ Инициализация среды перед началом проверок
        1) Поиск СOM портов
        2) Загрузка из файла эталонов (TODO)
    """

    def autoset():
        logging.disable(logging.CRITICAL)
        tm_wait_pmf_on = 3
        com_psh = ''
        com_232 = ''
        print(u'Ищу COM-порт подкл. к PSH (надеюсь PSH включен)...')
        ports = getcomports.serial_ports()
        for port in ports:
            with serial.Serial(port, baudrate=9600) as ser:
                ps = psh.psh3610(ser)
                ps_id = ps.read_id()
                if ps_id != '':
                    print(u'Источник питания подключен к %s' % port)
                    com_psh = port
                    break
        if com_psh != '':
            print(u'Ищу COM-порт подкл. к RS-232 ПМФ (надеюсь PSH включен)...')
            ports = getcomports.serial_ports()
            ports.remove(com_psh)
            with serial.Serial(com_psh, baudrate=9600) as ser:
                ps = psh.psh3610(ser)
                ps.setup(27, 2, 30, 0, 1, 0.5)
                time.sleep(tm_wait_pmf_on)
                for port in ports:
                    with serial.Serial(port, baudrate=9600) as ser:
                        rs232_sts_out_q.clear()
                        rs.set_mode(ser, u'технологический')
                        if len(rx_specific_packet('STS_OUT', '232', 0.3)) > 0:
                            print(u'RS-232 ПМФ подключен к %s' % port)
                            com_232 = port
                            break
        else:
            print(u'PSH не был найден')
        logging.disable(logging.NOTSET)
        return com_psh, com_232

    init_dic = {}
    init_fail = False
    print(chr(12))
    print(u'Подготовка к проверке')
    print(u'>>> Использовать test.ini для настройки? [1 - да, 0 - нет]:',)
    if resp_yes_no() == 0:
        print(u'>>> Автоматически назначить COM-порты? [1 - да, 0 - нет]:',)
        if resp_yes_no() == 0:
            comports = getcomports.serial_ports()
            if len(comports) < comports_required_n:
                print(u'Не хватает доступных COM-портов, завершаю работу')
                init_fail = True
            else:
                print(u'Доступные COM-порты:', " ".join(comports))
                print(u'>>> Введите номер COM-порта подкл. к RS-232 ПМФ:',)
                while True:
                    port_232 = raw_input()
                    if ('COM' + port_232) in comports:
                        print(u'RS-232 ПМФ назначен на COM-порт №', port_232)
                        comports.remove('COM' + port_232)
                        break
                    else:
                        print(u'Неправильный номер порта, повторите попытку:',)
                print(u'Доступные COM-порты:', " ".join(comports))
                print(u'>>> Введите номер COM порта подкл. к PSH3610:',)
                while True:
                    port_psh = raw_input()
                    if ('COM' + port_psh) in comports:
                        print(u'Источник питания назначен на '
                              u'COM-порт №%s' % port_psh)
                        comports.remove('COM' + port_psh)
                        break
                    else:
                        print(u'\nНеправильный номер порта, '
                              u'повторите попытку:',)
                init_dic['RSCOM'] = 'COM' + port_232
                init_dic['PSHCOM'] = 'COM' + port_psh
        else:
            # автосет
            port_psh, port_232 = autoset()
            if (port_psh == '') or (port_232 == ''):
                init_fail = True
            else:
                init_dic['RSCOM'] = port_232
                init_dic['PSHCOM'] = port_psh
    else:
        pass  # тут ввод из файла
        print(u'Загрузка из файла пока не реализована')
        init_fail = True
    return init_dic, init_fail


def logger_close():
    """ Чистка логгера после работы """
    handlers = log.handlers[:]
    for handler in handlers:
        handler.close()
        log.removeHandler(handler)


def print_pmf_sn():
    pmf_sn = ''.join((unichr(i) for i in exp_serial_id if i > 31))
    log.info(u'Тест %s зав.№ %s' % (get_pmf_type(exp_pmf_id), pmf_sn))


def get_pmf_type(pmf_id):
    if pmf_id == 0x10:
        return u'ПМФ-6.0'
    elif pmf_id == 0x11:
        return u'ПМФ-6.1'
    elif pmf_id == 0x12:
        return u'ПМФ-6.2'
    elif pmf_id == 0x13:
        return u'ПМФ-6.3'
    elif pmf_id == 0x14:
        return u'ПМФ-6.4'
    elif pmf_id == 0x15:
        return u'ПМФ-6.5'
    else:
        return u'неизвестное устройство ID = %s' % pmf_id


def get_vga_modes(dev_num):
    """ Получает список режимов VGA. Список режимов используется потом в 
    set_vga_resolution """
    devices = vga.devlist()
    mode_list = vga.modelist(devices[dev_num])
    return mode_list, devices


def set_vga_resolution(x, y, mode_list, devices, dev_num, ask_user):
    er = 0
    vga.change_resolution(devices[dev_num], mode_list,
                          mode_required=(32, x, y, 60, 0))
    if ask_user:
        print(u'>>> Разрешение {}х{} ? [1 - да, 0 - нет]:'.format(x, y),)
        result = resp_yes_no()
        if result == 0:
            log.error(u'Ошибка VGA {}х{}'.format(x, y))
            er += 1
    return er


# =============================================================================
# Тесты атомарные
# =============================================================================
def key_test(one_point=True):
    """Тест клавиатуры \n
    Отображает анимацию нажатия клавиш и считает количество нажатий для \
каждой клавиши. Анализ нажатия ведется независимо для всех каналов: \
RS-232, RS-422, CAN.\n
    Тест содержит два субтеста: \

    1) проверка в режиме "одна клавиша" \

    2) проверка в режиме "все клавиши" \n
    Тестирование продолжается пока пользователь не нажмет на все клавиши\
не менее 3-х раз.\n
    Тест не принимает решение о работоспособности клавиатуры и \
не возвращает количество ошибок.
"""

    PRESS_REQ_TO_STOP = 3

    def key_get(key_out):
        return key_out[4]

    def key_out_get(key_out):
        return (key_out[5] << 7) + key_out[4]

    class button():
        def __init__(self, x0, y0, width, height, color, txt, interface):
            self.pressed_cnt = 0
            self.isPressed = False
            self.time_last_press = 0
            self.time_release = 0.1 #0.15
            self.x = x0
            self.y = y0
            self.dx = width
            self.dy = height
            self.color = color
            self.pressed_color = cGreen
            self.txt = txt
            self.txt_size = 16
            self.screen_sizeX = 1024
            self.screen_sizeY = 768
            self.vx = 0
            self.vy = 0
            self.exist = False
            self.interface = interface

        def make(self):
            self.btn = gr.Rectangle(gr.Point(self.x, self.y),
                                    gr.Point(self.x + self.dx,
                                             self.y + self.dy))
            self.btn.setFill(self.color)
            self.btn_txt = gr.Text(gr.Point(self.x + int(self.dx / 2),
                                            self.y + int(self.dy / 2)),
                                   self.txt)
            self.btn_txt.setSize(self.txt_size)
            self.btn.draw(window)
            self.btn_txt.draw(window)
            self.exist = True

        def pressed(self):
            self.pressed_cnt += 1
            self.btn_txt.setText(self.txt + '\n%s' % str(self.pressed_cnt))
            self.isPressed = True
            self.btn.setFill(self.pressed_color)
            self.time_last_press = time.clock()
            self.shakeitbaby()

        def shakeitbaby(self):
            pass
            self.btn.move(0, -5)
            #time.sleep(0.025)
            time.sleep(0.005)
            self.btn.move(0, 8)
            time.sleep(0.005)
            self.btn.move(0, -3)

        def release(self):
            self.btn.setFill(self.color)
            self.isPressed = False

        def moveto(self, x, y):
            self.btn_txt.move(x - self.x, y - self.y)
            self.btn.move(x - self.x, y - self.y)
            self.x = x
            self.y = y

        def move(self, dx, dy):
            self.btn_txt.move(dx, dy)
            self.btn.move(dx, dy)
            self.x = self.x + dx
            self.y = self.y + dy
            if self.x > self.screen_sizeX or self.y > self.screen_sizeY:
                self.erase()
                self.exist = False

        def update(self):
            if self.isPressed is True:
                if time.clock() > self.time_last_press + self.time_release:
                    self.release()

        def erase(self):
            self.btn_txt.undraw()
            self.btn.undraw()

    window = gr.GraphWin("PMF-6.0 Key test", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    if one_point:
        log.info(u'тест клавиатуры часть 1')
        tt = gr.Text(gr.Point(511, 60), u'Проверка кнопок в режиме \
"одна кнопка" \n нажми кнопки F1-F5, K1-K5 \n не менее 3-х раз')
        tt.draw(window)
        tt.setTextColor(cWhite)
        tt.setSize(16)
    else:
        log.info(u'тест клавиатуры часть 2')
        tt = gr.Text(gr.Point(511, 60), u'Проверка кнопок в режиме \
"все кнопки" \n нажми кнопки F1-F5, K1-K5 \n не менее 3-х раз \n \
нажимай несколько кнопок одновременно')
        tt.draw(window)
        tt.setTextColor(cWhite)
        tt.setSize(16)

    # tmr = gr.Text(gr.Point(511, 150), u'60')
    # tmr.draw(window)
    # tmr.setTextColor(cYellow)
    # tmr.setSize(36)

    tt = gr.Text(gr.Point(40, 15), u'RS-232')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(107, 15), u'RS-422')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(174, 15), u'CAN')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(1024 - 40, 15), u'RS-232')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(1024 - 107, 15), u'RS-422')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    tt = gr.Text(gr.Point(1024 - 174, 15), u'CAN')
    tt.draw(window)
    tt.setTextColor(cYellow)
    tt.setSize(12)

    spx = 8
    x0 = spx
    y0 = 30
    dy = 150
    sp = 4
    size_x = 60
    size_y = 60
    # RS-232 BUTTONS
    b_232 = {}
    for i in xrange(0x21, 0x26):
        b_232[i] = button(x0, y0, size_x, size_y, cWhite, 'F%s' % (i - 0x20),
                          'RS-232')
        b_232[i].make()
        y0 += dy + sp

    x0 = 1023 - spx - size_x
    y0 = 30

    for i in xrange(0x26, 0x2B):
        b_232[i] = button(x0, y0, size_x, size_y, cWhite, 'K%s' % (i - 0x25),
                          'RS-232')
        b_232[i].make()
        y0 += dy + sp

    # RS-422 BUTTONS
    x0 = spx * 2 + size_x
    y0 = 30
    dy = 150
    sp = 4

    b_422 = {}
    for i in xrange(0x21, 0x26):
        b_422[i] = button(x0, y0, size_x, size_y, cWhite, 'F%s' % (i - 0x20),
                          'RS-422')
        b_422[i].make()
        y0 += dy + sp

    x0 = 1023 - size_x * 2 - spx * 2
    y0 = 30

    b_422 = {}
    for i in xrange(0x26, 0x2B):
        b_422[i] = button(x0, y0, size_x, size_y, cWhite, 'K%s' % (i - 0x25),
                          'RS-422')
        b_422[i].make()
        y0 += dy + sp

    # CAN BUTTONS
    x0 = spx * 3 + size_x * 2
    y0 = 30
    dy = 150
    sp = 4

    b_can = {}
    for i in xrange(0x21, 0x26):
        b_can[i] = button(x0, y0, size_x, size_y, cGrey, 'F%s' % (i - 0x20),
                          'CAN')
        b_can[i].make()
        y0 += dy + sp

    x0 = 1023 - size_x * 3 - spx * 3
    y0 = 30

    b_can = {}
    for i in xrange(0x26, 0x2B):
        b_can[i] = button(x0, y0, size_x, size_y, cGrey, 'K%s' % (i - 0x25),
                          'CAN')
        b_can[i].make()
        y0 += dy + sp

#    start_time = time.clock()
#    while (time.clock() < start_time + TEST_TIME) and not test_stop:
#        tmr.setText(str(int(round(TEST_TIME - (time.clock() - start_time)))))

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        for b in b_232: b_232[b].update()
        for b in b_422: b_422[b].update()

        if one_point is True:
            if rs232_key_out_q:
                key = key_get(rs232_key_out_q.popleft())
                try:
                    b_232[key].pressed()
                except Exception as e:
                    print(u'ошибка 232: %s' % str(e))

            if rs422_key_out_q:
                key = key_get(rs422_key_out_q.popleft())
                try:
                    b_422[key].pressed()
                except Exception as e:
                    print(u'ошибка 422: %s' % str(e))

            if can_key_out_q:
                key = key_get(can_key_out_q.popleft())
                try:
                    b_can[key].pressed()
                except Exception as e:
                    print(u'ошибка can: %s' % str(e))
        else:
            if rs232_key_set_out_q:
                key = key_out_get(rs232_key_set_out_q.popleft())
                try:
                    if key & 0x0001 > 0: b_232[0x21].pressed()
                    if key & 0x0002 > 0: b_232[0x22].pressed()
                    if key & 0x0004 > 0: b_232[0x23].pressed()
                    if key & 0x0008 > 0: b_232[0x24].pressed()
                    if key & 0x0010 > 0: b_232[0x25].pressed()
                    if key & 0x0020 > 0: b_232[0x26].pressed()
                    if key & 0x0040 > 0: b_232[0x27].pressed()
                    if key & 0x0080 > 0: b_232[0x28].pressed()
                    if key & 0x0100 > 0: b_232[0x29].pressed()
                    if key & 0x0200 > 0: b_232[0x2A].pressed()
                except Exception as e:
                    print(u'ошибка 232 key_set_out: %s' % str(e))

        if ((b_232[0x21].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x22].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x23].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x24].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x25].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x26].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x27].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x28].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x29].pressed_cnt >= PRESS_REQ_TO_STOP) and
            (b_232[0x2A].pressed_cnt >= PRESS_REQ_TO_STOP)):
            break

    window.close()


def coord_q(coord_out):

    flag1 = coord_out[4]
    y1h = coord_out[5]
    y1l = coord_out[6]
    x1h = coord_out[7]
    x1l = coord_out[8]

    flag2 = coord_out[9]
    y2h = coord_out[10]
    y2l = coord_out[11]
    x2h = coord_out[12]
    x2l = coord_out[13]

    x1 = (x1h << 7) + x1l
    x2 = (x2h << 7) + x2l
#    y1 = (y1h << 7) + y1l
#    y2 = (y2h << 7) + y2l

    y1 = ((y1h << 7) + y1l)
    y2 = ((y2h << 7) + y2l)

    if flag1 == 255:
        flag1 = 0
    else:
        flag1 = 1

    if flag2 == 255:
        flag2 = 0
    else:
        flag2 = 1

    print('f1 = %.5s, f2 = %.5s, x1,y1 = (%.5s, %.5s), \
x2,y2 = (%.5s, %.5s) ' % (flag1, flag2, x1, y1, x2, y2))
    return x1, y1, x2, y2, flag1, flag2


def coord_delay_test():
    """ Проверка задержки выдачи координат.
    Создает окно. На окно выводятся две точки, одна из канала RS-232,
    вторая из UART который формирует МДЦ-104.
    Задержка оценивается визуально. """

    log.info(u'Проверка задержки выдачи координат')

    window = gr.GraphWin("PMF-6.0 Touch Screen", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    radius = 36
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 60), u'Проверка сенсорного экрана №1')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    # tmr = gr.Text(gr.Point(511, 150), u'60')
    # tmr.draw(window)
    # tmr.setTextColor(cYellow)
    # tmr.setSize(36)

    xi1, yi1 = 2000, 2000
    rsdot1 = gr.Circle(gr.Point(xi1, yi1), radius)
    rsdot1.setFill(rsdot_pressed_color)
    rsdot1.draw(window)

    xi2, yi2 = 2000, 2000
    rsdot2 = gr.Circle(gr.Point(xi2, yi2), radius)
    rsdot2.setFill(rsdot_pressed_color)
    rsdot2.draw(window)

    xi3, yi3 = 2000, 2000
    mdcdot1 = gr.Circle(gr.Point(xi3, yi3), radius)
    mdcdot1.setFill(mdcdot_pressed_color)
    mdcdot1.draw(window)

    xi4, yi4 = 2000, 2000
    mdcdot2 = gr.Circle(gr.Point(xi4, yi4), radius)
    mdcdot2.setFill(mdcdot_pressed_color)
    mdcdot2.draw(window)

    rsdot1_pressed = False
    rsdot2_pressed = False

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()

        if rs232_coord_out_q:
            x1, y1, x2, y2, f1, f2 = coord_q(rs232_coord_out_q.popleft())
            if f1 == 1:
                rsdot1.setFill(rsdot_pressed_color)
                y1_mod = int(y1 * 0.75)
                rsdot1.move(x1 - xi1, y1_mod - yi1)
                xi1 = x1
                yi1 = y1_mod
                rsdot1_pressed = True
            else:
                if rsdot1_pressed:
                    rsdot1.setFill(rsdot_released_color)
                    y1_mod = int(y1 * 0.75)
                    rsdot1.move(x1 - xi1, y1_mod - yi1)
                    xi1 = x1
                    yi1 = y1_mod
                    rsdot1_pressed = False
            if f2 == 1:
                rsdot2.setFill(rsdot_pressed_color)
                y2_mod = int(y2 * 0.75)
                rsdot2.move(x2 - xi2, y2_mod - yi2)
                xi2 = x2
                yi2 = y2_mod
                rsdot2_pressed = True
            else:
                if rsdot2_pressed:
                    rsdot2.setFill(rsdot_released_color)
                    y2_mod = int(y2 * 0.75)
                    rsdot2.move(x2 - xi2, y2_mod - yi2)
                    xi2 = x2
                    yi2 = y2_mod
                    rsdot2_pressed = False
    window.close()


def response_time_move():
    """
    Проверка времени отклика
    """
    log.info(u'Проверка времени отклика (бегущие квадраты)')

    class MovingBox:

        def __init__(self, x, y, size, speed, window):
            self.x0 = x
            self.y0 = y
            self.x = x
            self.y = y
            self.size = size
            self.speed = speed
            self.window = window
            self.box = gr.Rectangle(gr.Point(self.x, self.y),
                                    gr.Point(self.x + self.size,
                                             self.y + self.size))
            self.box.setFill(cWhite)
            self.box.setOutline(cWhite)
            self.box.draw(window)

        def mv(self):
            while test_stop is False and test_next is False:
                if self.x < 1024:
                    self.box.move(1, 0)
                    self.x += 1
                else:
                    self.box.move(self.x0 - self.x, self.y0 - self.y)
                    self.x = self.x0
                self.window.update()
                time.sleep(1 / self.speed)

    window = gr.GraphWin("PMF-6.0 RT", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 60), u'Проверка времени отклика')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    mark_space = 10
    mark_y = 100
    mark_length = 40
    for i in xrange(110):
        mark = gr.Line(gr.Point(i * mark_space, mark_y),
                       gr.Point(i * mark_space, mark_y + mark_length))
        mark.setFill(cWhite)
        mark.draw(window)

    x1 = 0
    y1 = 150
    size = 50
    step_y = 70
    speed = 512

    bx1 = MovingBox(x1, y1, size, speed, window)
    bx2 = MovingBox(x1, y1 + step_y * 1, size, (speed / 2), window)
    bx3 = MovingBox(x1, y1 + step_y * 2, size, (speed / 4), window)
    bx4 = MovingBox(x1, y1 + step_y * 3, size, (speed / 8), window)
    bx5 = MovingBox(x1, y1 + step_y * 4, size, (speed / 16), window)
    bx6 = MovingBox(x1, y1 + step_y * 5, size, (speed / 32), window)
   
    threading.Thread(target=bx1.mv).start()
    threading.Thread(target=bx2.mv).start()
    threading.Thread(target=bx3.mv).start()
    threading.Thread(target=bx4.mv).start()
    threading.Thread(target=bx5.mv).start()
    threading.Thread(target=bx6.mv).start()

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        # if rs232_key_out_q:
        #     break
        window.update()
    time.sleep(0.3)
    rs232_key_out_q.clear()
    window.close()


def response_time_blink(ser):
    """ Проверка времени отклика """

    log.info(u'Проверка времени отклика (мерцающий квадрат)')

    class BlinkingBox:

        def __init__(self, x, y, size, speed, window):
            self.color = cBlack
            self.x = x
            self.y = y
            self.size = size
            self.speed = speed
            self.window = window
            self.box = gr.Rectangle(gr.Point(self.x, self.y),
                                    gr.Point(self.x + self.size,
                                             self.y + self.size))
            self.box.setFill(cWhite)
            self.box.setOutline(cWhite)
            self.box.draw(window)
            self.starttime = time.time()
            self.txt = ' '
            
#            tt = gr.Text(gr.Point(511, 200), self.txt)
#            tt.draw(window)
#            tt.setTextColor(cWhite)
#            tt.setSize(32)

        def mv(self):
            while test_stop is False and test_next is False:
                if self.color == cBlack:
                    self.window.autoflush = False
                    self.box.setFill(cWhite)
                    self.box.setOutline(cWhite)
                    self.color = cWhite
                    self.window.autoflush = True
                else:
                    self.window.autoflush = False
                    self.box.setFill(cBlack)
                    self.box.setOutline(cBlack)
                    self.color = cBlack
                    self.window.autoflush = True
                self.window.update()
                time.sleep(1 / self.speed)
        def temper_time(self):
            while test_stop is False and test_next is False:
                rs.req_sts(ser)
                time.sleep(1)
                #tt.undraw()
                sts = rx_specific_packet('STS_PMF', '232')        
                if sts:
                    tmp_ts_raw = sts[24]
                    tmp_mi_raw = sts[25] + ((sts[26] << 7) & 0x80)
                    if (tmp_ts_raw & 0x80) == 0x80:
                        tmp_ts = tmp_ts_raw - 256
                    else:
                        tmp_ts = tmp_ts_raw
                        
                    if (tmp_mi_raw & 0x80) == 0x80:
                        tmp_mi = tmp_mi_raw - 256
                    else:
                        tmp_mi = tmp_mi_raw
                    self.txt = u'температура МДЦ = %s °C\n' \
                               u'температура МИ = %s °C\n' \
                               u'время работы = %s c' % (tmp_ts, tmp_mi, int(time.time() - self.starttime)) 
                    tt.setSize(32)                    
                    tt.setText(self.txt)
                    
                  
                self.window.update()

    rs.set_mode(ser, u'расширенный')
    time.sleep(1)
    rs.set_heater(ser, [0x00, 0x00])
    time.sleep(1)
    rs.set_heater(ser, [0x01, 0x01])
    
    
    clear_all_q()
    
    window = gr.GraphWin("PMF-6.0 RT", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 150), u'Проверка времени отклика №2 \n'
                                    u'период 1000 мс')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    size = 200
    x1 = int((1024 - size) / 2)
    y1 = int((768 - size) / 2)
    speed = 2

    bx1 = BlinkingBox(x1, y1, size, speed, window)
    threading.Thread(target=bx1.mv).start()
    threading.Thread(target=bx1.temper_time).start()

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        window.update()
        
    time.sleep(0.3)
    rs232_key_out_q.clear()
    window.close()


def coord_resolution_slide():
    """ Проверка разрешения сенсорного экрана """

    log.info(u'Проверка разрешения сенсора (скольжение)')
    window = gr.GraphWin("PMF-6.0 Touch Screen", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 60), u'Проверка разрешения сенсорного экрана '
                                    u'при жесте "скольжение"')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    xy = gr.Text(gr.Point(511, 100), u'x:0, y:0')
    xy.setTextColor(cWhite)
    xy.setSize(28)
    xy.setStyle("bold")
    xy.draw(window)

    res_x = set()
    res_y = set()
    xy.setText('x:%s, y:%s' % (len(res_x), len(res_y)))

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        if rs232_coord_out_q:
            x1, y1, x2, y2, f1, f2 = \
                coord_q(rs232_coord_out_q.popleft())
            if f1 == 1:
                y1_mod = int(y1 * 0.75)
                xi = x1
                yi = y1_mod

                if xi in res_x:
                    pass
                else:
                    ln = gr.Line(gr.Point(xi, 0), gr.Point(xi, 767))
                    ln.setWidth(1)
                    ln.setFill(cGreen)
                    ln.draw(window)
                res_x.add(xi)
                res_y.add(yi)
                xy.undraw()
                xy.setText('x:%s, y:%s' % (len(res_x), len(res_y)))
                xy.draw(window)
                tt.undraw()
                tt.draw(window)                
    window.close()


def coord_resolution_tap():
    """ Проверка разрешения сенсорного экрана """

    log.info(u'Проверка разрешения сенсора (касание)')

    window = gr.GraphWin("PMF-6.0 Touch Screen", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 60), u'Проверка разрешения сенсорного экрана '
                                    u'при жесте "касание"')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    xy = gr.Text(gr.Point(511, 100), u'x:0, y:0')
    xy.setTextColor(cWhite)
    xy.setSize(28)
    xy.setStyle("bold")
    xy.draw(window)

    res_x = set()
    res_y = set()
    xy.setText('x:%s, y:%s' % (len(res_x), len(res_y)))
    is_pressed = False

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        if rs232_coord_out_q:
            x1, y1, x2, y2, f1, f2 = \
                coord_q(rs232_coord_out_q.popleft())
            if is_pressed:
                if f1 == 0:
                    is_pressed = False
                    y1_mod = int(y1 * 0.75)
                    xi = x1
                    yi = y1_mod

                    if xi in res_x:
                        pass
                    else:
                        ln = gr.Line(gr.Point(xi, 0), gr.Point(xi, 767))
                        ln.setWidth(1)
                        ln.setFill(cGreen)
                        ln.draw(window)
                    res_x.add(xi)
                    res_y.add(yi)
                    xy.undraw()
                    xy.setText('x:%s, y:%s' % (len(res_x), len(res_y)))
                    xy.draw(window)
                    tt.undraw()
                    tt.draw(window)
            else:
                if f1 == 1:
                    is_pressed = True
    window.close()

def coord_zone():
    """
    Проверка выдачи коородинат выходящих за диапазон \n
    0 < x < 1024\n
    0 < y < 768
    """

    log.info(u'Проверка аномальных координат сенсора')

    window = gr.GraphWin("PMF-6.0 Touch Screen", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    border = 0
    brdr = gr.Rectangle(gr.Point(border, border),gr.Point(1023 - border,
                        767 - border))

    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 60),
                 u'Проверка выдачи коородинат выходящих за диапазон\n'
                 u'0 < x < 1024\n'
                 u'0 < y < 768')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    bad_coord_txt_pos_x = 120
    bad_coord_txt_pos_y = 30

    p1_pressed = False
    p2_pressed = False
    
    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        if rs232_coord_out_q:
            pack = rs232_coord_out_q.popleft()
            log.info(pack)
            x1, y1, x2, y2, f1, f2 = coord_q(pack)
            if f1 == 1:
                p1_pressed = True
                y1_mod = int(y1 * 0.75)
                xi = x1
                yi = y1_mod
                if (xi > 1100 or yi > 1100):
                    ln = gr.Line(gr.Point(511, 383), gr.Point(xi, yi))
                    ln.setFill(cRed)
                    ln.draw(window)
                    tt = gr.Text(gr.Point(bad_coord_txt_pos_x,
                                          bad_coord_txt_pos_y),
                                 'point 1: x=%s, y=%s' % (xi,yi))
                    tt.setFill(cRed)
                    tt.draw(window)
                    bad_coord_txt_pos_y += 20
            else:
                if p1_pressed is True:
                    p1_pressed = False
                    log.info('dot 1 released')
                    y1_mod = int(y1 * 0.75)
                    xi = x1
                    yi = y1_mod
                    if (xi > 1100 or yi > 1100):
                        ln = gr.Line(gr.Point(511, 383), gr.Point(xi, yi))
                        ln.setFill(cRed)
                        ln.draw(window)
                        tt = gr.Text(gr.Point(bad_coord_txt_pos_x,
                                              bad_coord_txt_pos_y),
                                     'point 1: x=%s, y=%s' % (xi,yi))
                        tt.setFill(cRed)
                        tt.draw(window)
                        bad_coord_txt_pos_y += 20                    
                    
            if f2 == 1:
                p2_pressed = True
                y2_mod = int(y2 * 0.75)
                xi = x2
                yi = y2_mod
                if (xi > 1100 or yi > 1100) or (xi < 1 or yi < 1):
                    ln = gr.Line(gr.Point(511, 383), gr.Point(xi, yi))
                    ln.setFill(cYellow)
                    ln.draw(window)
                    tt = gr.Text(gr.Point(bad_coord_txt_pos_x,
                                          bad_coord_txt_pos_y),
                                 'point 2: x=%.5s, y=%.5s' % (xi,yi))
                    tt.setFill(cYellow)
                    tt.draw(window)
                    bad_coord_txt_pos_y += 20
            else:
                if p2_pressed:
                    p2_pressed = False
                    log.info('dot 2 released')
                    y2_mod = int(y2 * 0.75)
                    xi = x2
                    yi = y2_mod
                    log.info(x2)
                    log.info(y2)
                    if (xi > 1100 or yi > 1100) or (xi < 1 or yi < 1):
                        ln = gr.Line(gr.Point(511, 383), gr.Point(xi, yi))
                        ln.setFill(cYellow)
                        ln.draw(window)
                        tt = gr.Text(gr.Point(bad_coord_txt_pos_x,
                                              bad_coord_txt_pos_y),
                                     'point 2: x=%.5s, y=%.5s' % (x2,y2))
                        tt.setFill(cYellow)
                        tt.draw(window)
                        bad_coord_txt_pos_y += 20
                        
    window.close()                


def coord_drawer_232():
    """
    Тест
    """

    log.info(u'Проверка сенсора (рисовалка)')

    class CoordWindow:
        def __init__(self, width, height):
            self.dot1_pressed_color = gr.color_rgb(0, 0, 255)
            self.dot1_released_color = gr.color_rgb(255, 255, 255)
            self.dot2_pressed_color = gr.color_rgb(0, 255, 255)
            self.dot2_released_color = gr.color_rgb(255, 128, 128)
            self.rsdot_radius = 32
            self.window = gr.GraphWin("PMF-6.0 Touch Screen", width, height)
            self.window.setCoords(0, 767, 1023, 0)
            self.window.setBackground(cBlack)
            self.maxitems = 10
            self.dot1_pressed = False
            self.dot2_pressed = False

            self.tt = gr.Text(gr.Point(511, 60), u'Проверка сенсорного '
                                                 u'экрана №2')
            self.tt.draw(self.window)
            self.tt.setTextColor(cWhite)
            self.tt.setSize(16)

            brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
            brdr.setOutline(cWhite)
            brdr.draw(self.window)

            # self.tmr = gr.Text(gr.Point(511, 150), u'60')
            # self.tmr.draw(self.window)
            # self.tmr.setTextColor(cYellow)
            # self.tmr.setSize(36)

        def dots_process(self, x1, y1, x2, y2, f1, f2):
            if f1 == 1:
                self.dot1_pressed = True
                self.draw_dot(x1, y1, self.dot1_pressed_color)
            else:
                if self.dot1_pressed is True:
                    self.draw_dot(x1, y1, self.dot1_released_color)
                    self.dot1_pressed = False
            if f2 == 1:
                self.dot2_pressed = True
                self.draw_dot(x2, y2, self.dot2_pressed_color)
            else:
                if self.dot2_pressed is True:
                    self.draw_dot(x2, y2, self.dot2_released_color)
                    self.dot2_pressed = False

        def draw_dot(self, x, y, color):
            y_mod = int(y * 0.75)
            rsdot = gr.Circle(gr.Point(x, y_mod), self.rsdot_radius)
            rsdot.setFill(color)
            rsdot.draw(self.window)
            if len(self.window.items[:]) > self.maxitems:
                self.delitem(0)

        def delitem(self, n):
            self.window.delItem(self.window.items[n])

        def close(self):
            self.window.close()

    w = CoordWindow(1024, 768)

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        if rs232_coord_out_q:
            pack = rs232_coord_out_q.popleft()
            log.info(pack)
            x1, y1, x2, y2, f1, f2 = \
                coord_q(pack)
            
            w.dots_process(x1, y1, x2, y2, f1, f2)
            if x2 > 950 and y2 > 950:
                break
    w.close()


def coord_accuracy():
    """Тест точности определения координат 
    Отображает круг радиусом (R + E) мм в координатах которые передал
    сенсорный экран
    R - минимальный радиус объекта касания (4 мм)
    E - заданная ошибка определения координат (2.6 мм)
    
    Опреатор касается экрана объектом диаметром 8 мм и смотрит не выступает ли
    объект за границы нарисованного круга. Если не выступает, то ошибка 
    определения координат меньше заданной.
    """    
    
    def process(x, y, x1, y1):
        #y1 = y1 * 0.75

        distance_x_pix = "{:.1f}".format(x1 - x) + ' pix  '

        distance_y_pix = "{:.1f}".format(y1 - y) + ' pix  '                                
        
        distance_in_mm = ("{:.1f}".format((math.sqrt(
                                ((x1 - x) * 0.2055) ** 2 +
                                ((y1 - y) * 0.2055) ** 2))) + ' mm  ' +
                                distance_x_pix + distance_y_pix)
        tt.setText(distance_in_mm)
    stick_rad_pix = (8 / 2) / 0.2055
    error_pix = 2.6 / 0.2055
    aim_radius_in_pixels = int(math.ceil((stick_rad_pix + error_pix)))
    window = gr.GraphWin("Touch Screen Accuracy", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)
    border = 0
    brdr = gr.Rectangle(gr.Point(border, border), gr.Point(1023 - border,
                                                           767 - border))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 20), u'Проверка ошибки определения коородинат')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    target_on = False
    dx = 0
    dy = 0
    x = 0
    y = 0

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()

        if not target_on:
            if dx == 0 and dy == 0:
                pass
            else:
                x = x + dx
                y = y + dy
                                
            aim = gr.Circle(gr.Point(x, y), aim_radius_in_pixels)
            aim.setOutline(cWhite)
            aim.setFill(cGrey)
            aim.draw(window)
            vln = gr.Line(gr.Point(x, 0), gr.Point(x, 767))
            vln.setFill(cGreen)
            vln.draw(window)
            hln = gr.Line(gr.Point(0, y), gr.Point(1023, y))
            hln.setFill(cGreen)
            hln.draw(window)
            target_on = True

        if rs232_coord_out_q:
            pack = rs232_coord_out_q.popleft()
            x1, y1, x2, y2, f1, f2 = coord_q(pack)

            y1 = y1 * 0.75
            target_on = False
            dx, dy = x1-x, y1-y
            for item in window.items[:]:
                item.undraw()
            tt.draw(window)            
            
            process(x, y, x1, y1)

        if rs232_key_out_q:
            pack = rs232_key_out_q.popleft()
            key = pack[4]
            if key == 0x26:
                break
    window.close()

def coord_accuracy_measure():
    """Тест точности определения координат 
    Отображает круг радиусом (R + E) мм в произвольном месте экрана
    R - минимальный радиус объекта касания (4 мм)
    E - заданная ошибка определения координат (2.6 мм)
    Опреатор касается экрана объектом диаметром 8 мм и смотрит на 
    расчитанную ошибку определения координат.
    """      
    
    def process(x, y, x1, y1):
        y1 = y1 * 0.75

        distance_x_pix = "{:.1f}".format(x1 - x) + ' pix  '

        distance_y_pix = "{:.1f}".format(y1 - y) + ' pix  '                                
        
        distance_in_mm = ("{:.1f}".format((math.sqrt(
                                ((x1 - x) * 0.2055) ** 2 +
                                ((y1 - y) * 0.2055) ** 2))) + ' mm  ' +
                                distance_x_pix + distance_y_pix)
        tt.setText(distance_in_mm)
    stick_rad_pix = (8 / 2) / 0.2055
    error_pix = 2.6 / 0.2055
    aim_radius_in_pixels = int(math.ceil((stick_rad_pix + error_pix)))
    window = gr.GraphWin("Touch Screen Accuracy", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)
    border = 0
    brdr = gr.Rectangle(gr.Point(border, border), gr.Point(1023 - border,
                                                           767 - border))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 20), u'Проверка ошибки определения коородинат')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    target_on = False
    dx = 0
    dy = 0
    x = 0
    y = 0

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()

        if not target_on:
            if dx == 0 and dy == 0:
                x = random.randint(20, 1004)
                y = random.randint(20, 748)
            else:
                x = x + dx
                y = y + dy
                                
            aim = gr.Circle(gr.Point(x, y), aim_radius_in_pixels)
            aim.setOutline(cWhite)
            aim.setFill(cGrey)
            aim.draw(window)
            vln = gr.Line(gr.Point(x, 0), gr.Point(x, 767))
            vln.setFill(cGreen)
            vln.draw(window)
            hln = gr.Line(gr.Point(0, y), gr.Point(1023, y))
            hln.setFill(cGreen)
            hln.draw(window)
            target_on = True

        if rs232_coord_out_q:
            pack = rs232_coord_out_q.popleft()
            x1, y1, x2, y2, f1, f2 = coord_q(pack)
            process(x, y, x1, y1)

        if rs232_key_out_q:
            pack = rs232_key_out_q.popleft()
            key = pack[4]
            if key == 0x21:
                target_on = False
                dx, dy = 0, 0
                for item in window.items[:]:
                    item.undraw()
                tt.draw(window)

            if key == 0x24:
                target_on = False
                dx, dy = 1, 0
                for item in window.items[:]:
                    item.undraw()
                tt.draw(window)

            if key == 0x25:
                target_on = False
                dx, dy = -1, 0
                for item in window.items[:]:
                    item.undraw()
                tt.draw(window)

            if key == 0x29:
                target_on = False
                dx, dy = 0, 1
                for item in window.items[:]:
                    item.undraw()
                tt.draw(window)

            if key == 0x2A:
                target_on = False
                dx, dy = 0, -1
                for item in window.items[:]:
                    item.undraw()
                tt.draw(window)                
                
            if key == 0x26:
                break

    window.close()

# TODO переделать так чтобы из папки указнной в конфиге грузились изображения
# TODO в произвольном количестве и с произвольными именами, сделать
# TODO проверку на валидность изображения перед загрузкой
def picture_set():
    """ переключение картинок
    """
    log.info(u'Изображения 1024х768')

    def wait_f1():
        while test_stop is False and test_next is False:
            QtCore.QCoreApplication.processEvents()
            window.update()
            if rs232_key_out_q:
                key = rs232_key_out_q.popleft()
                if key[4] == 0x21:
                    rs232_key_out_q.clear()
                    break

    window = gr.GraphWin("PMF-6.0 pictures", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)
    window.focus_set()

#    img = []
#    for i in xrange(1, 8):
#        img.append(gr.Image(gr.Point(512, 384), "img1024/pic%s.gif" % i))

    img = []
    for i in xrange(1, 13):
        img.append(gr.Image(gr.Point(512, 384), "img1024/%s.gif" % i))

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        rs232_key_out_q.clear()
        for pic in img:
            pic.draw(window)
            wait_f1()
            if test_stop is True or test_next is True: break
            pic.undraw()
    window.close()


# =============================================================================
# Тесты чеклиста
# =============================================================================
def chk00_start_time(ser, timeout=3):
    """ Измерение времени готовности ПМФ.
    Процедура не включает в себя управление источником питания.
    Проверяется через какое время после вызова процедуры ПМФ ответит
    пакетом STS_OUT на пакет SET_MODE.
    Погрешность измерения ~ resp_time + 15 мс
    """
    errors = 0
    resp_time = 0.5
    is_awake = False
    rs232_sts_out_q.clear()
    log.info(u'00:[Проверка времени готовности ПМФ]')
    start_time = time.clock()
    while time.clock() < start_time + timeout:
        QtCore.QCoreApplication.processEvents()
        rs.set_mode(ser, u'технологический')
        time.sleep(resp_time)
        if len(rs232_sts_out_q) > 0:
            log.info(u'00-1: ОK: ПМФ ответил через %s с'
                     % (time.clock() - start_time))
            is_awake = True
            break
    if is_awake is False:
        log.error(u'00-1:ERR: ПМФ не ответил через %s с' % timeout)
        errors += 1
    return errors


def chk01_set_mode(ser, resp_timeout=1):
    """ Проверка установки режимов работы ПМФ """
    errors = 0
    log.info(u'01:[Проверка установки режимов работы ПМФ]')
    rs232_sts_out_q.clear()
    rs.set_mode(ser, u'штатный')

    sts_out = rx_specific_packet('STS_OUT', '232', resp_timeout)

    if len(sts_out) > 0:
        if (sts_out[6] & 0x0A) == 0x00:  # проверяем, что мы в штатном режиме
            log.info(u'01-1: ОK: установлен признак режима штатный')
        else:
            log.error(u'01-1:ERR: не установлен признак режима штатный')
            errors += 1
    else:
        log.error(u'01-1:ERR: нет ответа sts_out на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    rs232_sts_out_q.clear()
    rs.set_mode(ser, u'технологический')

    sts_out = rx_specific_packet('STS_OUT', '232', resp_timeout)

    if len(sts_out) > 0:
        if (sts_out[6] & 0x0A) == 0x02:  # проверяем, что мы в тех.режиме
            log.info(u'01-2: ОK: установлен признак режима технологический')
        else:
            log.error(u'01-2:ERR: не установлен признак режима \
            технологический')
            errors += 1
    else:
        log.error(u'01-2:ERR: нет ответа sts_out на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    rs232_sts_pmf_q.clear()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232', resp_timeout)
    if len(sts_pmf) > 0:
        if (sts_pmf[27] & 0x0A) > 0x02:  # проверяем, что мы в расшир. режиме
            log.info(u'01-3: ОK: установлен признак режима расширенный')
        else:
            log.error(u'01-3:ERR: не установлен признак режима расширенный')
            errors += 1
    else:
        log.error(u'01-3:ERR: нет ответа sts_pmf на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    return errors


# def chk02_stats(ser, exp_id, exp_softid, exp_hardid, exp_serialid,
#                 exp_temp_MD, exp_temp_MI, resp_timeout=1):
def chk02_stats(ser, resp_timeout=1):
    """ Проверка идентификаторов ПМФ """

    errors = 0
    log.info(u'02:[Проверка параметров ПМФ]')
    rs232_sts_pmf_q.clear()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232', resp_timeout)
    if len(sts_pmf) > 0:
        if sts_pmf[4] == exp_pmf_id:  # 02-2 проверяем идентификатор ПМФ
            log.info(u'02-1: OK: Ожидаемый PMF_ID = %s, полученный \
            PMF_ID = %s' % (hex(exp_pmf_id), hex(sts_pmf[4])))
        else:
            log.error(u'02-1:ERR: Ожидаемый PMF_ID = %s, полученный \
            PMF_ID = %s' % (hex(exp_pmf_id), hex(sts_pmf[4])))
            errors += 1
        if sts_pmf[5:10] == exp_soft_id:  # проверяем версию ПО
            log.info(u'02-2: OK: Ожидаемый SOFT_ID = %s, полученный \
            SOFT_ID = %s' % (exp_soft_id, sts_pmf[5:10]))
        else:
            log.error(u'02-2:ERR: Ожидаемый SOFT_ID = %s, полученный \
            SOFT_ID = %s' % (exp_soft_id, sts_pmf[5:10]))
            errors += 1
        if sts_pmf[10:15] == exp_hard_id:  # проверяем версию аппаратуры
            log.info(u'02-3: OK: Ожидаемый HARD_ID = %s, полученный \
            HARD_ID = %s' % (exp_hard_id, sts_pmf[10:15]))
        else:
            log.error(u'02-3:ERR: Ожидаемый HARD_ID = %s, полученный \
            HARD_ID = %s' % (exp_hard_id, sts_pmf[10:15]))
            errors += 1
        if sts_pmf[15:24] == exp_serial_id:  # проверяем заводской номер
            log.info(u'02-4: OK: Ожидаемый SERIAL_ID = %s, полученный \
            SERIAL_ID = %s' % (exp_serial_id, sts_pmf[15:24]))
        else:
            log.error(u'02-4:ERR: Ожидаемый SERIAL_ID = %s, полученный \
            SERIAL_ID = %s' % (exp_serial_id, sts_pmf[15:24]))
            errors += 1
            # TODO написать нормальный обработчик принятой температуры
            # проверяем температуру МД
        if exp_temp_MD[0] < sts_pmf[24] < exp_temp_MD[1]:
            log.info((u'02-5: OK: Ожидаемая температура МД от %s до %s, \
            полученная = %s' % (exp_temp_MD[0], exp_temp_MD[1], sts_pmf[24])))
        else:
            log.error((u'02-5:ERR: Ожидаемая температура МД от %s до %s, \
            полученная = %s' % (exp_temp_MD[0], exp_temp_MD[1], sts_pmf[24])))
            errors += 1
        # TODO написать нормальный обработчик принятой температуры
        if exp_temp_MI[0] < sts_pmf[25] < exp_temp_MI[1] and \
                        sts_pmf[26] == 0:  # проверяем температуру МИ
            log.info((u'02-6: OK: Ожидаемая температура МИ от %s до %s, \
            полученная = %s' % (exp_temp_MI[0], exp_temp_MI[1], sts_pmf[25])))
        else:
            log.error((u'02-6:ERR: Ожидаемая температура МИ от %s до %s, \
            полученная = %s' % (exp_temp_MI[0], exp_temp_MI[1], sts_pmf[25])))
            errors += 1
    else:
        log.error(u'02-X:ERR: ПМФ не ответил sts_pmf на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1

    return errors


# TODO переделать получение времени
def chk03_runtime(ser, sleep_time, resp_timeout=1):
    """ Проверка времени наработки ПМФ """

    errors = 0
    log.info(u'03:[Проверка времени наработки]')
    rs232_sts_pmf_q.clear()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232', resp_timeout)
    if sts_pmf:
        PMF_time1 = sts_pmf[31:36]
        PMF_time2 = PMF_time1[::-1]
        rtime1 = 0
        i = 4
        for c in xrange(len(PMF_time2)):
            rtime1 += PMF_time2[c] << (i * 8)
            i += -1
        rtime1 *= 0.25 # время наработки ПМФ в секундах
        first = rtime1
        log.info(u'03-1:INF: Ждем %s c' % sleep_time)
        time.sleep(sleep_time)
        rs.req_sts(ser)
        sts_pmf = rx_specific_packet('STS_PMF', '232', resp_timeout)
        if len(sts_pmf) > 0:
            PMF_time1 = sts_pmf[31:36]
            PMF_time2 = PMF_time1[::-1]
            rtime2 = 0
            i = 4
            for c in xrange(len(PMF_time2)):
                rtime2 += PMF_time2[c] << (i * 8)
                i += -1
            rtime2 *= 0.25  # время наработки ПМФ в секундах
            time_diff = abs(rtime2 - (first + sleep_time))
            time_err_allowed = 1
            if time_diff <= time_err_allowed:
                log.info(u'03-1: OK: Разница во времени между прочитанной и \
                заданной %s <= %s c' % (time_diff, time_err_allowed))
            else:
                log.info(u'03-1:ERR: Время_1 = %s, Время_2 = %s, time_diff = '
                         u'%s, \
                exp_diff = %s' % (first, rtime2, time_diff, time_err_allowed))
                errors += 1
        else:
            log.info(u'03-1:ERR: ПМФ не ответил sts_pmf на SET_MODE за %s с'
                     % resp_timeout)
            errors += 1
    else:
        log.error(u'03-1:ERR: ПМФ не ответил sts_pmf на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    return errors


def chk04_vga_resolution():
    """ Проверка установки разрешений VGA """

#    errors = 0
#    ask = True
#    log.info(u'04:[Проверка установки разрешений VGA]')
#    dev_num = 3  # TODO автоматизировать выбор устройства
#    mode_list, devices = get_vga_modes(dev_num)
#    errors += set_vga_resolution(640, 480, mode_list, devices, dev_num, ask)
#    errors += set_vga_resolution(800, 600, mode_list, devices, dev_num, ask)
#    errors += set_vga_resolution(1024, 768, mode_list, devices, dev_num, ask)
#    return errors
    errors = 0
    ask = False
    log.info(u'04:[Проверка установки разрешений VGA]')
    dev_num = 3  # TODO автоматизировать выбор устройства
    mode_list, devices = get_vga_modes(dev_num)
    
    res = [(640,480),(800,600),(1024,768)]
    
    for n in xrange(600):
        rnd = n % 3
        log.info(("%s x=%s, y=%s" % (n, res[rnd][0], res[rnd][1])))
        set_vga_resolution(res[rnd][0], res[rnd][1], mode_list, devices, dev_num, ask)
        time.sleep(3)
    
    
#    for n in xrange(20):
#        rnd = random.randint(0, 2)
#        log.info(("x=%s, y=%s" % (res[rnd][0], res[rnd][1])))
#        set_vga_resolution(res[rnd][0], res[rnd][1], mode_list, devices, dev_num, ask)
#        time.sleep(3)
    
    
    return errors


def chk05_toprosa(ser, resp_timeout=1, time_to_wait=3):
    """ Описание 05
    """
    def check(ser, topros):
        passed = 0
        failed = 0
        err_time_list = []
        topros_sec = (topros + 1) * 0.025
        param = [0xFE, 0x46, 0x46, 0x46, 0x0A, 0x0A, 0x0A, 0x58, 0x00, 0x00,
                 0x00, topros, 0x0A, 0xFE, 0x00, 0x00]
        rs.set_param(ser, param)
        start_time = time.clock()
        last_time = 0
        err_in_time_measurement = 0.04
        first_time = True
        while time.clock() < start_time + time_to_wait:
            rx_specific_packet('KEY_SET_OUT', '232', resp_timeout)
            delta_t = time.clock() - last_time
            if first_time is True:
                first_time = False
            else:
                if abs(delta_t - topros_sec) < err_in_time_measurement:
                    passed += 1
                else:
                    failed += 1
                    err_time_list.append(delta_t - topros_sec)
            last_time = time.clock()
        if len(err_time_list) == 0:
            max_time_err = 0
        else:
            max_time_err = max(err_time_list)
        return passed, failed, max_time_err

    errors = 0
    log.info(u'05:[Проверка установки Toprosa]')
    rs.set_mode(ser, u'технологический')
    rs.set_key_mode(ser, u'все кнопки')
    topros_min = 2  # мин. допустимое значение по протоколу 75 мс = (2+1)*25мс
    topros_2 = 9
    topros_3 = 19

    passed, failed, err_max = check(ser, topros_min)
    if failed > 0:
        msg = u'05-1:ERR: Topros = {}, успешно {}, ошибок {}, расхождение {} c\
        '.format(topros_min, passed, failed, err_max)
        log.error(msg)
        errors += 1

    passed, failed, err_max = check(ser, topros_2)  # 250 мс
    if failed > 0:
        msg = u'05-2:ERR: Topros = {}, успешно {}, ошибок {}, расхождение {} c\
        '.format(topros_2, passed, failed, err_max)
        log.error(msg)
        errors += 1

    passed, failed, err_max = check(ser, topros_3)  # 500 мс
    if failed > 0:
        msg = u'05-3:ERR: Topros = {}, успешно {}, ошибок {}, расхождение {} c\
        '.format(topros_3, passed, failed, err_max)
        log.error(msg)
        errors += 1

    rs.set_key_mode(ser, u'одна кнопка')
    return errors


def chk06_brightness(ser, manual=False):
    """ Проверка установки яркости
    у проверки два режима, ручной и автоматический.
    В автоматическом режиме идет перебор всех значений яркости от 0 до 254 и
    обратно 3 раа.
    В ручном режиме пользователя просят установить яркость и подтвердить
    успешную установку до тех пор пока пользователь не захочет прекратить
    проверку и не введет 255.
    """
    errors = 0
    wait = 0.005
    log.info(u'06:[Проверка установки яркости]')
    rs.set_mode(ser, u'технологический')
    if not manual:
        br = 0
        dbr = 1
        for i in xrange(3):
            while True:
                QtCore.QCoreApplication.processEvents()
                if br > 254:
                    br = 254
                    rs.set_brit(ser, br)
                    time.sleep(wait)
                    dbr = -dbr
                    break
                elif br < 0:
                    br = 0
                    rs.set_brit(ser, br)
                    time.sleep(wait)
                    dbr = -dbr
                    break
                else:
                    rs.set_brit(ser, br)
                    br += dbr
                    time.sleep(wait)
        # print u'\n>>> Яркость изменялась? [1 - да, 0 - нет]:',
        # resp = resp_yes_no()
        # if resp == 1:
        #     log.info(u'Проверка изменения яркости прошла успешно')
        # else:
        #     log.error(u'Ошибка при проверке изменения яркости')
        #     errors += 1
    else:
        while True:
            QtCore.QCoreApplication.processEvents()
            print(u'\n>>> Введите яркость [0 - 254], для выхода введите 255:',)
            br = resp_0_255()
            if br == 255:
                break
            else:
                rs.set_brit(ser, br)
                time.sleep(wait)
                # print u'\n>>> Яркость установлена правильно? \
                # [1 - да, 0 - нет]:',
                # if resp_yes_no() == 1:
                #     log.info(u'Яркость %s установлена успешно' % br)
                # else:
                #     log.error(u'Яркость %s не установлена' % br)
                #     errors += 1
    return errors


def chk07_power_consumption(ps, max_power, resp_timeout=0.3):
    """ Проверка потребляемой мощности в НКУ
    1) Перебрать напряжения от 22 до 29 В на источнике, измерить ток, вычислить
       мощность, сохранить ее в список
    2) Выбрать из списка максимальную мощность и сравнить с эталоном
    """
    log.info(u'07:[Проверка потребляемой мощности в НКУ]')
    errors = 0
    p = []
    for volts in xrange(22, 29, 1):
        ps.set_votage(volts, resp_timeout)
        v = ps.measure_voltage(resp_timeout)
        i = ps.measure_current(resp_timeout)
        if (v == -1) or (i == -1):
            errors += 1
        else:
            p.append(v * i)
            log.info(u'Напряжение %s, ток %s, мощность %s' % (v, i, v * i))
    if len(p) > 0:
        max_p = max(p)
        if max_p > max_power:
            log.error(u'Потр. мощность %s Вт > %s Вт' % (max_p, max_power))
            errors += 1
        else:
            log.info(u'Потр. мощность %s Вт < %s Вт' % (max_p, max_power))
    else:
        log.error(u'Потр. мощность измерить не удалось')
        errors += 1
    ps.set_votage(27, resp_timeout)
    return errors


def chk08_splashscreen(ser):
    """ Проверка экрана-заставки
    1) Включить экран-заставку
    2) Спросить пользователя все ли ОК
    3) Выключить экран-заставку
    4) Спросить пользователя все ли ОК    
    """
    log.info(u'08:[Проверка экрана-заставки]')
    errors = 0
    log.info(u'Включаю экран-заставку')
    rs.set_splash(ser, u'вкл')
    print(u'\nНа экране отображается заставка? [1 - да, 0 - нет]:',)
    resp = resp_yes_no()
    if resp == 1:
        log.info(u'Проверка вкл. экрана-заставки прошла успешно')
    else:
        log.error(u'Ошибка при проверке вкл. экрана-заставки')
        errors += 1
    log.info(u'Выключаю экран-заставку')
    rs.set_splash(ser, u'выкл')
    print(u'\nНа экране отображается не заставка? [1 - да, 0 - нет]:',)
    resp = resp_yes_no()
    if resp == 1:
        log.info(u'Проверка выкл. экрана-заставки прошла успешно')
    else:
        log.error(u'Ошибка при проверке выкл. экрана-заставки')
        errors += 1
    return errors


def chk09_default(ser232, ser422):
    """ Проверка установки заводских настроек.
    1) Установить настройки 
    2) Сбросить настройки послав пакет SET_DEFAULT
    3) Проверить настроки, должны соответствовать дефолтным.
    """

    def get_sts_out_422(timeout=1):
        start_time = time.clock()
        while time.clock() < start_time + timeout:
            if len(rs422_sts_out_q) > 0:
                sts_out = rs422_sts_out_q.pop()
                return sts_out
        return []

    def get_sts_pmf_232(timeout=1):
        start_time = time.clock()
        while time.clock() < start_time + timeout:
            if len(rs232_sts_pmf_q) > 0:
                sts_pmf = rs232_sts_pmf_q.pop()
                return sts_pmf
        return []

    def compare_with_defaults(sts_out):
        # vidparam и vidinterface определить из статуса нельзя
        global defaults
        if (sts_out[6] & 0x08 == 0) and \
                (((sts_out[6] & 0x02) >> 1) == defaults['mode']) and \
                (sts_out[6] & 0x04 >> 2) == defaults['key_out'] and \
                sts_out[11] == defaults['gainR'] and \
                sts_out[12] == defaults['gainG'] and \
                sts_out[13] == defaults['gainB'] and \
                sts_out[14] == defaults['offsetR'] and \
                sts_out[15] == defaults['offsetG'] and \
                sts_out[16] == defaults['offsetB'] and \
                sts_out[17] == defaults['phase'] and \
                sts_out[18] == defaults['offsetH'] and \
                sts_out[19] == defaults['offsetV'] and \
                sts_out[20] == defaults['brightness'] and \
                sts_out[28] == defaults['topros'] and \
                sts_out[29] == defaults['tavtopovtor'] and \
                (sts_out[6] & 0x10 == defaults['splash']):
            return True
        else:
            return False

    def compare_sts_pmf_with_defaults(STS_PMF):
        ## vidparam и vidinterface определить из статуса нельзя
        global defaults
        pass

    log.info(u'09:[Проверка установки заводских настроек]')
    errors = 0

    rs.set_mode(ser232, u'технологический')

    param = [0xFE, 0x46, 0x46, 0x46, 0x0A, 0x0A, 0x0A, 0x58, 0x00, 0x00,
             0x00, 0x06, 0x0A, 0xFE, 0x00, 0x00]

    rs.set_param(ser232, param)

    rs.set_default(ser232)

    rs422_sts_out_q.clear()
    rs.req_sts(ser422)

    STS_OUT = get_sts_out_422()
    isOK = compare_with_defaults(STS_OUT)
    ## TODO
    log.info(u'Проверка установки заводских настроек прошла успешно')


def chk10_save_settings():
    """ Проверка сохранения настроек в ПЗУ.
    1) Установить настройки
    2) Сохранить настройки послав пакет SAVE_PARAM
    3) Выключить питание
    4) Включить питание
    5) Проверить настройки, должны совпадать с установленными
    """
    pass


def chk11_buttons(ser):
    """ Проверка работы кнопок.
    1) Установить режим "одна кнопка"
    2) Нарисовать окно с 10 кнопками (GUI), вывести его на экран ПМФ
    3) Попросить пользователя понажимать кнопки и написать все ли ОК
    4) Установить режим "много кнопок"
    5) Повторить 2)-3)
    """
    log.info(u'11:[Проверка кнопок]')
    errors = 0
    log.info(u'Режим одна кнопка')
    rs.set_mode(ser, u'технологический')
    rs.set_key_mode(ser, mode=u'одна кнопка')
    key_test(True)
    log.info(u'Режи все кнопки')
    rs.set_key_mode(ser, mode=u'все кнопки')
    key_test(False)
    rs.set_key_mode(ser, mode=u'одна кнопка')
    log.info(u'\nВсе кнопки нажимались без замечаний? [1 - да, 0 - нет]:',)
    resp = resp_yes_no()
    if resp == 1:
        log.info(u'Проверка кнопок в режиме одна кнопка прошла успешно')
    else:
        log.error(u'Ошибка при проверке кнопок в режие одна кнопка')
        errors += 1

    return errors


def chk12_videoswitch():
    """ Проверка переключения видеоканалов.
    1) Подать VGA, LVDS, ETH
    2) Переключать видеоканалы с интервалом 3 с, с полным перебором комбинаций
       всех форматов (включая отсутствие видео в канале и режимы 
       автоопределения)
    3) Попросить пользователя контроллировать и написать все ли ОК
    """
    pass


def chk13_heater_power():
    """ Проверка мощности подогрева
    1) Включить питание
    2) Установить мощности подогрева (00-01-10-01) разрешение (0-1)
    3) Измерить мощности и температуры, сравнить с эталонами
    """
    pass


def chk14_heater_time():
    """ Проверка времени готовности ПМФ на минусе
    1) Включить питание
    2) Установить мощности подогрева (00) разрешение (1)
    3) Запустить таймер
    4) Попросить пользователя контролировать изображение и остановить таймер
       когда картинка отмерзнет
    5) Выключить, повторить для мощности (01)
    """
    pass


def chk15_can():
    """ Проверки специфичные для CAN
    HARTBEAT
    NODEID
    ...
    """
    pass


def chk16_stress():
    """ Проверки полной нагрузки по каналам RS-232, RS-422, CAN
    1) Включаются все видеоканалы на макс. разрешение и скорости.
    2) По всем инф.каналам посылаются пакеты с макс. темпом
    3) Пользователь нажимает кнопки и работает с сенсором
    4) В течении 1-2 минут контроллируется визульно качество работы сенсора,
    нажатие кнопок, картинка на экране ПМФ
    """
    pass


def chk17_corrupted_packets(ser):
    """ Проверка устойчивости к поврежденным пакетам
    """
    log.info(u'17:[Проверка неправильных пакетов]')
    errors = 0
    rs.set_mode(ser, 0x55, bad_mode=True)

    pass  # TODO доделать
    return errors


def chk18_random_flood_rs232(ser):
    """
    Посылаются все пакеты в произвольном порядке с
    максимальным темпом. Пытаемся завалить канал RS-232 или
    обработчик пакетов или еще что-нибудь в ПМФ
    """

    LOOPS = 10
    RAND_LOOPS = 1000

    modes = [u'штатный', u'технологический', u'расширенный']
    k_mode = [u'одна кнопка', u'все кнопки']
    sp_mode = [u'вкл', u'выкл']

    log.debug(u"начало DDoS")
    log.debug(u"разогрев")

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        param = [random.randint(0, 254) for x in xrange(16)]
        rs.set_param(ser, param)

    for i in xrange(LOOPS):
        m = random.randint(0, 2)
        rs.set_mode(ser, modes[m])

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        rs.req_sts(ser)

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        rs.save_param(ser)

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        rs.set_default(ser)

    log.debug(u"рандом")

    for i in xrange(RAND_LOOPS):
        test_pick = random.randint(1, 23)
        if test_pick == 1:
            m = random.randint(0, 2)
            rs.set_mode(ser, modes[m])
        elif test_pick == 2:
            param = [random.randint(0, 254) for x in xrange(16)]
            rs.set_param(ser, param)
        elif test_pick == 3:
            rs.req_sts(ser)
        elif test_pick == 4:
            rs.save_param(ser)
        elif test_pick == 5:
            rs.set_default(ser)
        elif test_pick == 6:
            rs.req_sts_eth1(ser)
        elif test_pick == 7:
            rs.req_sts_eth2(ser)
        elif test_pick == 8:
            rs.req_sts_ovhp(ser)
        elif test_pick == 9:
            rs.req_sts_vglv(ser)
        elif test_pick == 10:
            rs.req_sts_vpipe(ser)
        elif test_pick == 11:
            rs.req_sts_vpr1(ser)
        elif test_pick == 12:
            rs.req_sts_vpr2(ser)
        elif test_pick == 13:
            rs.req_sts_vpr3(ser)
        elif test_pick == 14:
            rs.req_sts_vpr4(ser)
        elif test_pick == 15:
            brit = random.randint(0, 254)
            rs.set_brit(ser, brightness=brit)
        elif test_pick == 16:
            param = [random.randint(0, 254) for x in xrange(2)]
            rs.set_heater(ser, param)
        elif test_pick == 17:
            m = random.randint(0, 1)
            rs.set_key_mode(ser, k_mode[m])
        elif test_pick == 18:
            param = [random.randint(0, 254) for x in xrange(2)]
            rs.set_keys(ser, param)
        elif test_pick == 19:
            param = [random.randint(0, 254) for x in xrange(6)]
            rs.set_ovhp(ser, param)
        elif test_pick == 20:
            m = random.randint(0, 1)
            rs.set_splash(ser, sp_mode[m])
        elif test_pick == 21:
            param = [random.randint(0, 254) for x in xrange(9)]
            rs.set_vga(ser, param)
        elif test_pick == 22:
            param = [random.randint(0, 254) for x in xrange(93)]
            rs.set_vpipe(ser, param)
        elif test_pick == 23:
            param = [random.randint(0, 254) for x in xrange(52)]
            rs.set_eth1(ser, param)
    # после проверки возвращаем настройки в исходное состояние
    rs.set_default(ser)

    # чистим приемные очереди
    rs232_sts_out_q.clear()
    rs232_coord_out_q.clear()
    rs232_key_out_q.clear()
    rs232_key_set_out_q.clear()
    rs232_sts_pmf_q.clear()


def kill_sram(ser, ser422):

    LOOPS = 10
    RAND_LOOPS = 1000

    modes = [u'штатный', u'технологический', u'расширенный']
    k_mode = [u'одна кнопка', u'все кнопки']
    sp_mode = [u'вкл', u'выкл']

    log.debug(u"начало DDoS")

    rs.set_mode(ser, u'расширенный')
    for i in xrange(LOOPS):
        rs.req_sts(ser)

    log.debug(u"рандом")

    for i in xrange(RAND_LOOPS):
#        test_pick = random.randint(1, 23)
#        if test_pick == 1:
##            m = random.randint(0, 2)
##            rs.set_mode(ser, modes[m])
#            pass
#        elif test_pick == 2:
##            param = [random.randint(0, 254) for x in xrange(16)]
##            rs.set_param(ser, param)
#            pass
#        elif test_pick == 3:
#            rs.req_sts(ser)
#        elif test_pick == 4:
#            #rs.save_param(ser)
#            pass
#        elif test_pick == 5:
#            rs.set_default(ser)
#        elif test_pick == 6:
#            rs.req_sts_eth1(ser)
#        elif test_pick == 7:
#            rs.req_sts_eth2(ser)
#        elif test_pick == 8:
#            rs.req_sts_ovhp(ser)
#        elif test_pick == 9:
#            rs.req_sts_vglv(ser)
#        elif test_pick == 10:
#            rs.req_sts_vpipe(ser)
#        elif test_pick == 11:
#            rs.req_sts_vpr1(ser)
#        elif test_pick == 12:
#            rs.req_sts_vpr2(ser)
#        elif test_pick == 13:
#            rs.req_sts_vpr3(ser)
#        elif test_pick == 14:
#            rs.req_sts_vpr4(ser)
#        elif test_pick == 15:
#            brit = random.randint(0, 254)
#            rs.set_brit(ser, brightness=brit)
#        elif test_pick == 16:
##            param = [random.randint(0, 254) for x in xrange(2)]
##            rs.set_heater(ser, param)
#            pass
#        elif test_pick == 17:
#            m = random.randint(0, 1)
#            rs.set_key_mode(ser, k_mode[m])
#        elif test_pick == 18:
#            param = [random.randint(0, 254) for x in xrange(2)]
#            rs.set_keys(ser, param)
#        elif test_pick == 19:
#            param = [random.randint(0, 254) for x in xrange(6)]
#            rs.set_ovhp(ser, param)
#        elif test_pick == 20:
#            m = random.randint(0, 1)
#            rs.set_splash(ser, sp_mode[m])
#        elif test_pick == 21:
#            param = [random.randint(0, 254) for x in xrange(9)]
#            rs.set_vga(ser, param)
#        elif test_pick == 22:
#            param = [random.randint(0, 254) for x in xrange(93)]
#            rs.set_vpipe(ser, param)
#        elif test_pick == 23:
#            param = [random.randint(0, 254) for x in xrange(52)]
#            rs.set_eth1(ser, param)
#            
            
            
        test_pick = random.randint(1, 23)
        if test_pick == 1:
            pass
        elif test_pick == 2:
            pass
        elif test_pick == 3:
            rs.req_sts(ser422)
        elif test_pick == 4:
            pass
        elif test_pick == 5:
            rs.set_default(ser422)
        elif test_pick == 6:
            rs.req_sts_eth1(ser422)
        elif test_pick == 7:
            rs.req_sts_eth2(ser422)
        elif test_pick == 8:
            rs.req_sts_ovhp(ser422)
        elif test_pick == 9:
            rs.req_sts_vglv(ser422)
        elif test_pick == 10:
            rs.req_sts_vpipe(ser422)
        elif test_pick == 11:
            rs.req_sts_vpr1(ser422)
        elif test_pick == 12:
            rs.req_sts_vpr2(ser422)
        elif test_pick == 13:
            rs.req_sts_vpr3(ser422)
        elif test_pick == 14:
            rs.req_sts_vpr4(ser422)
        elif test_pick == 15:
            brit = random.randint(0, 254)
            rs.set_brit(ser422, brightness=brit)
        elif test_pick == 16:
            pass
        elif test_pick == 17:
            m = random.randint(0, 1)
            rs.set_key_mode(ser422, k_mode[m])
        elif test_pick == 18:
            param = [random.randint(0, 254) for x in xrange(2)]
            rs.set_keys(ser422, param)
        elif test_pick == 19:
            param = [random.randint(0, 254) for x in xrange(6)]
            rs.set_ovhp(ser422, param)
        elif test_pick == 20:
            m = random.randint(0, 1)
            rs.set_splash(ser422, sp_mode[m])
        elif test_pick == 21:
            param = [random.randint(0, 254) for x in xrange(9)]
            rs.set_vga(ser422, param)
        elif test_pick == 22:
            param = [random.randint(0, 254) for x in xrange(93)]
            rs.set_vpipe(ser422, param)
        elif test_pick == 23:
            param = [random.randint(0, 254) for x in xrange(52)]
            rs.set_eth1(ser422, param)
            
    # после проверки возвращаем настройки в исходное состояние
    rs.set_default(ser)

    # чистим приемные очереди
    rs232_sts_out_q.clear()
    rs232_coord_out_q.clear()
    rs232_key_out_q.clear()
    rs232_key_set_out_q.clear()
    rs232_sts_pmf_q.clear()




def clear_all_q():
    # чистим приемные очереди
    rs232_coord_out_q.clear()
    rs232_key_out_q.clear()
    rs232_key_set_out_q.clear()
    rs232_sts_out_q.clear()
    rs232_sts_pmf_q.clear()
    rs232_sts_vpipe_q.clear()
    rs232_sts_vpr1_q.clear()
    rs232_sts_vpr2_q.clear()
    rs232_sts_vpr3_q.clear()
    rs232_sts_vpr4_q.clear()
    rs232_sts_vglv_q.clear()
    rs232_sts_eth1_q.clear()
    rs232_sts_eth2_q.clear()
    rs232_sts_ovhp_q.clear()
    rs422_coord_out_q.clear()
    rs422_key_out_q.clear()
    rs422_key_set_out_q.clear()
    rs422_sts_out_q.clear()
    rs422_sts_pmf_q.clear()
    rs422_sts_vpipe_q.clear()
    rs422_sts_vpr1_q.clear()
    rs422_sts_vpr2_q.clear()
    rs422_sts_vpr3_q.clear()
    rs422_sts_vpr4_q.clear()
    rs422_sts_vglv_q.clear()
    rs422_sts_eth1_q.clear()
    rs422_sts_eth2_q.clear()
    rs422_sts_ovhp_q.clear()
    old_xy.clear()
    


def chk_111(ser):
    "ПМФ должен в режиме штатный по RS-232 выдавать OLD_OUT при касании сенсорного экрана"
    log.info(u'Проверка OLD_OUT')
    rs.set_mode(ser, u'штатный')
    time.sleep(0.2)
    clear_all_q()
    while True:    
        if old_xy:
            flag, x, y = old_xy.popleft()
            log.info(u'flag = %s, x = %s, y = %s' % (flag, x, y))
            if flag == 255: break 


def chk_112(ser):
    log.info(limiter)
    log.info(u'112 ПМФ должен в режиме штатный по RS-232 выдавать STS_OUT при получении SET_MODE')
    rs232_sts_out_q.clear()
    rs.set_mode(ser, u'штатный')
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x0A) == 0:
            log.info(u'установлен признак режима штатный')
        else:
            log.info(u'не установлен признак режима штатный')
    else:
        log.info(u'пакет STS_OUT не получен')
    rs232_sts_out_q.clear()
    rs.set_mode(ser, u'штатный')
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x0A) == 0:
            log.info(u'Установлен признак режима штатный')
        else:
            log.info(u'Не установлен признак режима штатный')        
    else:
        log.info(u'Пакет STS_OUT не получен')        


def chk_113(ser):
    log.info(limiter)
    log.info(u'113 ПМФ должен в режиме штатный по RS-232 принимать SET_MODE, устанавливать соответствующий режим работы и выдавать STS_OUT')
    chk01_set_mode(ser)


def chk_114(ser):
    log.info(limiter)
    log.info(u'114 ПМФ должен в режиме технологический по RS-232 выдавать KEY_OUT при нажатии на клавиши (в соответствующем режиме выдачи клавиш)')
    chk11_buttons(ser)


def chk_116(ser):
    log.info(limiter)
    log.info(u'116 ПМФ должен в режиме технологический по RS-232 выдавать COORD_OUT при касании сенсорного экрана')
    rs.set_mode(ser, u'технологический')
    log.info(u'touch the screen...')
    coord_out = rx_specific_packet('COORD_OUT', '232', 300)
    if coord_out:
        log.info(u'coord_out = %s' % coord_out)
    else:
        log.error(u'coord_out не принят')


def chk_117(ser):
    log.info(limiter)
    log.info(u'117 ПМФ должен в режиме технологический по RS-232 выдавать KEY_SET_OUT при нажатии на клавиши (в соответствующем режиме выдачи клавиш)')
    rs.set_mode(ser, u'технологический')
    rs.set_key_mode(ser, u'все кнопки')
    key_set_out = rx_specific_packet('KEY_SET_OUT', '232', 300)
    if key_set_out:
        log.info(u'key_set_out = %s' % key_set_out)
    else:
        log.error(u'key_set_out не принят')
        

def chk_118(ser):
    log.info(limiter)
    log.info(u'118 ПМФ должен в режиме технологический по RS-232 принимать REQ_STS и выдавать STS_OUT')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.2)
    clear_all_q()
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_119(ser):
    log.info(limiter)
    log.info(u'119 ПМФ должен в режиме технологический по RS-232 принимать SET_PARAM и выдавать STS_OUT')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.2)
    clear_all_q()
    param = [0xFE, 0x60, 0x60, 0x60, 0x1A, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
    rs.set_param(ser, param)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_120(ser):
    log.info(limiter)
    log.info(u'120 ПМФ должен в режиме технологический по RS-232 принимать SET_DEFAULT и выдавать STS_OUT')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.2)
    clear_all_q()
    rs.set_default(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_121(ser):
    log.info(limiter)
    log.info(u'121 ПМФ должен в режиме технологический по RS-232 принимать SAVE_PARAM и выдавть STS_OUT')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.2)
    clear_all_q()
    rs.save_param(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_122(ser):
    log.info(limiter)
    log.info(u'122 ПМФ должен в режиме технологический по RS-232 принимать SET_MODE и выдавать STS_OUT')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.2)
    clear_all_q()
    rs.set_mode(ser, u'технологический')
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_123(ser):
    log.info(limiter)
    log.info(u'123 ПМФ должен в режиме технологический по RS-232 принимать SET_BRIT')
    brightness = 0
    rs.set_mode(ser, u'технологический')
    while brightness < 255:
        rs.set_brit(ser, brightness)
        time.sleep(0.01)
        brightness += 1


def chk_124(ser):
    log.info(limiter)
    log.info(u'124 ПМФ должен в режиме технологический по RS-232 принимать SET_KEY_MODE')
    rs.set_mode(ser, u'технологический')
    rs.set_key_mode(ser, u'одна кнопка')
    rs.req_sts(ser)
    sts = rx_specific_packet('STS_OUT', '232')
    log.info(u'одна кнопка = %s' % sts)
    rs.set_key_mode(ser, u'все кнопки')
    rs.req_sts(ser)
    sts = rx_specific_packet('STS_OUT', '232')
    log.info(u'все кнопки = %s' % sts)
    time.sleep(1)
    rs.set_key_mode(ser, u'одна кнопка')


def chk_125(ser):
    log.info(limiter)
    log.info(u'125 ПМФ должен в режиме расширенный по RS-232 выдавать KEY_OUT при нажатии на клавиши (в соответствующем режиме выдачи клавиш)')
    rs.set_mode(ser, u'расширенный')
    rs.set_key_mode(ser, u'одна кнопка')
    key_test(one_point = True)
    

def chk_126(ser):
    log.info(limiter)
    log.info(u'126 ПМФ должен в режиме расширенный по RS-232 выдавать COORD_OUT при касании сенсорного экрана')
    rs.set_mode(ser, u'расширенный')
    coord_drawer_232()
    

def chk_127(ser):
    log.info(limiter)
    log.info(u'127 ПМФ должен в режиме расширенный по RS-232 выдавать KEY_SET_OUT при нажатии на клавиши (в соответствующем режиме выдачи клавиш)')
    rs.set_mode(ser, u'расширенный')
    rs.set_key_mode(ser, u'все кнопки')
    key_test(one_point = False)
    rs.set_key_mode(ser, u'одна кнопка')
    

def chk_128(ser):
    log.info(limiter)
    log.info(u'128 ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS и выдавать STS_PMF')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.req_sts(ser)
    sts_pmf = rx_specific_packet('STS_PMF', '232')
    if sts_pmf:
        log.info(u'STS_PMF = %s' % sts_pmf)
    else:
        log.error(u'Пакет STS_PMF не получен')
    clear_all_q()


def chk_129(ser):
    log.info(limiter)
    log.info(u'129 МФ должен в режиме расширенный по RS-232 принимать SET_PARAM и выдавать STS_OUT')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    
    vparam = 0xFE
    Ramp = 0x50
    Gamp = 0x50
    Bamp = 0x50
    Roff = 0x11
    Goff = 0x11
    Boff = 0x11
    Phase = 0x66
    Hoff = 0x00
    Voff = 0x00
    Topros = 0x06
    Tauto = 0x07
    vidif = 0xFE    
    
    param = [vparam, Ramp, Gamp, Bamp, Roff, Goff, Boff, Phase, Hoff, Voff, 0x00, Topros, Tauto, vidif, 0x00, 0x00]
    rs.set_param(ser, param)
    sts_out = rx_specific_packet('STS_OUT', '232')


    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
        if (Ramp == sts_out[11] and
        Gamp == sts_out[12] and 
        Bamp == sts_out[13] and
        Roff == sts_out[14] and
        Goff == sts_out[15] and
        Boff == sts_out[16] and
        Phase == sts_out[17] and
        Hoff == sts_out[18] and
        Voff == sts_out[19] and
        Topros == sts_out[28] and
        Tauto == sts_out[29]):
            log.info(u'параметры совпадают')
        else:
            log.error(u'Параметры не совпадают')
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_130(ser):
    log.info(limiter)
    log.info(u'130 ПМФ должен в режиме расширенный по RS-232 принимать SET_DEFAULT и выдавать STS_OUT')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.set_default(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_131(ser):
    log.info(limiter)
    log.info(u'131 ПМФ должен в режиме расширенный по RS-232 принимать SAVE_PARAM и выдавать STS_OUT')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.save_param(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        log.info(u'STS_OUT = %s' % sts_out)
    else:
        log.error(u'Пакет STS_OUT не получен')
    clear_all_q()


def chk_132(ser):
    log.info(limiter)
    log.info(u'132 ПМФ должен в режиме расширенный по RS-232 принимать SET_MODE и выдавать STS_PMF')
    clear_all_q()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232')
    if sts_pmf:
        log.info(u'STS_PMF = %s' % sts_pmf)
    else:
        log.error(u'Пакет STS_PMF не получен')
    clear_all_q()
    

def chk_133(ser):
    log.info(limiter)
    log.info(u'133 ПМФ должен в режиме расширенный по RS-232 принимать SET_BRIT')
    brightness = 0
    rs.set_mode(ser, u'расширенный')
    while brightness < 255:
        rs.set_brit(ser, brightness)
        time.sleep(0.01)
        brightness += 1


def chk_134(ser):
    log.info(limiter)
    log.info(u'134 ПМФ должен в режиме расширенный по RS-232 принимать SET_KEY_MODE')
    rs.set_mode(ser, u'расширенный')
    rs.set_key_mode(ser, u'одна кнопка')
    rs.req_sts(ser)
    sts = rx_specific_packet('STS_PMF', '232')
    log.info(u'одна кнопка = %s' % sts)
    rs.set_key_mode(ser, u'все кнопки')
    rs.req_sts(ser)
    sts = rx_specific_packet('STS_PMF', '232')
    log.info(u'все кнопки = %s' % sts)
    rs.set_key_mode(ser, u'одна кнопка')
        

def chk_135(ser):
    log.info(limiter)
    log.info(u'135 ПМФ должен в режиме расширенный по RS-232 принимать SET_VGA и выдавать STS_VGLV')
    rs.set_mode(ser, u'расширенный')    
    data = [0x11, 0x22 ,0x33, 0x44, 0x55, 0x66, 0x77, 0x00, 0x00]
    rs.set_vga(ser, data)
    sts_vglv = rx_specific_packet('STS_VGLV', '232')
    if sts_vglv:
        log.info(u'STS_VGLV = %s' % sts_vglv)
    else:
        log.error(u'Пакет STS_VGLV не получен')
    clear_all_q()


def chk_136(ser):
    log.info(limiter)
    log.info(u'136 МФ должен в режиме расширенный по RS-232 принимать SET_KEYs и выдавать STS_PMF')
    rs.set_mode(ser, u'расширенный')
    Top = random.randint(5, 254)
    Tauto = random.randint(5, 254)
    data = [Top, Tauto]
    rs.set_keys(ser, data)
    sts = rx_specific_packet('STS_PMF', '232')
    if sts:
        log.info(u'STS_PMF = %s' % sts)
        if sts[39] == Top and sts[40] == Tauto:
            log.info(u'Параметры в STS_PMF соответствуют переданным в SET_KEYS')
        else:
            log.error(u'Параметры в STS_PMF не соответствуют переданным в SET_KEYS')
    else:
        log.error(u'Пакет STS_PMF не получен')
    clear_all_q()


def chk_137(ser):
    log.info(limiter)
    log.info(u'137 ПМФ должен в режиме расширенный по RS-232 принимать SET_VPIPE и выдавать STS_VPIPE')
    rs.set_mode(ser, u'расширенный')
    data = [i for i in xrange(0, 93)]
    rs.set_vpipe(ser, data)
    sts = rx_specific_packet('STS_VPIPE', '232')
    if sts:
        log.info(u'STS_VPIPE = %s' % sts)
    else:
        log.error(u'Пакет STS_VPIPE не получен')
    clear_all_q()


def chk_144(ser):
    log.info(limiter)
    log.info(u'144 ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_ETH1 и выдавать STS_ETH1')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.req_sts_eth1(ser)
    sts_eth1 = rx_specific_packet('STS_ETH1', '232')
    if sts_eth1:
        log.info(u'STS_ETH1 = %s' % sts_eth1)
    else:
        log.error(u'Пакет STS_ETH1 не получен %s' % sts_eth1)
    clear_all_q()


def chk_145(ser):
    log.info(limiter)
    log.info(u'145 ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_ETH2 и выдавать STS_ETH2')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.req_sts_eth2(ser)
    sts_eth2 = rx_specific_packet('STS_ETH2', '232')
    if sts_eth2:
        log.info(u'STS_ETH2 = %s' % sts_eth2)
    else:
        log.error(u'Пакет STS_ETH2 не получен')
    clear_all_q()


def chk_146(ser):
    log.info(limiter)
    log.info(u'146 ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_VPr1 и выдавать STS_VPr1')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.req_sts_vpr1(ser)
    sts_vpr1 = rx_specific_packet('STS_VPr1', '232')
    if sts_vpr1:
        log.info(u'STS_VPr1 = %s' % sts_vpr1)
    else:
        log.error(u'Пакет STS_VPr1 не получен')
    clear_all_q()


def chk_147(ser):
    log.info(limiter)
    log.info(u'147 ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_VPr2 и выдавать STS_VPr2')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()    
    rs.req_sts_vpr2(ser)
    sts_vpr2 = rx_specific_packet('STS_VPr2', '232')
    if sts_vpr2:
        log.info(u'STS_VPr2 = %s' % sts_vpr2)
    else:
        log.error(u'Пакет STS_VPr2 не получен')
    clear_all_q()


def chk_148(ser):
    log.info(limiter)
    log.info(u'148 Требование: ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_VPr3 и выдавать STS_VPr3')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()    
    rs.req_sts_vpr3(ser)
    sts_vpr3 = rx_specific_packet('STS_VPr3', '232')
    if sts_vpr3:
        log.info(u'STS_VPr3 = %s' % sts_vpr3)
    else:
        log.error(u'Пакет STS_VPr3 не получен')
    clear_all_q()


def chk_149(ser):
    log.info(limiter)
    log.info(u'149 Требование: ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_VPr4 и выдавать STS_VPr4')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()    
    rs.req_sts_vpr4(ser)
    sts_vpr4 = rx_specific_packet('STS_VPr4', '232')
    if sts_vpr4:
        log.info(u'STS_VPr4 = %s' % sts_vpr4)
    else:
        log.error(u'Пакет STS_VPr4 не получен')
    clear_all_q()


def chk_150(ser):
    log.info(limiter)
    log.info(u'150 ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_VPIPE и выдавать STS_VPIPE')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.req_sts_vpipe(ser)
    sts_vpipe = rx_specific_packet('STS_VPIPE', '232')
    if sts_vpipe:
        log.info(u'STS_VPIPE = %s' % sts_vpipe)
    else:
        log.error(u'Пакет STS_VPIPE не получен')
    clear_all_q()


def chk_151(ser):
    log.info(limiter)
    log.info(u'151 ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_VGLV и выдавать STS_VGLV')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    clear_all_q()
    rs.req_sts_vglv(ser)
    sts_vglv = rx_specific_packet('STS_VGLV', '232')
    if sts_vglv:
        log.info(u'STS_VGLV = %s' % sts_vglv)
    else:
        log.error(u'Пакет STS_VGLV не получен')
    clear_all_q()


def chk_152(ser):
    log.info(limiter)
    log.info(u'ПМФ должен в режиме расширенный по RS-232 принимать REQ_STS_OVHP и выдавать STS_OVHP')
    rs.set_mode(ser, u'расширенный')
    rs.req_sts_ovhp(ser)
    sts_ovhp = rx_specific_packet('STS_OVHP', '232')
    if sts_ovhp:
        log.info(u'STS_OVHP = %s' % sts_ovhp)
    else:
        log.error(u'Пакет STS_OVHP не получен')
    clear_all_q()


def chk_153(ser):
    log.info(limiter)
    log.info(u'153 ПМФ должен в режиме расширенный по RS-232 принимать SET_SPLASH и выдавать STS_PMF')
    rs.set_mode(ser, u'расширенный')
    rs.set_splash(ser, u'вкл')
    sts_pmf = rx_specific_packet('STS_PMF', '232')
    if sts_pmf:
        log.info(u'STS_PMF = %s' % sts_pmf)
    else:
        log.error(u'Пакет STS_PMF не получен')
    clear_all_q()
    rs.set_splash(ser, u'выкл')
    sts_pmf = rx_specific_packet('STS_PMF', '232')
    if sts_pmf:
        log.info(u'STS_PMF = %s' % sts_pmf)
    else:
        log.error(u'Пакет STS_PMF не получен')
    clear_all_q()


def chk_154(ser):
    log.info(limiter)
    log.info(u'154 ПМФ должен в режиме расширенный по RS-232 принимать SET_HEATER и выдавать STS_PMF')
    rs.set_mode(ser, u'расширенный')
    rs.set_heater(ser, [0, 0])
    sts_pmf = rx_specific_packet('STS_PMF', '232')
    if sts_pmf:
        log.info(u'STS_PMF = %s' % sts_pmf)
    else:
        log.error(u'Пакет STS_PMF не получен')
    clear_all_q()


def chk_155(ser):
    log.info(limiter)
    log.info(u'155 ПМФ должен в режиме расширенный по RS-232 принимать SET_OVHP и выдавать STS_OVHP')
    rs.set_mode(ser, u'расширенный')
    rs.set_ovhp(ser, [0, 0, 0, 0, 0, 0])
    sts_ovhp = rx_specific_packet('STS_OVHP', '232')
    if sts_ovhp:
        log.info(u'STS_OVHP = %s' % sts_ovhp)
    else:
        log.error(u'Пакет STS_OVHP не получен')
    clear_all_q()


def chk_156(ser):
    log.info(limiter)
    log.info(u'156 ПМФ должен в режиме расширенный по RS-232 принимать SET_ID')
    rs.set_mode(ser, u'расширенный')
    sts = rx_specific_packet('STS_PMF', '232')
    if sts:
        ID = sts[4]
        SN = [sts[15], sts[16], sts[17], sts[18], sts[19], sts[20], sts[21], sts[22], sts[23]]
        log.info(u'ID = %s, SN = %s' % (ID, SN))
        if ID == PMF_ID: log.info(u'Pass. Идентификатор ПМФ считанный и ожидаемый совпали')
        else: log.info(u'Fail. Идентификатор ПМФ считанный и ожидаемый не совпали!')
        if SN == PMF_SN: log.info(u'Pass. Заводской номер ПМФ считанный и ожидаемый совпали')
        else: log.info(u'Fail. Заводской номер ПМФ считанный и ожидаемый не совпали!')
    else:
        log.error(u'Пакет STS_PMF не получен')
    new_data = [0x11, 48, 48, 48, 51, 0, 0, 0, 0, 0]
    rs.set_ID(ser, new_data)
    clear_all_q()
    rs.set_mode(ser, u'расширенный')
    NEW_ID = 0x11
    NEW_SN = [48, 48, 48, 51, 0, 0, 0, 0, 0]
    sts = rx_specific_packet('STS_PMF', '232')
    if sts:
        ID = sts[4]
        SN = [sts[15], sts[16], sts[17], sts[18], sts[19], sts[20], sts[21], sts[22], sts[23]]
        log.info(u'ID = %s, SN = %s' % (ID, SN))
        if ID == NEW_ID: log.info(u'Pass. Идентификатор ПМФ считанный и ожидаемый совпали')
        else: log.info(u'Fail. Идентификатор ПМФ считанный и ожидаемый не совпали!')
        if SN == NEW_SN: log.info(u'Pass. Заводской номер ПМФ считанный и ожидаемый совпали')
        else: log.info(u'Fail. Заводской номер ПМФ считанный и ожидаемый не совпали!')
    else:
        log.error(u'Пакет STS_PMF не получен')
    clear_all_q()


def chk_157(psh_ser):
    """
    Требование: ПМФ должна переходить в штатный режим работы по включению
    Источник: 1_3.3
    """
    ps = psh.psh3610(psh_ser)
    ps.setup(27, 2, 30, 0, 1, 0.5)
    time.sleep(3)



def chk_158(ser):
    log.info(limiter)
    log.info(u'158 ПМФ должна устанавливать режим работы по команде из пакета SET_MODE по RS-232')
    chk01_set_mode(ser)


def chk_161(ser):
    log.info(limiter)
    log.info(u'161 ПМФ должна выдавать OLD_OUT во время касания сенсорного экрана в режиме штатный')
    rs.set_mode(ser, u'штатный')
    clear_all_q()
    while 1:
        if old_xy:
            old_out = old_xy.pop()
            f = old_out[0]
            x = old_out[1]
            y = old_out[2]
            log.info(u'OLD_OUT: F = %s, X = %s, Y = %s' % (f,x,y))
            if x > 950 and y > 950: break

        
def chk_162(ser):
    log.info(limiter)
    log.info(u'162 ПМФ должна по прекращению касания сенсора выдавать пакет OLD_OUT с флагом прекращения касания (байт 1 равен Ffh) в режиме штатный')
    rs.set_mode(ser, u'штатный')
    time.sleep(0.2)
    clear_all_q()
    while 1:
        if old_xy:
            old_out = old_xy.pop()
            f = old_out[0]
            x = old_out[1]
            y = old_out[2]
            log.info(u'OLD_OUT: F = %s, X = %s, Y = %s' % (f,x,y))
            if (f == 255):
                log.info(u'OLD_OUT получен признак отжатия')
            if x > 950 and y > 950: break


def chk_168(ser):
    log.info(limiter)
    log.info(u'168 ПМФ должен выдавать свой идентификатор в STS_OUT')
    clear_all_q()
    rs.set_mode(ser, u'технологический')
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if sts_out[4] == exp_pmf_id:
            log.info('ID pass = %s' % sts_out[4])
        else:
            log.error(u'ID fail = %s' % sts_out[4])
    else:
        log.error(u'Пакет STS_OUT не получен')        

def chk_169(ser):
    log.info(limiter)
    log.info(u'169 ПМФ должен выдавать версию ПО в STS_OUT')
    clear_all_q()
    rs.set_mode(ser, u'технологический')
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if sts_out[5] == exp_soft_id:
            log.info('SOFT ID pass')

def chk_170(ser):
    log.info(limiter)
    log.info(u'170 ПМФ должен выдавать режим ПМФ в STS_OUT')
    clear_all_q()
    rs.set_mode(ser, u'технологический')
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x0A) == 2:
            log.info('pass')


def chk_171(ser):
    log.info(limiter)
    log.info(u'171 ПМФ должен выдавать режим передачи клавиш в STS_OUT')
    clear_all_q()
    rs.set_mode(ser, u'технологический')
    rs.set_key_mode(ser, u'одна кнопка')
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x04) == 0:
            log.info('pass')
        else:
            log.error('fail %s' % sts_out)
            
    rs.set_key_mode(ser, u'все кнопки')
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x04) == 4:
            log.info('pass')
        else:
            log.error('fail %s' % sts_out)
            
    rs.set_key_mode(ser, u'одна кнопка')
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x04) == 0:
            log.info('pass')
        else:
            log.error('fail %s' % sts_out)
            

def chk_172(ser):
    log.info(limiter)
    log.info(u'172 ПМФ должен выдавать признак включения экрана-заставки в STS_OUT')
    clear_all_q()
    rs.set_mode(ser, u'технологический')
    rs.set_splash(ser, u'вкл')
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x10) == 0x10:
            log.info('pass')
        else:
            log.error('fail %s' % sts_out)
    rs.set_splash(ser, u'выкл')
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if (sts_out[6] & 0x10) == 0:
            log.info('pass')
        else:
            log.error('fail %s' % sts_out)


def chk_173(ser):
    log.info(limiter)
    log.info(u'173 ПМФ должен выдавать коэффициент усиления R в STS_OUT')
    rs.set_mode(ser, u'технологический')
    R = 0
    while R < MAX_VAL:
        param = [0xFE, R, 0x60, 0x60, 0x1A, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xFE, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        #time.sleep(0.1)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[11] == R:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (R, sts_out[11]))
        R += 1


def chk_174(ser):
    log.info(limiter)
    log.info(u'174 ПМФ должен выдавать коэффициент усиления G в STS_OUT')
    rs.set_mode(ser, u'технологический')
    G = 0
    while G < MAX_VAL:
        param = [0xFE, 0x60, G, 0x60, 0x1A, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[12] == G:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (G, sts_out[12]))
        G += 1


def chk_175(ser):
    log.info(limiter)
    log.info(u'175 ПМФ должен выдавать коэффициент усиления B в STS_OUT')
    rs.set_mode(ser, u'технологический')
    B = 0
    while B < MAX_VAL:
        param = [0xFE, 0x60, 0x60, B, 0x1A, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[13] == B:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (B, sts_out[13]))
        B += 1
        

def chk_176(ser):
    log.info(limiter)
    log.info(u'176 ПМФ должен выдавать смещение R в STS_OUT')
    rs.set_mode(ser, u'технологический')
    R = 0
    while R < MAX_VAL:
        param = [0xFE, 0x60, 0x60, 0x60, R, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[14] == R:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (R, sts_out[14]))
        R += 1


def chk_177(ser):
    log.info(limiter)
    log.info(u'177 ПМФ должен выдавать смещение G в STS_OUT')
    rs.set_mode(ser, u'технологический')
    G = 0
    while G < MAX_VAL:
        param = [0xFE, 0x60, 0x60, 0x60, 0x1A, G, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[15] == G:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (G, sts_out[15]))
        G += 1


def chk_178(ser):
    log.info(limiter)
    log.info(u'178 ПМФ должен выдавать смещение B в STS_OUT')
    rs.set_mode(ser, u'технологический')
    B = 0
    while B < MAX_VAL:
        param = [0xFE, 0x60, 0x60, 0x60, 0x1A, 0x1A, B, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[16] == B:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (B, sts_out[16]))
        B += 1


def chk_179(ser):
    log.info(limiter)
    log.info(u'179 ПМФ должен выдавать фазу тактовой частоты в STS_OUT')
    rs.set_mode(ser, u'технологический')
    PHASE = 0
    while PHASE < MAX_VAL:
        param = [0xFE, 0x60, 0x60, 0x60, 0x1A, 0x1A, 0x1A, PHASE, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[17] == PHASE:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (PHASE, sts_out[17]))
        PHASE += 1


def chk_180(ser):
    log.info(limiter)
    log.info(u'180 ПМФ должен выдавать смещение по горизонтали в STS_OUT')
    rs.set_mode(ser, u'технологический')
    SHIFT_H = 0
    while SHIFT_H < MAX_VAL:
        param = [0xFE, 0x60, 0x60, 0x60, 0x1A, 0x1A, 0x1A, 0x68, SHIFT_H, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[18] == SHIFT_H:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (SHIFT_H, sts_out[18]))
        SHIFT_H += 1


def chk_181(ser):
    log.info(limiter)
    log.info(u'181 ПМФ должен выдавать смещение по вертикали в STS_OUT')
    rs.set_mode(ser, u'технологический')
    SHIFT_V = 0
    while SHIFT_V < MAX_VAL:
        param = [0xFE, 0x60, 0x60, 0x60, 0x1A, 0x1A, 0x1A, 0x68, 0x00, SHIFT_V, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
        rs.set_param(ser, param)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[19] == SHIFT_V:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (SHIFT_V, sts_out[19]))
        SHIFT_V += 1


def chk_182(ser):
    log.info(limiter)
    log.info(u'182 ПМФ должен выдавать текущее значение яркости в STS_OUT')
    rs.set_mode(ser, u'технологический')
    BRIT = 0
    while BRIT < MAX_VAL:
        rs.set_brit(ser, BRIT)
        time.sleep(delay_sts_readback)
        clear_all_q()
        rs.req_sts(ser)
        sts_out = rx_specific_packet('STS_OUT', '232')
        if sts_out:
            if sts_out[20] == BRIT:
                log.info('pass')
            else:
                log.error('fail %s <> %s' % (BRIT, sts_out[20]))
        BRIT += 1


def chk_195(ser):
    log.info(limiter)
    log.info(u'195 ПМФ должен вести учет времени наработки и выдавать его в STS_OUT')
    time_delay = 10
    clear_all_q()    
    rs.set_mode(ser, u'технологический')
    sts_out = rx_specific_packet('STS_OUT', '232')
    T1 = sts_out[24] + (sts_out[25] << 7) + (sts_out[26] << 14) + (sts_out[27] << 21)
    log.info(T1)
    time.sleep(time_delay)
    rs.set_mode(ser, u'технологический')
    sts_out = rx_specific_packet('STS_OUT', '232')
    T2 = sts_out[24] + (sts_out[25] << 7) + (sts_out[26] << 14) + (sts_out[27] << 21)
    if (time_delay/60 - 1) <= (T2 - T1) <= (time_delay/60 + 1):
        log.info(u'Pass T2 = %s, T1 = %s' % (T2, T1))
    else:
        log.error(u'Fail T2 = %s, T1 = %s' % (T2, T1))
    

def chk_237(ser):
    log.info(limiter)
    log.info(u'237 ПМФ должен в STS_PMF выдавать время наработки')
    time_delay = 10
    clear_all_q()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232')
    T1 = (sts_pmf[31] + (sts_pmf[32] << 8) + (sts_pmf[33] << 16) + (sts_pmf[34] << 24) + (sts_pmf[35] << 32)) * 0.25
    log.info(T1)
    time.sleep(time_delay)
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232')
    T2 = (sts_pmf[31] + (sts_pmf[32] << 8) + (sts_pmf[33] << 16) + (sts_pmf[34] << 24) + (sts_pmf[35] << 32)) * 0.25
    log.info(T2)
    if (time_delay - 1) <= (T2 - T1) <= (time_delay + 1):
        log.info(u'Pass T2 = %s, T1 = %s' % (T2, T1))
    else:
        log.error(u'Fail T2 = %s, T1 = %s' % (T2, T1))


def chk_276(ser):
    log.info(limiter)
    log.info(u'276 ПМФ должен игнорировать пакеты с ошибочной контрольной суммой')

    def hex2bytes(string):
        return binascii.unhexlify(string.replace(' ', ''))

    def cs_calc_bad(data):
        CS = 0
        for each in data:
            CS = CS ^ each
        return CS + 1
    
    def send_packet(ser, data):
        CS = cs_calc_bad(data)
        send = 'FF FF '
        for d in data:
            send += "%0.2X " % d
        send += "%0.2X" % CS
        ser.write(hex2bytes(send))
    
    rs.set_mode(ser, u'технологический')
    data = [0xFE, 0x77, 0x77, 0x77, 0x1A, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
    rs.set_param(ser, data)
    time.sleep(delay_sts_readback)
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    log.info(sts_out)    
    data = [0xFE, 0x55, 0x55, 0x55, 0x1A, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]    
    data.insert(0, 0xC2)
    send_packet(ser, data)
    time.sleep(delay_sts_readback)
    clear_all_q()
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if sts_out[11] == 0x55:
            log.error('fail %s' % sts_out)
        else:
            log.info('pass')


def chk_277(ser):
    log.info(limiter)
    log.info(u'277 ПМФ должен игнорироват пакеты с неправильным заголовком')

    def hex2bytes(string):
        return binascii.unhexlify(string.replace(' ', ''))

    def cs_calc_bad(data):
        CS = 0
        for each in data:
            CS = CS ^ each
        return CS
    
    def send_packet(ser, data):
        CS = cs_calc_bad(data)
        send = 'FF FF '
        for d in data:
            send += "%0.2X " % d
        send += "%0.2X" % CS
        ser.write(hex2bytes(send))
        log.info(u'направляем в ПМФ %s' % send)
    
    data = [0xFE, 0x55, 0x55, 0x55, 0x1A, 0x1A, 0x1A, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]    
    data.insert(0, 0xFE)
    send_packet(ser, data)
    time.sleep(delay_sts_readback)
    clear_all_q()
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')


def chk_279(ser):
    log.info(limiter)
    log.info(u'279 ПМФ должна не менять значение параметра если была попытка установки недопустимого значения')
    rs.set_mode(ser, u'технологический')
    param = [0xFE, 0x07, 0x09, 0xFF, 0x10, 0x10, 0x10, 0x68, 0x00, 0x00, 0x00, 0x07, 0x2A, 0xF0, 0x00, 0x00]
    rs.set_param(ser, param)
    time.sleep(delay_sts_readback)
    clear_all_q()
    rs.req_sts(ser)
    sts_out = rx_specific_packet('STS_OUT', '232')
    if sts_out:
        if sts_out[11] == 0xFF:
            log.error('fail')
        else:
            log.info('pass STS_OUT = %s' % sts_out)



def checklist(ser, spsh='COM1'):
    """ Последовательный вызов указанных тестов 
    """
    params = (exp_pmf_id, exp_soft_id, exp_hard_id, exp_serial_id,
              exp_temp_MD, exp_temp_MI)
    errors = 0
    ps = psh.psh3610(spsh)
    log.info(u'Начало теста')
    ps.setup(27, 2, 30, 0, 1, 0.5)
    errors += chk00_start_time(ser, 1)
    errors += chk01_set_mode(ser)
    errors += chk02_stats(ser, *params)
    errors += chk03_runtime(ser, 1)
    errors += chk04_vga_resolution()
    errors += chk05_toprosa(ser, 1, 3)
    errors += chk06_brightness(ser, manual=False)
    errors += chk07_power_consumption(ps, max_power=30, resp_timeout=0.3)
    errors += chk08_splashscreen(ser)
    ps.setup(27, 2, 30, 0, 0, 0.5)
    log.info(u'Конец теста')
    log.info(u'Количество ошибок: %s' % errors)
    return errors
    
    
#def temperature_reading(ser):
#    rs.set_mode(ser, u'расширенный')
#    time.sleep(0.2)
#    rs.set_heater(ser, [0x00, 0x01])
#    clear_all_q()
#    while 1:
#        rs.req_sts(ser)
#        time.sleep(2)
#        sts = rx_specific_packet('STS_PMF', '232')        
#        
#    #    print('raw ts %s' % sts[24])
#    #    print('raw mi %s %s' % (sts[25], sts[26]))
#    
#        tmp_ts_raw = sts[24]
#        tmp_mi_raw = sts[25] + ((sts[26] << 7) & 0x80)
#        
#    #    print(tmp_ts_raw)
#    #    print(tmp_mi_raw)
#        
#        if (tmp_ts_raw & 0x80) == 0x80:
#            tmp_ts = tmp_ts_raw - 256
#        else:
#            tmp_ts = tmp_ts_raw
#            
#        if (tmp_mi_raw & 0x80) == 0x80:
#            tmp_mi = tmp_mi_raw - 256
#        else:
#            tmp_mi = tmp_mi_raw
#        
#        print('ts = %s  mi = %s' % (tmp_ts, tmp_mi))
#
#    pass

def temperature_reading(ser):
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.2)
    rs.set_heater(ser, [0x00, 0x01])
    clear_all_q()
    while 1:
        rs.req_sts(ser)
        time.sleep(2)
        sts = rx_specific_packet('STS_PMF', '232')        
        
        tmp_ts_raw = sts[24]
        tmp_mi_raw = sts[25] + ((sts[26] << 7) & 0x80)
        
        if (tmp_ts_raw & 0x80) == 0x80:
            tmp_ts = tmp_ts_raw - 256
        else:
            tmp_ts = tmp_ts_raw
            
        if (tmp_mi_raw & 0x80) == 0x80:
            tmp_mi = tmp_mi_raw - 256
        else:
            tmp_mi = tmp_mi_raw
        
        print('ts = %s  mi = %s' % (tmp_ts, tmp_mi))


def measure_luminance():
    R=110
    window = gr.GraphWin("PMF-6.0 Touch Screen", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    border = 0
    brdr = gr.Rectangle(gr.Point(border, border),gr.Point(1023 - border,
                        767 - border))

    brdr.setOutline(cWhite)
    brdr.draw(window)

    dot = gr.Circle(gr.Point(256, 192), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(512, 384), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(768, 192), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(256, 576), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(768, 576), R)
    dot.setFill(cWhite)
    dot.draw(window)

    ln = gr.Line(gr.Point(256, 0), gr.Point(256, 767))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(512, 0), gr.Point(512, 767))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(768, 0), gr.Point(768, 767))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(0, 192), gr.Point(1023, 192))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(0, 384), gr.Point(1023, 384))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(0, 576), gr.Point(1023, 576))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
    window.close()


def pmf32_reg_pwrcodes(ser, glass_resistance, pmin, pmax, ton, toff, time_pmax):

    Vmax = 19.85
    R = glass_resistance
    Pmin = pmin
    Pmax = pmax
    T_ON = ton
    T_OFF = toff
    
    assert (T_ON < T_OFF), 'temperature limits are wrong'
    assert (0 <= time_pmax <= 254), 'time pmax is wrong'

    t_on_hex = T_ON & 0xff
    t_off_hex = T_OFF & 0xff
        
    #print(t_on_hex, t_off_hex)
        
    t_on_hex_U8b_2B_l = t_on_hex & 0x7F
    t_on_hex_U8b_2B_h = (t_on_hex & 0x80) >> 7
    
    t_off_hex_U8b_2B_l = t_off_hex & 0x7F
    t_off_hex_U8b_2B_h = (t_off_hex & 0x80) >> 7
        
    code_min = int(((math.sqrt(Pmin * R) / Vmax) * 100 - 50) * (126 / 50) + 1)
    code_max = int(((math.sqrt(Pmax * R) / Vmax) * 100 - 50) * (126 / 50) + 1)

    #print(code_min, code_max)

    # защита от переполнения    
    if code_min > 127: code_min = 127
    if code_max > 127: code_max = 127

    # защита от недопустимых значений
    if code_min < 1: code_min = 0
    if code_max < 1: code_max = 0
        
    data = [code_min, code_max, code_max, code_min, t_off_hex_U8b_2B_l,
            t_off_hex_U8b_2B_h, t_on_hex_U8b_2B_l,
            t_on_hex_U8b_2B_h, time_pmax]

    rs.reg_pwrcodes(ser,data)
    


def pmf32_set_btnbrt(ser, context_btn_brt, on_btn_brt):
    assert (0 <= context_btn_brt <= 0xfe), 'context buttons brightness is wrong'
    assert (0 <= on_btn_brt <= 0xfe), 'power on button brightness is wrong'
    data = [context_btn_brt, on_btn_brt, 0, 0]
    rs.set_btnbrt(ser, data)


def simulation_heater(ser):
    dt = 0.05
    def set_t(ser, context_btn_brt, on_btn_brt, t_set):
        assert (0 <= context_btn_brt <= 0xfe), 'context buttons brightness is wrong'
        assert (0 <= on_btn_brt <= 0xfe), 'power on button brightness is wrong'
        t = t_set & 0xff
        t_low = t & 0x7F
        t_high = (t & 0x80) >> 7
        data = [context_btn_brt, on_btn_brt, t_low, t_high]
        rs.set_btnbrt(ser, data)

    while 1:    
        print(u'Выберите тест')
        print(u'1  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=10c')
        print(u'2  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=10c')
        print(u'3  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MAX; HENA=0; Pmaxtime=10c')
        print(u'4  - Т=-64..+127; t_on=-3; t_off=0; U2U1=MIN; HENA=0; Pmaxtime=10c')
        print(u'5  - Т=-5..+1..-5; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'6  - Т=-5..+1..-5; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'7  - Т=+5..-2..+5; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'8  - Т=+5..-4..+5; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'9  - Т=+127..-64; t_on=-3; t_off=0; U2U1=MIN; HENA=1; Pmaxtime=600c')
        print(u'10 - Т=+127..-64; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'12 - Т=-2..0..-2; t_on=-3; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'13 - Т=-10; t_on=-3>>-15; t_off=0; U2U1=MAX; HENA=1; Pmaxtime=600c')
        print(u'14 - Т=0; t_on=-3>>5; t_off=0>>10; U2U1=MAX; HENA=1; Pmaxtime=600c')        
        print(u'15 - Т=-50; t_on=-3; t_off=0; U2U1=MAX>>MIN>>MAX; HENA=1; Pmaxtime=10c')        
        
        test_n = int(raw_input('>>'))
        
        if test_n == 1:
            rs.set_heater(ser,[0x01, 0x01])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
        elif test_n == 2:
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
        elif test_n == 3:
            rs.set_heater(ser,[0x01, 0x00])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
        elif test_n == 4:
            rs.set_heater(ser,[0x00, 0x00])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=1)
            for t in xrange(-64, 127):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
        elif test_n == 5:
            rs.set_heater(ser,[0x01, 0x01])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(-5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(1, -5, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)                
        elif test_n == 6:
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(-5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(1, -5, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)            
        elif test_n == 7:
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(5, -2, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(-2, 5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)            
        elif test_n == 8:
            rs.set_heater(ser,[0x00, 0x01])
            pmf32_reg_pwrcodes(ser, glass_resistance=4.315, 
                               pmin=30, pmax=50, ton=-3, toff=0, time_pmax=60)
            for t in xrange(5, -5, -1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)
            for t in xrange(-4, 5, 1):
                set_t(ser, 0xFE, 0xFE, t)
                time.sleep(dt)            
        elif test_n == 9:
            pass
        elif test_n == 10:
            pass
        elif test_n == 11:
            pass
        elif test_n == 12:
            pass
        elif test_n == 13:
            pass        
        elif test_n == 14:
            pass
        elif test_n == 15:
            pass        
        else:
            pass
        
            
        
        
        
        
        

def off_by_cmd(ser):
    Tuderj_vykl = 3
    rs.set_off_mode(ser, Tuderj_vykl)
    
    Toff = 5
    data = [Toff, 0x55, Toff, 0xE7]
    rs.cmd_off_timeout(ser, data)    
    
    pack = rx_specific_packet('RECEIPT_OFF', '232')
    if pack[4] == Toff:
        print(u' выключаемся через %s секунд' % pack[4]) 


def off_by_button_hold(ser):
    Tuderj_vykl = 5
    rs.set_off_mode(ser, Tuderj_vykl)


def run_gui(ser):
    def run_tests():
        global test_stop
        global test_next
        if (ui.ch_t1.isChecked() or ui.ch_t2.isChecked() or
            ui.ch_t3.isChecked() or ui.ch_t4.isChecked() or
            ui.ch_t5.isChecked() or ui.ch_t6.isChecked() or
            ui.ch_t7.isChecked() or ui.ch_t8.isChecked() or
            ui.ch_t9.isChecked() or ui.ch_t10.isChecked() or
            ui.ch_t11.isChecked() or ui.ch_t12.isChecked() or
            ui.ch_t13.isChecked() or ui.ch_t14.isChecked() or
            ui.ch_t15.isChecked() or ui.ch_t16.isChecked() or
            ui.ch_t15.isChecked() or ui.ch_t16.isChecked() or
            ui.ch_t17.isChecked() or ui.ch_t18.isChecked() or
            ui.ch_t19.isChecked() or ui.ch_t20.isChecked() or
            ui.ch_t21.isChecked() or ui.ch_t22.isChecked() or
            ui.ch_t23.isChecked() or ui.ch_t24.isChecked() or
            ui.ch_t25.isChecked() or ui.ch_t26.isChecked() or
            ui.ch_t27.isChecked() or ui.ch_t28.isChecked()):
            ui.btn_start.setEnabled(False)
            ui.btn_stop.setEnabled(True)
            ui.btn_skip.setEnabled(True)
            test_stop = False
            rs232_sts_out_q.clear()
            if ui.ch_t1.isChecked():
                if test_stop is False:
                    rs.set_key_mode(ser, u'одна кнопка')
                    key_test(one_point=True)
                    test_next = False
                    rs.set_key_mode(ser, u'все кнопки')
                    key_test(one_point=False)
                    rs.set_key_mode(ser, u'одна кнопка')
                    test_next = False
            if ui.ch_t2.isChecked():
                if test_stop is False:
                    #chk18_random_flood_rs232(ser)
                    coord_resolution_slide()
                    test_next = False
            if ui.ch_t3.isChecked():
                if test_stop is False:
                    coord_zone()
                    test_next = False
            if ui.ch_t4.isChecked():
                if test_stop is False:
                    coord_delay_test()
                    test_next = False
            if ui.ch_t5.isChecked():
                if test_stop is False:
                    coord_drawer_232()
                    test_next = False
            if ui.ch_t6.isChecked():
                if test_stop is False:
                    response_time_move()
                    test_next = False
            if ui.ch_t7.isChecked():
                if test_stop is False:
                    response_time_blink(ser)
                    test_next = False
            if ui.ch_t8.isChecked():
                if test_stop is False:
                    picture_set()
                    test_next = False
            if ui.ch_t9.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t10.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t11.isChecked():
                if test_stop is False:
                    chk04_vga_resolution()
                    test_next = False
            if ui.ch_t12.isChecked():
                if test_stop is False:
                    chk00_start_time(ser, timeout=5)
                    test_next = False
            if ui.ch_t13.isChecked():
                if test_stop is False:
                    chk01_set_mode(ser)
                    test_next = False
            if ui.ch_t14.isChecked():
                if test_stop is False:
                    chk02_stats(ser)
                    test_next = False
            if ui.ch_t15.isChecked():
                if test_stop is False:
                    chk03_runtime(ser, 5, 1)
                    test_next = False
            if ui.ch_t16.isChecked():
                if test_stop is False:
                    chk05_toprosa(ser)
                    test_next = False
            if ui.ch_t17.isChecked():
                if test_stop is False:
                    chk06_brightness(ser)
                    test_next = False
            if ui.ch_t18.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t19.isChecked():
                if test_stop is False:
                    chk08_splashscreen(ser)
                    test_next = False
            if ui.ch_t20.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t21.isChecked():
                if test_stop is False:
                    chk10_save_settings()
                    test_next = False
            if ui.ch_t22.isChecked():
                if test_stop is False:
                    chk12_videoswitch()
                    test_next = False
            if ui.ch_t23.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t24.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t25.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t26.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t27.isChecked():
                if test_stop is False:
                    pass
                    test_next = False
            if ui.ch_t28.isChecked():
                if test_stop is False:
                    chk17_corrupted_packets(ser)
                    test_next = False

            test_stop = False
            ui.btn_start.setEnabled(True)
            ui.btn_stop.setEnabled(False)
            ui.btn_skip.setEnabled(False)

    def stop_test():
        global test_stop
        test_stop = True

    def next_test():
        global test_next
        test_next = True

    des1 = key_test.__doc__.decode(encoding='utf-8')
    des2 = coord_resolution_slide.__doc__.decode(encoding='utf-8')
    des3 = coord_zone.__doc__.decode(encoding='utf-8')
    des4 = coord_delay_test.__doc__.decode(encoding='utf-8')
    des5 = coord_drawer_232.__doc__.decode(encoding='utf-8')
    des6 = response_time_move.__doc__.decode(encoding='utf-8')
    des7 = response_time_blink.__doc__.decode(encoding='utf-8')
    des8 = picture_set.__doc__.decode(encoding='utf-8')
    des9 = u'x'
    des10 = u'x'
    des11 = u'x'
    des12 = chk00_start_time.__doc__.decode(encoding='utf-8')
    des13 = chk01_set_mode.__doc__.decode(encoding='utf-8')
    des14 = chk02_stats.__doc__.decode(encoding='utf-8')
    des15 = chk03_runtime.__doc__.decode(encoding='utf-8')
    des16 = chk05_toprosa.__doc__.decode(encoding='utf-8')
    des17 = chk06_brightness.__doc__.decode(encoding='utf-8')
    des18 = chk07_power_consumption.__doc__.decode(encoding='utf-8')
    des19 = chk08_splashscreen.__doc__.decode(encoding='utf-8')
    des20 = chk09_default.__doc__.decode(encoding='utf-8')
    des21 = chk10_save_settings.__doc__.decode(encoding='utf-8')
    des22 = chk12_videoswitch.__doc__.decode(encoding='utf-8')
    des23 = u'x'
    des24 = u'x'
    des25 = u'x'
    des26 = u'x'
    des27 = u'x'
    des28 = u'x'

    def descr_t1(): ui.plainTextEdit.setPlainText(des1)
    def descr_t2(): ui.plainTextEdit.setPlainText(des2)
    def descr_t3(): ui.plainTextEdit.setPlainText(des3)
    def descr_t4(): ui.plainTextEdit.setPlainText(des4)
    def descr_t5(): ui.plainTextEdit.setPlainText(des5)
    def descr_t6(): ui.plainTextEdit.setPlainText(des6)
    def descr_t7(): ui.plainTextEdit.setPlainText(des7)
    def descr_t8(): ui.plainTextEdit.setPlainText(des8)
    def descr_t9(): ui.plainTextEdit.setPlainText(des9)
    def descr_t10(): ui.plainTextEdit.setPlainText(des10)
    def descr_t11(): ui.plainTextEdit.setPlainText(des11)
    def descr_t12(): ui.plainTextEdit.setPlainText(des12)
    def descr_t13(): ui.plainTextEdit.setPlainText(des13)
    def descr_t14(): ui.plainTextEdit.setPlainText(des14)
    def descr_t15(): ui.plainTextEdit.setPlainText(des15)
    def descr_t16(): ui.plainTextEdit.setPlainText(des16)
    def descr_t17(): ui.plainTextEdit.setPlainText(des17)
    def descr_t18(): ui.plainTextEdit.setPlainText(des18)
    def descr_t19(): ui.plainTextEdit.setPlainText(des19)
    def descr_t20(): ui.plainTextEdit.setPlainText(des20)
    def descr_t21(): ui.plainTextEdit.setPlainText(des21)
    def descr_t22(): ui.plainTextEdit.setPlainText(des22)
    def descr_t23(): ui.plainTextEdit.setPlainText(des23)
    def descr_t24(): ui.plainTextEdit.setPlainText(des24)
    def descr_t25(): ui.plainTextEdit.setPlainText(des25)
    def descr_t26(): ui.plainTextEdit.setPlainText(des26)
    def descr_t27(): ui.plainTextEdit.setPlainText(des27)
    def descr_t28(): ui.plainTextEdit.setPlainText(des28)

    def fade_up():
        for i in xrange(50):
            MainWindow.setWindowOpacity(i / 50)
            time.sleep(0.001)

    def scroll():
        ui.textBrowser.moveCursor(QtGui.QTextCursor.End)

    def kill():
        global run
        print('last word')
        run = False
        for i in xrange(50, 0, -1):
            MainWindow.setWindowOpacity(i / 50)
            time.sleep(0.001)

    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = gui.Ui_MainWindow()
    ui.setupUi(MainWindow)

    #XStream.stdout().messageWritten.connect(ui.textBrowser.insertPlainText)
    #XStream.stderr().messageWritten.connect(ui.textBrowser.insertPlainText)

    QtCore.QObject.connect(ui.btn_start, QtCore.SIGNAL("clicked()"), run_tests)
    QtCore.QObject.connect(ui.btn_stop, QtCore.SIGNAL("clicked()"), stop_test)
    QtCore.QObject.connect(ui.btn_skip, QtCore.SIGNAL("clicked()"), next_test)
    QtCore.QObject.connect(ui.textBrowser, QtCore.SIGNAL("textChanged()"),
                           scroll)
    QtCore.QObject.connect(ui.centralwidget, QtCore.SIGNAL("closeEmitApp()"), kill)

    ui.btn_stop.setEnabled(False)
    ui.btn_skip.setEnabled(False)

    QtCore.QObject.connect(ui.ch_t1, QtCore.SIGNAL("clicked()"), descr_t1)
    QtCore.QObject.connect(ui.ch_t2, QtCore.SIGNAL("clicked()"), descr_t2)
    QtCore.QObject.connect(ui.ch_t3, QtCore.SIGNAL("clicked()"), descr_t3)
    QtCore.QObject.connect(ui.ch_t4, QtCore.SIGNAL("clicked()"), descr_t4)
    QtCore.QObject.connect(ui.ch_t5, QtCore.SIGNAL("clicked()"), descr_t5)
    QtCore.QObject.connect(ui.ch_t6, QtCore.SIGNAL("clicked()"), descr_t6)
    QtCore.QObject.connect(ui.ch_t7, QtCore.SIGNAL("clicked()"), descr_t7)
    QtCore.QObject.connect(ui.ch_t8, QtCore.SIGNAL("clicked()"), descr_t8)
    QtCore.QObject.connect(ui.ch_t9, QtCore.SIGNAL("clicked()"), descr_t9)
    QtCore.QObject.connect(ui.ch_t10, QtCore.SIGNAL("clicked()"), descr_t10)
    QtCore.QObject.connect(ui.ch_t11, QtCore.SIGNAL("clicked()"), descr_t11)
    QtCore.QObject.connect(ui.ch_t12, QtCore.SIGNAL("clicked()"), descr_t12)
    QtCore.QObject.connect(ui.ch_t13, QtCore.SIGNAL("clicked()"), descr_t13)
    QtCore.QObject.connect(ui.ch_t14, QtCore.SIGNAL("clicked()"), descr_t14)
    QtCore.QObject.connect(ui.ch_t15, QtCore.SIGNAL("clicked()"), descr_t15)
    QtCore.QObject.connect(ui.ch_t16, QtCore.SIGNAL("clicked()"), descr_t16)
    QtCore.QObject.connect(ui.ch_t17, QtCore.SIGNAL("clicked()"), descr_t17)
    QtCore.QObject.connect(ui.ch_t18, QtCore.SIGNAL("clicked()"), descr_t18)
    QtCore.QObject.connect(ui.ch_t19, QtCore.SIGNAL("clicked()"), descr_t19)
    QtCore.QObject.connect(ui.ch_t20, QtCore.SIGNAL("clicked()"), descr_t20)
    QtCore.QObject.connect(ui.ch_t21, QtCore.SIGNAL("clicked()"), descr_t21)
    QtCore.QObject.connect(ui.ch_t22, QtCore.SIGNAL("clicked()"), descr_t22)
    QtCore.QObject.connect(ui.ch_t23, QtCore.SIGNAL("clicked()"), descr_t23)
    QtCore.QObject.connect(ui.ch_t24, QtCore.SIGNAL("clicked()"), descr_t24)
    QtCore.QObject.connect(ui.ch_t25, QtCore.SIGNAL("clicked()"), descr_t25)
    QtCore.QObject.connect(ui.ch_t26, QtCore.SIGNAL("clicked()"), descr_t26)
    QtCore.QObject.connect(ui.ch_t27, QtCore.SIGNAL("clicked()"), descr_t27)
    QtCore.QObject.connect(ui.ch_t28, QtCore.SIGNAL("clicked()"), descr_t28)

    MainWindow.setWindowOpacity(0)
    MainWindow.show()
    MainWindow.setFixedSize(866, 500)
    fade_up()

    app.exec_()


def stop_threads(th_list):
    for th in th_list:
        th.join()


# =============================================================================
# MAIN 
# =============================================================================
def main():
    global run

    def launch_threads(ser_rs232, ser_mdc):
        th1 = threading.Thread(name='th_rs232', target=inq, args=(ser_rs232, mbx_232))
        #th2 = threading.Thread(name='th_mdc', target=inq, args=(ser_mdc, mbx_mdc))
        th3 = threading.Thread(name='th_sw', target=inq_switch, args=(mbx_232, '232'))
        th31 = threading.Thread(name='thsw', target=old_packet_parser)
        th4 = threading.Thread(name='th_size', target=fifo_size_out)

        th1.start()
        #th2.start()
        th3.start()
        th31.start()
        th4.start()

        th_list = []
        th_list.append(th1)
        #th_list.append(th2)
        th_list.append(th3)
        th_list.append(th31)
        th_list.append(th4)

        return th_list


    try:
        print(chr(12))
        if not False:  # init_fail:

            
            with serial.Serial(COM_RS232, baudrate=9600) as ser:
                #with serial.Serial(COM_RS422, baudrate=19200) as ser422:
                #with serial.Serial('COM6', baudrate=9600) as psh_ser:
                logging.disable(logging.CRITICAL)
                th_list = launch_threads(ser, ser)  # загрузка FIFO
                rs.set_mode(ser, u'расширенный')
                #temperature_reading(ser)
                #coord_drawer_232()
                #coord_accuracy()
                #coord_accuracy_measure()
                #pmf32_reg_pwrcodes(ser, glass_resistance=4.315, pmin=60, pmax=82, ton=-3, toff=0, time_pmax=60)
                #pmf32_set_btnbrt(ser, context_btn_brt=0x55, on_btn_brt=0x55)
                simulation_heater(ser)
                #response_time_blink(ser)
                #response_time_move()
                #measure_luminance()
                #run_gui(ser)
                

                
              
                
  
                
                
                run = False
                stop_threads(th_list)
                logging.disable(logging.NOTSET)            
            
            
            
        else:
            print(u'Инициализация закончилась с ошибкой')
    except AssertionError as ae:
        print(u'Assertion: ', ae)
    except Exception as e:
        print(u'Что-то пошло не так: ', e)
    else:
        print(u'Сбоев в коде не было')
    finally:
        print(u'Это конец...',)
        logger_close()
        return 0

if __name__ == "__main__":
    main()
    
    

