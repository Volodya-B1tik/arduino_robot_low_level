# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 21:59:57 2017

@author: User
"""
from __future__ import division
from test import *
import logging
from var import *

log = logging.getLogger(__name__)

def response_time_move():
    """
    Проверка времени отклика
    """
    log.info(u'Проверка времени отклика (бегущие квадраты)')

    class MovingBox:

        def __init__(self, x, y, size, speed, window):
            self.x0 = x
            self.y0 = y
            self.x = x
            self.y = y
            self.size = size
            self.speed = speed
            self.window = window
            self.box = gr.Rectangle(gr.Point(self.x, self.y),
                                    gr.Point(self.x + self.size,
                                             self.y + self.size))
            self.box.setFill(cWhite)
            self.box.setOutline(cWhite)
            self.box.draw(window)

        def mv(self):
            while test_stop is False and test_next is False:
                if self.x < 1024:
                    self.box.move(1, 0)
                    self.x += 1
                else:
                    self.box.move(self.x0 - self.x, self.y0 - self.y)
                    self.x = self.x0
                self.window.update()
                time.sleep(1 / self.speed)

    window = gr.GraphWin("PMF-6.0 RT", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 60), u'Проверка времени отклика')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    mark_space = 10
    mark_y = 100
    mark_length = 40
    for i in xrange(110):
        mark = gr.Line(gr.Point(i * mark_space, mark_y),
                       gr.Point(i * mark_space, mark_y + mark_length))
        mark.setFill(cWhite)
        mark.draw(window)

    x1 = 0
    y1 = 150
    size = 50
    step_y = 70
    speed = 512

    bx1 = MovingBox(x1, y1, size, speed, window)
    bx2 = MovingBox(x1, y1 + step_y * 1, size, (speed / 2), window)
    bx3 = MovingBox(x1, y1 + step_y * 2, size, (speed / 4), window)
    bx4 = MovingBox(x1, y1 + step_y * 3, size, (speed / 8), window)
    bx5 = MovingBox(x1, y1 + step_y * 4, size, (speed / 16), window)
    bx6 = MovingBox(x1, y1 + step_y * 5, size, (speed / 32), window)
   
    threading.Thread(target=bx1.mv).start()
    threading.Thread(target=bx2.mv).start()
    threading.Thread(target=bx3.mv).start()
    threading.Thread(target=bx4.mv).start()
    threading.Thread(target=bx5.mv).start()
    threading.Thread(target=bx6.mv).start()

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        # if rs232_key_out_q:
        #     break
        window.update()
    time.sleep(0.3)
    rs232_key_out_q.clear()
    window.close()


def response_time_blink(ser):
    """ Проверка времени отклика """

    log.info(u'Проверка времени отклика (мерцающий квадрат)')

    class BlinkingBox:

        def __init__(self, x, y, size, speed, window):
            self.color = cBlack
            self.x = x
            self.y = y
            self.size = size
            self.speed = speed
            self.window = window
            self.box = gr.Rectangle(gr.Point(self.x, self.y),
                                    gr.Point(self.x + self.size,
                                             self.y + self.size))
            self.box.setFill(cWhite)
            self.box.setOutline(cWhite)
            self.box.draw(window)
            self.starttime = time.time()
            self.txt = ' '
            
#            tt = gr.Text(gr.Point(511, 200), self.txt)
#            tt.draw(window)
#            tt.setTextColor(cWhite)
#            tt.setSize(32)

        def mv(self):
            while test_stop is False and test_next is False:
                if self.color == cBlack:
                    self.window.autoflush = False
                    self.box.setFill(cWhite)
                    self.box.setOutline(cWhite)
                    self.color = cWhite
                    self.window.autoflush = True
                else:
                    self.window.autoflush = False
                    self.box.setFill(cBlack)
                    self.box.setOutline(cBlack)
                    self.color = cBlack
                    self.window.autoflush = True
                self.window.update()
                time.sleep(1 / self.speed)
        def temper_time(self):
            while test_stop is False and test_next is False:
                rs.req_sts(ser)
                time.sleep(1)
                tt.undraw()
                sts = rx_specific_packet('STS_PMF', '232')        
                if sts:
                    tmp_ts_raw = sts[24]
                    tmp_mi_raw = sts[25] + ((sts[26] << 7) & 0x80)
                    if (tmp_ts_raw & 0x80) == 0x80:
                        tmp_ts = tmp_ts_raw - 256
                    else:
                        tmp_ts = tmp_ts_raw
                        
                    if (tmp_mi_raw & 0x80) == 0x80:
                        tmp_mi = tmp_mi_raw - 256
                    else:
                        tmp_mi = tmp_mi_raw
                    self.txt = u'температура МДЦ = %s °C\n' \
                               u'температура МИ = %s °C\n' \
                               u'время работы = %s c' % (tmp_ts, tmp_mi, int(time.time() - self.starttime)) 
                    tt.setSize(32)                    
                    tt.setText(self.txt)
                    
                  
                self.window.update()

#    rs.set_mode(ser, u'расширенный')
#    time.sleep(1)
#    rs.set_heater(ser, [0x00, 0x00])
#    time.sleep(1)
#    rs.set_heater(ser, [0x01, 0x01])
#    
#    
#    clear_all_q()
    
    window = gr.GraphWin("PMF-6.0 RT", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 150), u'Проверка времени отклика №2 \n'
                                    u'период 1000 мс')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    size = 200
    x1 = int((1024 - size) / 2)
    y1 = int((768 - size) / 2)
    speed = 1

    bx1 = BlinkingBox(x1, y1, size, speed, window)
    threading.Thread(target=bx1.mv).start()
#    threading.Thread(target=bx1.temper_time).start()

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        window.update()
        
    time.sleep(0.3)
#    rs232_key_out_q.clear()
    window.close()



# TODO переделать так чтобы из папки указнной в конфиге грузились изображения
# TODO в произвольном количестве и с произвольными именами, сделать
# TODO проверку на валидность изображения перед загрузкой
def picture_set():
    """ переключение картинок
    """
    log.info(u'Изображения 1024х768')

    def wait_f1():
        while test_stop is False and test_next is False:
            QtCore.QCoreApplication.processEvents()
            window.update()
            if rs232_key_out_q:
                key = rs232_key_out_q.popleft()
                if key[4] == 0x21:
                    rs232_key_out_q.clear()
                    break

    window = gr.GraphWin("PMF-6.0 pictures", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)
    window.focus_set()

#    img = []
#    for i in xrange(1, 8):
#        img.append(gr.Image(gr.Point(512, 384), "img1024/pic%s.gif" % i))

    img = []
    for i in xrange(1, 13):
        img.append(gr.Image(gr.Point(512, 384), "img1024/%s.gif" % i))

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
        rs232_key_out_q.clear()
        for pic in img:
            pic.draw(window)
            raw_input()
            #wait_f1()
            if test_stop is True or test_next is True: break
            pic.undraw()
    window.close()



def measure_luminance():
    R = 110
    window = gr.GraphWin("PMF-6.0 Touch Screen", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)
    border = 0
    brdr = gr.Rectangle(gr.Point(border, border),gr.Point(1023 - border,
                        767 - border))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    dot = gr.Circle(gr.Point(256, 192), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(512, 384), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(768, 192), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(256, 576), R)
    dot.setFill(cWhite)
    dot.draw(window)

    dot = gr.Circle(gr.Point(768, 576), R)
    dot.setFill(cWhite)
    dot.draw(window)

    ln = gr.Line(gr.Point(256, 0), gr.Point(256, 767))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(512, 0), gr.Point(512, 767))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(768, 0), gr.Point(768, 767))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(0, 192), gr.Point(1023, 192))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(0, 384), gr.Point(1023, 384))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    ln = gr.Line(gr.Point(0, 576), gr.Point(1023, 576))
    ln.setWidth(1)
    ln.setFill(cWhite)
    ln.draw(window)

    while test_stop is False and test_next is False:
        QtCore.QCoreApplication.processEvents()
    window.close()


