# -*- coding: utf-8 -*-
"""
Created on Thu Mar 10 20:28:12 2016

@author: gubatenko
Набор тестов для проверки ПМФ
"""

from __future__ import division, print_function
from PyQt4 import QtCore, QtGui
import Tkinter as tk
import serial
import rs
import psh
import vga
import time
import datetime
import logging
import sys
import getcomports
import graphics as gr
import collections as coll
import binascii
import threading
import gui
import random
import math
import chk_nnn
import keyboard_tests as keys
import lcd_tests as lcd
import power_tests as pwr
import test_checklist as chk
import touchscreen_tests as touch
from var import *


def inq(ser, mbx):
    while 1:
        if ser.inWaiting() > 0:
            dat = ser.read(ser.inWaiting())
            chunk = coll.deque([int(binascii.hexlify(dat[i]), 16)
                                for i in xrange(len(dat))])
            while True:
                try:
                    mbx.append(chunk.popleft())
                except IndexError:
                    break


def inq_sw(mbx):
    while 1:
        if mbx:
            rx_byte = mbx.popleft()
            print(rx_byte)
            


def actions(ser):
    def hex2bytes(string):
        return binascii.unhexlify(string.replace(' ', ''))
    while 1:
        x = raw_input()
        if x=='1':
            send = 'D5'
            ser.write(hex2bytes(send))
            print(send)
        if x=='2':
            send = 'DA'
            ser.write(hex2bytes(send))
            print(send)
        if x=='3':
            send = '80'
            ser.write(hex2bytes(send))
            print(send)
        if x=='4':
            send = 'BF'
            ser.write(hex2bytes(send))
            print(send)            

def hb(ser):
    def hex2bytes(string):
        return binascii.unhexlify(string.replace(' ', ''))
    while 1:
        send = '00'
        ser.write(hex2bytes(send))
        time.sleep(1)

def main():
    try:
        with serial.Serial('COM12', baudrate=2400) as ser:
            th1 = threading.Thread(name='hb', target=hb, args=(ser,))
            th2 = threading.Thread(name='in', target=inq, args=(ser, mbx_232))
            th3 = threading.Thread(name='sw', target=inq_sw, args=(mbx_232,))
            th4 = threading.Thread(name='ac', target=actions, args=(ser,))
            th1.start()
            th2.start()
            th3.start()
            th4.start()            
            while 1:
                time.sleep(1)
#                print('Loop')
    except:
        print(u'Error',)
    finally:
        print(u'Exit',)
        return 0

        
if __name__ == "__main__":
    main()
