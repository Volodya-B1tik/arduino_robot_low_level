# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 21:54:20 2017

@author: User
"""

import test as t
import time
import logging
import rs
from var import *
import binascii

log = logging.getLogger(__name__)

# константы с которыми сравниваем выдаваемые ПМФ значения
# TODO сдеать их подгружаемыми из *.ini файла
exp_pmf_id = 0x10
exp_soft_id = [2, 0, 0, 0, 0]
exp_hard_id = [1, 0, 0, 0, 0]
exp_serial_id = [48, 48, 48, 49, 0, 0, 0, 0, 0]
exp_temp_MD = [10, 40]
exp_temp_MI = [10, 50]

def print_pmf_sn():
    pmf_sn = ''.join((unichr(i) for i in exp_serial_id if i > 31))
    log.info(u'Тест %s зав.№ %s' % (get_pmf_type(exp_pmf_id), pmf_sn))


def get_pmf_type(pmf_id):
    if pmf_id == 0x10:
        return u'ПМФ-6.0'
    elif pmf_id == 0x11:
        return u'ПМФ-6.1'
    elif pmf_id == 0x12:
        return u'ПМФ-6.2'
    elif pmf_id == 0x13:
        return u'ПМФ-6.3'
    elif pmf_id == 0x14:
        return u'ПМФ-6.4'
    elif pmf_id == 0x15:
        return u'ПМФ-6.5'
    elif pmf_id == 0x16:
        return u'ПМФ-6.6'
    elif pmf_id == 0x20:
        return u'ПМФ-6.0м'
    elif pmf_id == 0x21:
        return u'ПМФ-3.2'
    else:
        return u'неизвестное устройство ID = %s' % pmf_id

# =============================================================================
# Тесты чеклиста
# =============================================================================
def chk00_start_time(ser, timeout=3):
    """ Измерение времени готовности ПМФ.
    Процедура не включает в себя управление источником питания.
    Проверяется через какое время после вызова процедуры ПМФ ответит
    пакетом STS_OUT на пакет SET_MODE.
    Погрешность измерения ~ resp_time + 15 мс
    """
    errors = 0
    resp_time = 0.5
    is_awake = False
    t.rs232_sts_out_q.clear()
    log.info(u'00:[Проверка времени готовности ПМФ]')
    start_time = time.clock()
    while time.clock() < start_time + timeout:
        #QtCore.QCoreApplication.processEvents()
        rs.set_mode(ser, u'технологический')
        time.sleep(resp_time)
        if len(t.rs232_sts_out_q) > 0:
            log.info(u'00-1: ОK: ПМФ ответил через %s с'
                     % (time.clock() - start_time))
            is_awake = True
            break
    if is_awake is False:
        log.error(u'00-1:ERR: ПМФ не ответил через %s с' % timeout)
        errors += 1
    return errors


def chk01_set_mode(ser, resp_timeout=1):
    """ Проверка установки режимов работы ПМФ """
    errors = 0
    log.info(u'01:[Проверка установки режимов работы ПМФ]')
    t.rs232_sts_out_q.clear()
    rs.set_mode(ser, u'штатный')

    sts_out = t.rx_specific_packet('STS_OUT', '232', resp_timeout)

    if len(sts_out) > 0:
        if (sts_out[6] & 0x0A) == 0x00:  # проверяем, что мы в штатном режиме
            log.info(u'01-1: ОK: установлен признак режима штатный')
        else:
            log.error(u'01-1:ERR: не установлен признак режима штатный')
            errors += 1
    else:
        log.error(u'01-1:ERR: нет ответа sts_out на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    t.rs232_sts_out_q.clear()
    rs.set_mode(ser, u'технологический')

    sts_out = t.rx_specific_packet('STS_OUT', '232', resp_timeout)

    if len(sts_out) > 0:
        if (sts_out[6] & 0x0A) == 0x02:  # проверяем, что мы в тех.режиме
            log.info(u'01-2: ОK: установлен признак режима технологический')
        else:
            log.error(u'01-2:ERR: не установлен признак режима \
            технологический')
            errors += 1
    else:
        log.error(u'01-2:ERR: нет ответа sts_out на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    t.rs232_sts_pmf_q.clear()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = t.rx_specific_packet('STS_PMF', '232', resp_timeout)
    if len(sts_pmf) > 0:
        if (sts_pmf[27] & 0x0A) > 0x02:  # проверяем, что мы в расшир. режиме
            log.info(u'01-3: ОK: установлен признак режима расширенный')
        else:
            log.error(u'01-3:ERR: не установлен признак режима расширенный')
            errors += 1
    else:
        log.error(u'01-3:ERR: нет ответа sts_pmf на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    return errors


# def chk02_stats(ser, exp_id, exp_softid, exp_hardid, exp_serialid,
#                 exp_temp_MD, exp_temp_MI, resp_timeout=1):
def chk02_stats(ser, resp_timeout=1):
    """ Проверка идентификаторов ПМФ """

    errors = 0
    log.info(u'02:[Проверка параметров ПМФ]')
    rs232_sts_pmf_q.clear()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232', resp_timeout)
    if len(sts_pmf) > 0:
        if sts_pmf[4] == exp_pmf_id:  # 02-2 проверяем идентификатор ПМФ
            log.info(u'02-1: OK: Ожидаемый PMF_ID = %s, полученный \
            PMF_ID = %s' % (hex(exp_pmf_id), hex(sts_pmf[4])))
        else:
            log.error(u'02-1:ERR: Ожидаемый PMF_ID = %s, полученный \
            PMF_ID = %s' % (hex(exp_pmf_id), hex(sts_pmf[4])))
            errors += 1
        if sts_pmf[5:10] == exp_soft_id:  # проверяем версию ПО
            log.info(u'02-2: OK: Ожидаемый SOFT_ID = %s, полученный \
            SOFT_ID = %s' % (exp_soft_id, sts_pmf[5:10]))
        else:
            log.error(u'02-2:ERR: Ожидаемый SOFT_ID = %s, полученный \
            SOFT_ID = %s' % (exp_soft_id, sts_pmf[5:10]))
            errors += 1
        if sts_pmf[10:15] == exp_hard_id:  # проверяем версию аппаратуры
            log.info(u'02-3: OK: Ожидаемый HARD_ID = %s, полученный \
            HARD_ID = %s' % (exp_hard_id, sts_pmf[10:15]))
        else:
            log.error(u'02-3:ERR: Ожидаемый HARD_ID = %s, полученный \
            HARD_ID = %s' % (exp_hard_id, sts_pmf[10:15]))
            errors += 1
        if sts_pmf[15:24] == exp_serial_id:  # проверяем заводской номер
            log.info(u'02-4: OK: Ожидаемый SERIAL_ID = %s, полученный \
            SERIAL_ID = %s' % (exp_serial_id, sts_pmf[15:24]))
        else:
            log.error(u'02-4:ERR: Ожидаемый SERIAL_ID = %s, полученный \
            SERIAL_ID = %s' % (exp_serial_id, sts_pmf[15:24]))
            errors += 1
            # TODO написать нормальный обработчик принятой температуры
            # проверяем температуру МД
        if exp_temp_MD[0] < sts_pmf[24] < exp_temp_MD[1]:
            log.info((u'02-5: OK: Ожидаемая температура МД от %s до %s, \
            полученная = %s' % (exp_temp_MD[0], exp_temp_MD[1], sts_pmf[24])))
        else:
            log.error((u'02-5:ERR: Ожидаемая температура МД от %s до %s, \
            полученная = %s' % (exp_temp_MD[0], exp_temp_MD[1], sts_pmf[24])))
            errors += 1
        # TODO написать нормальный обработчик принятой температуры
        if exp_temp_MI[0] < sts_pmf[25] < exp_temp_MI[1] and \
                        sts_pmf[26] == 0:  # проверяем температуру МИ
            log.info((u'02-6: OK: Ожидаемая температура МИ от %s до %s, \
            полученная = %s' % (exp_temp_MI[0], exp_temp_MI[1], sts_pmf[25])))
        else:
            log.error((u'02-6:ERR: Ожидаемая температура МИ от %s до %s, \
            полученная = %s' % (exp_temp_MI[0], exp_temp_MI[1], sts_pmf[25])))
            errors += 1
    else:
        log.error(u'02-X:ERR: ПМФ не ответил sts_pmf на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1

    return errors


# TODO переделать получение времени
def chk03_runtime(ser, sleep_time, resp_timeout=1):
    """ Проверка времени наработки ПМФ """

    errors = 0
    log.info(u'03:[Проверка времени наработки]')
    rs232_sts_pmf_q.clear()
    rs.set_mode(ser, u'расширенный')
    sts_pmf = rx_specific_packet('STS_PMF', '232', resp_timeout)
    if sts_pmf:
        PMF_time1 = sts_pmf[31:36]
        PMF_time2 = PMF_time1[::-1]
        rtime1 = 0
        i = 4
        for c in xrange(len(PMF_time2)):
            rtime1 += PMF_time2[c] << (i * 8)
            i += -1
        rtime1 *= 0.25 # время наработки ПМФ в секундах
        first = rtime1
        log.info(u'03-1:INF: Ждем %s c' % sleep_time)
        time.sleep(sleep_time)
        rs.req_sts(ser)
        sts_pmf = rx_specific_packet('STS_PMF', '232', resp_timeout)
        if len(sts_pmf) > 0:
            PMF_time1 = sts_pmf[31:36]
            PMF_time2 = PMF_time1[::-1]
            rtime2 = 0
            i = 4
            for c in xrange(len(PMF_time2)):
                rtime2 += PMF_time2[c] << (i * 8)
                i += -1
            rtime2 *= 0.25  # время наработки ПМФ в секундах
            time_diff = abs(rtime2 - (first + sleep_time))
            time_err_allowed = 1
            if time_diff <= time_err_allowed:
                log.info(u'03-1: OK: Разница во времени между прочитанной и \
                заданной %s <= %s c' % (time_diff, time_err_allowed))
            else:
                log.info(u'03-1:ERR: Время_1 = %s, Время_2 = %s, time_diff = '
                         u'%s, \
                exp_diff = %s' % (first, rtime2, time_diff, time_err_allowed))
                errors += 1
        else:
            log.info(u'03-1:ERR: ПМФ не ответил sts_pmf на SET_MODE за %s с'
                     % resp_timeout)
            errors += 1
    else:
        log.error(u'03-1:ERR: ПМФ не ответил sts_pmf на SET_MODE за %s с'
                  % resp_timeout)
        errors += 1
    return errors


def chk04_vga_resolution():
    """ Проверка установки разрешений VGA """

#    errors = 0
#    ask = True
#    log.info(u'04:[Проверка установки разрешений VGA]')
#    dev_num = 3  # TODO автоматизировать выбор устройства
#    mode_list, devices = get_vga_modes(dev_num)
#    errors += set_vga_resolution(640, 480, mode_list, devices, dev_num, ask)
#    errors += set_vga_resolution(800, 600, mode_list, devices, dev_num, ask)
#    errors += set_vga_resolution(1024, 768, mode_list, devices, dev_num, ask)
#    return errors
    errors = 0
    ask = False
    log.info(u'04:[Проверка установки разрешений VGA]')
    dev_num = 3  # TODO автоматизировать выбор устройства
    mode_list, devices = get_vga_modes(dev_num)
    
    res = [(640,480),(800,600),(1024,768)]
    
    for n in xrange(600):
        rnd = n % 3
        log.info(("%s x=%s, y=%s" % (n, res[rnd][0], res[rnd][1])))
        set_vga_resolution(res[rnd][0], res[rnd][1], mode_list, devices, dev_num, ask)
        time.sleep(3)
    
    
#    for n in xrange(20):
#        rnd = random.randint(0, 2)
#        log.info(("x=%s, y=%s" % (res[rnd][0], res[rnd][1])))
#        set_vga_resolution(res[rnd][0], res[rnd][1], mode_list, devices, dev_num, ask)
#        time.sleep(3)
    
    
    return errors


def chk05_toprosa(ser, resp_timeout=1, time_to_wait=3):
    """ Описание 05
    """
    def check(ser, topros):
        passed = 0
        failed = 0
        err_time_list = []
        topros_sec = (topros + 1) * 0.025
        param = [0xFE, 0x46, 0x46, 0x46, 0x0A, 0x0A, 0x0A, 0x58, 0x00, 0x00,
                 0x00, topros, 0x0A, 0xFE, 0x00, 0x00]
        rs.set_param(ser, param)
        start_time = time.clock()
        last_time = 0
        err_in_time_measurement = 0.04
        first_time = True
        while time.clock() < start_time + time_to_wait:
            rx_specific_packet('KEY_SET_OUT', '232', resp_timeout)
            delta_t = time.clock() - last_time
            if first_time is True:
                first_time = False
            else:
                if abs(delta_t - topros_sec) < err_in_time_measurement:
                    passed += 1
                else:
                    failed += 1
                    err_time_list.append(delta_t - topros_sec)
            last_time = time.clock()
        if len(err_time_list) == 0:
            max_time_err = 0
        else:
            max_time_err = max(err_time_list)
        return passed, failed, max_time_err

    errors = 0
    log.info(u'05:[Проверка установки Toprosa]')
    rs.set_mode(ser, u'технологический')
    rs.set_key_mode(ser, u'все кнопки')
    topros_min = 2  # мин. допустимое значение по протоколу 75 мс = (2+1)*25мс
    topros_2 = 9
    topros_3 = 19

    passed, failed, err_max = check(ser, topros_min)
    if failed > 0:
        msg = u'05-1:ERR: Topros = {}, успешно {}, ошибок {}, расхождение {} c\
        '.format(topros_min, passed, failed, err_max)
        log.error(msg)
        errors += 1

    passed, failed, err_max = check(ser, topros_2)  # 250 мс
    if failed > 0:
        msg = u'05-2:ERR: Topros = {}, успешно {}, ошибок {}, расхождение {} c\
        '.format(topros_2, passed, failed, err_max)
        log.error(msg)
        errors += 1

    passed, failed, err_max = check(ser, topros_3)  # 500 мс
    if failed > 0:
        msg = u'05-3:ERR: Topros = {}, успешно {}, ошибок {}, расхождение {} c\
        '.format(topros_3, passed, failed, err_max)
        log.error(msg)
        errors += 1

    rs.set_key_mode(ser, u'одна кнопка')
    return errors


def chk06_brightness(ser, manual=False):
    """ Проверка установки яркости
    у проверки два режима, ручной и автоматический.
    В автоматическом режиме идет перебор всех значений яркости от 0 до 254 и
    обратно 3 раа.
    В ручном режиме пользователя просят установить яркость и подтвердить
    успешную установку до тех пор пока пользователь не захочет прекратить
    проверку и не введет 255.
    """
    errors = 0
    wait = 0.005
    log.info(u'06:[Проверка установки яркости]')
    rs.set_mode(ser, u'технологический')
    if not manual:
        br = 0
        dbr = 1
        for i in xrange(3):
            while True:
                QtCore.QCoreApplication.processEvents()
                if br > 254:
                    br = 254
                    rs.set_brit(ser, br)
                    time.sleep(wait)
                    dbr = -dbr
                    break
                elif br < 0:
                    br = 0
                    rs.set_brit(ser, br)
                    time.sleep(wait)
                    dbr = -dbr
                    break
                else:
                    rs.set_brit(ser, br)
                    br += dbr
                    time.sleep(wait)
        # print u'\n>>> Яркость изменялась? [1 - да, 0 - нет]:',
        # resp = resp_yes_no()
        # if resp == 1:
        #     log.info(u'Проверка изменения яркости прошла успешно')
        # else:
        #     log.error(u'Ошибка при проверке изменения яркости')
        #     errors += 1
    else:
        while True:
            QtCore.QCoreApplication.processEvents()
            print(u'\n>>> Введите яркость [0 - 254], для выхода введите 255:',)
            br = resp_0_255()
            if br == 255:
                break
            else:
                rs.set_brit(ser, br)
                time.sleep(wait)
                # print u'\n>>> Яркость установлена правильно? \
                # [1 - да, 0 - нет]:',
                # if resp_yes_no() == 1:
                #     log.info(u'Яркость %s установлена успешно' % br)
                # else:
                #     log.error(u'Яркость %s не установлена' % br)
                #     errors += 1
    return errors


def chk07_power_consumption(ps, max_power, resp_timeout=0.3):
    """ Проверка потребляемой мощности в НКУ
    1) Перебрать напряжения от 22 до 29 В на источнике, измерить ток, вычислить
       мощность, сохранить ее в список
    2) Выбрать из списка максимальную мощность и сравнить с эталоном
    """
    log.info(u'07:[Проверка потребляемой мощности в НКУ]')
    errors = 0
    p = []
    for volts in xrange(22, 29, 1):
        ps.set_votage(volts, resp_timeout)
        v = ps.measure_voltage(resp_timeout)
        i = ps.measure_current(resp_timeout)
        if (v == -1) or (i == -1):
            errors += 1
        else:
            p.append(v * i)
            log.info(u'Напряжение %s, ток %s, мощность %s' % (v, i, v * i))
    if len(p) > 0:
        max_p = max(p)
        if max_p > max_power:
            log.error(u'Потр. мощность %s Вт > %s Вт' % (max_p, max_power))
            errors += 1
        else:
            log.info(u'Потр. мощность %s Вт < %s Вт' % (max_p, max_power))
    else:
        log.error(u'Потр. мощность измерить не удалось')
        errors += 1
    ps.set_votage(27, resp_timeout)
    return errors


def chk08_splashscreen(ser):
    """ Проверка экрана-заставки
    1) Включить экран-заставку
    2) Спросить пользователя все ли ОК
    3) Выключить экран-заставку
    4) Спросить пользователя все ли ОК    
    """
    log.info(u'08:[Проверка экрана-заставки]')
    errors = 0
    log.info(u'Включаю экран-заставку')
    rs.set_splash(ser, u'вкл')
    print(u'\nНа экране отображается заставка? [1 - да, 0 - нет]:',)
    resp = resp_yes_no()
    if resp == 1:
        log.info(u'Проверка вкл. экрана-заставки прошла успешно')
    else:
        log.error(u'Ошибка при проверке вкл. экрана-заставки')
        errors += 1
    log.info(u'Выключаю экран-заставку')
    rs.set_splash(ser, u'выкл')
    print(u'\nНа экране отображается не заставка? [1 - да, 0 - нет]:',)
    resp = resp_yes_no()
    if resp == 1:
        log.info(u'Проверка выкл. экрана-заставки прошла успешно')
    else:
        log.error(u'Ошибка при проверке выкл. экрана-заставки')
        errors += 1
    return errors


def chk09_default(ser232, ser422):
    """ Проверка установки заводских настроек.
    1) Установить настройки 
    2) Сбросить настройки послав пакет SET_DEFAULT
    3) Проверить настроки, должны соответствовать дефолтным.
    """

    def get_sts_out_422(timeout=1):
        start_time = time.clock()
        while time.clock() < start_time + timeout:
            if len(rs422_sts_out_q) > 0:
                sts_out = rs422_sts_out_q.pop()
                return sts_out
        return []

    def get_sts_pmf_232(timeout=1):
        start_time = time.clock()
        while time.clock() < start_time + timeout:
            if len(rs232_sts_pmf_q) > 0:
                sts_pmf = rs232_sts_pmf_q.pop()
                return sts_pmf
        return []

    def compare_with_defaults(sts_out):
        # vidparam и vidinterface определить из статуса нельзя
        global defaults
        if (sts_out[6] & 0x08 == 0) and \
                (((sts_out[6] & 0x02) >> 1) == defaults['mode']) and \
                (sts_out[6] & 0x04 >> 2) == defaults['key_out'] and \
                sts_out[11] == defaults['gainR'] and \
                sts_out[12] == defaults['gainG'] and \
                sts_out[13] == defaults['gainB'] and \
                sts_out[14] == defaults['offsetR'] and \
                sts_out[15] == defaults['offsetG'] and \
                sts_out[16] == defaults['offsetB'] and \
                sts_out[17] == defaults['phase'] and \
                sts_out[18] == defaults['offsetH'] and \
                sts_out[19] == defaults['offsetV'] and \
                sts_out[20] == defaults['brightness'] and \
                sts_out[28] == defaults['topros'] and \
                sts_out[29] == defaults['tavtopovtor'] and \
                (sts_out[6] & 0x10 == defaults['splash']):
            return True
        else:
            return False

    def compare_sts_pmf_with_defaults(STS_PMF):
        ## vidparam и vidinterface определить из статуса нельзя
        global defaults
        pass

    log.info(u'09:[Проверка установки заводских настроек]')
    errors = 0

    rs.set_mode(ser232, u'технологический')

    param = [0xFE, 0x46, 0x46, 0x46, 0x0A, 0x0A, 0x0A, 0x58, 0x00, 0x00,
             0x00, 0x06, 0x0A, 0xFE, 0x00, 0x00]

    rs.set_param(ser232, param)

    rs.set_default(ser232)

    rs422_sts_out_q.clear()
    rs.req_sts(ser422)

    STS_OUT = get_sts_out_422()
    isOK = compare_with_defaults(STS_OUT)
    ## TODO
    log.info(u'Проверка установки заводских настроек прошла успешно')


def chk10_save_settings():
    """ Проверка сохранения настроек в ПЗУ.
    1) Установить настройки
    2) Сохранить настройки послав пакет SAVE_PARAM
    3) Выключить питание
    4) Включить питание
    5) Проверить настройки, должны совпадать с установленными
    """
    pass


def chk11_buttons(ser):
    """ Проверка работы кнопок.
    1) Установить режим "одна кнопка"
    2) Нарисовать окно с 10 кнопками (GUI), вывести его на экран ПМФ
    3) Попросить пользователя понажимать кнопки и написать все ли ОК
    4) Установить режим "много кнопок"
    5) Повторить 2)-3)
    """
    log.info(u'11:[Проверка кнопок]')
    errors = 0
    log.info(u'Режим одна кнопка')
    rs.set_mode(ser, u'технологический')
    rs.set_key_mode(ser, mode=u'одна кнопка')
    key_test(True)
    log.info(u'Режи все кнопки')
    rs.set_key_mode(ser, mode=u'все кнопки')
    key_test(False)
    rs.set_key_mode(ser, mode=u'одна кнопка')
    log.info(u'\nВсе кнопки нажимались без замечаний? [1 - да, 0 - нет]:',)
    resp = resp_yes_no()
    if resp == 1:
        log.info(u'Проверка кнопок в режиме одна кнопка прошла успешно')
    else:
        log.error(u'Ошибка при проверке кнопок в режие одна кнопка')
        errors += 1

    return errors


def chk12_videoswitch():
    """ Проверка переключения видеоканалов.
    1) Подать VGA, LVDS, ETH
    2) Переключать видеоканалы с интервалом 3 с, с полным перебором комбинаций
       всех форматов (включая отсутствие видео в канале и режимы 
       автоопределения)
    3) Попросить пользователя контроллировать и написать все ли ОК
    """
    pass


def chk13_heater_power():
    """ Проверка мощности подогрева
    1) Включить питание
    2) Установить мощности подогрева (00-01-10-01) разрешение (0-1)
    3) Измерить мощности и температуры, сравнить с эталонами
    """
    pass


def chk14_heater_time():
    """ Проверка времени готовности ПМФ на минусе
    1) Включить питание
    2) Установить мощности подогрева (00) разрешение (1)
    3) Запустить таймер
    4) Попросить пользователя контролировать изображение и остановить таймер
       когда картинка отмерзнет
    5) Выключить, повторить для мощности (01)
    """
    pass


def chk15_can():
    """ Проверки специфичные для CAN
    HARTBEAT
    NODEID
    ...
    """
    pass


def chk16_stress():
    """ Проверки полной нагрузки по каналам RS-232, RS-422, CAN
    1) Включаются все видеоканалы на макс. разрешение и скорости.
    2) По всем инф.каналам посылаются пакеты с макс. темпом
    3) Пользователь нажимает кнопки и работает с сенсором
    4) В течении 1-2 минут контроллируется визульно качество работы сенсора,
    нажатие кнопок, картинка на экране ПМФ
    """
    pass


def function_control(ser, cycles=10, sts_control=True):
    log.info(u'Проверка переключения видеоканалов')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.5)
    def make_param(vid_param, vid_if):
        vid_dict = {
        'автоопределение' : 0xFE,
        '640х480 VGA,LVDS': 0x00,
        '800х600 VGA,LVDS': 0x01,
        '1024х768 VGA,LVDS' : 0x02,
        '1024х768 Eth, 16 бит, цвет' : 0x03,
        '1024х768 Eth, 8 бит, моно': 0x04,
        '1024х768 Eth, 10 бит, моно' : 0x05,
        '720х576 Eth, 16 бит, цвет' : 0x06,
        '720х576 Eth, 8 бит, моно' : 0x07,
        '720х576  Eth, 10 бит, моно' : 0x08,
        '720х400 VGA,LVDS' : 0x09,
        '640х400 VGA,LVDS' : 0x0A
        }
        vid_if_dict = {
        'автоопределение':0xFE,
        'VGA':0x01,
        'LVDS':0x02,
        'Ethernet':0x03
        }
        video_param = vid_dict[vid_param]
        R_amp = 0x32
        G_amp = 0x32
        B_amp = 0x32
        R_offset = 0x00
        G_offset = 0x00
        B_offset = 0x00
        phase = 0xCE
        hor_offset = 0x00
        ver_offset = 0x00
        rsrv = 0x00
        Toprosa = 0x0A
        Tavto = 0x06
        video_if = vid_if_dict[vid_if]
        param = [video_param, R_amp, G_amp, B_amp, R_offset, G_offset, B_offset, phase, hor_offset, ver_offset, rsrv, Toprosa, Tavto, video_if, rsrv, rsrv]
        return param

    video_switching_period = 3

    for n in xrange(0, cycles):
        rs.set_param(ser, make_param('1024х768 VGA,LVDS', 'VGA'))
#        if sts_control:
        #a = time.time()
        #sts = t.rx_specific_packet('STS_OUT', '232', timeout=1)
        #log.debug(sts)
        #if sts == []: break
        #log.debug(u'время между SET_PARAM и STS_OUT = %s' % (time.time() - a))
        #time.sleep(video_switching_period)
        raw_input()
        
        rs.set_param(ser, make_param('1024х768 VGA,LVDS', 'LVDS'))
        #a = time.time()
        #sts = rx_specific_packet('STS_OUT', '232', timeout=3)
        #log.debug(sts)
        #if sts == []: break
        #log.debug(u'время между SET_PARAM и STS_OUT = %s' % (time.time() - a))
        #time.sleep(sleep)
        raw_input()
        
        rs.set_param(ser, make_param('1024х768 Eth, 10 бит, моно', 'Ethernet'))
        #a = time.time()
        #sts = t.rx_specific_packet('STS_OUT', '232', timeout=3)
        #log.debug(sts)
        #if sts == []: break
        #log.debug(u'время между SET_PARAM и STS_OUT = %s' % (time.time() - a))
        #time.sleep(sleep)        
        raw_input()
        

def phase_in(ser):
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.5)
    def make_param(vid_param, vid_if, phase_adc):
        vid_dict = {
        'автоопределение' : 0xFE,
        '640х480 VGA,LVDS': 0x00,
        '800х600 VGA,LVDS': 0x01,
        '1024х768 VGA,LVDS' : 0x02,
        '1024х768 Eth, 16 бит, цвет' : 0x03,
        '1024х768 Eth, 8 бит, моно': 0x04,
        '1024х768 Eth, 10 бит, моно' : 0x05,
        '720х576 Eth, 16 бит, цвет' : 0x06,
        '720х576 Eth, 8 бит, моно' : 0x07,
        '720х576  Eth, 10 бит, моно' : 0x08,
        '720х400 VGA,LVDS' : 0x09,
        '640х400 VGA,LVDS' : 0x0A
        }
        vid_if_dict = {
        'автоопределение':0xFE,
        'VGA':0x01,
        'LVDS':0x02,
        'Ethernet':0x03
        }
        video_param = vid_dict[vid_param]
        R_amp = 0x32
        G_amp = 0x32
        B_amp = 0x32
        R_offset = 0x00
        G_offset = 0x00
        B_offset = 0x00
        phase = phase_adc
        hor_offset = 0x00
        ver_offset = 0x00
        rsrv = 0x00
        Toprosa = 0x0A
        Tavto = 0x06
        video_if = vid_if_dict[vid_if]
        param = [video_param, R_amp, G_amp, B_amp, R_offset, G_offset, B_offset, phase, hor_offset, ver_offset, rsrv, Toprosa, Tavto, video_if, rsrv, rsrv]
        return param

    p = 0
    for n in xrange(0, 100):
        rs.set_param(ser, make_param('1024х768 VGA,LVDS', 'VGA', p))
        try:
            p = int(raw_input())
        except:
            pass

        

def req_resp(ser):
    
    rs.set_mode(ser, u'расширенный')
    x = 1
    log.debug('----[%s]----' % x)
    time.sleep(1)
    
    for n in xrange(1, 500):
        rs.req_sts(ser)
        x += 1
        log.debug('----[%s]----' % x)
#        raw_input()

        time.sleep(0.5)

        sts_pmf = t.rx_specific_packet('STS_PMF', '232', timeout=10)
        if len(sts_pmf) != 50:
            log.debug(len(sts_pmf))
            break
        else:
            log.debug(sts_pmf)
            tt1 = sts_pmf[31]
            tt2 = sts_pmf[32] << 7
            tt3 = sts_pmf[33] << 14
            tt4 = sts_pmf[34] << 21
            tt5 = sts_pmf[35] << 28

            tm = (tt1 + tt2 + tt3 + tt4 + tt5) / (4 * 3600)
            
            log.debug("%s" % (tm))


def keys_brit(ser):
    log.info(u'Яркость кнопок')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.5)
    rs.set_brit(ser, 0)
    keys_brt = 0x00
    while 1:
        rs.set_btnbrt(ser, [keys_brt, keys_brt, 0, 0])
        keys_brt = int(raw_input())
        
    

                       

def SET_ID_test(ser):
    log.info(u'Проверка SET_ID')
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.5)
    data = [0x21, 0x30, 0x30, 0x30, 0x31, 0x00, 0x00, 0x00, 0x00, 0x00]
    rs.set_ID(ser, data)
    time.sleep(3)
    rs.req_sts(ser)
    sts_pmf = t.rx_specific_packet('STS_PMF', '232', timeout=1)
    n=0
    for each in sts_pmf:
        print(' - %s, - %s' % (n, (hex(each))))
        n +=1
    #log.debug('ID=[%s], SERIAL_N=%s' % (sts_pmf[4], sts_pmf[15:23]))

def SET_BRIT_test(ser):
    log.info(u'Проверка SET_BRIT')
#    rs.set_mode(ser, u'расширенный')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.5)
    #b = 0x05
    #t.clear_all_q()
    x = 1
    log.debug('----[%s]----' % x)

    while 1:
        rs.set_brit(ser, 0x00)
        x += 1
        log.debug('----[%s]----' % x)
        raw_input()
        rs.set_brit(ser, 0xFE)        
        x += 1
        log.debug('----[%s]----' % x)
        raw_input()
    
#    for n in xrange(1, 1000):
#        if b == 0x05:
#            b = 0xFE
#        else:
#            b = 0x05
#        rs.set_brit(ser, b)
#        time.sleep(0.5)


def SET_BRIT_test_0_254(ser):


    rs.set_mode(ser, u'технологический')
    time.sleep(0.5)

    while 1:
        rs.set_brit(ser, 0x00)
        time.sleep(0.15)
        rs.set_brit(ser, 0xFE)        
        time.sleep(0.15)


def SET_BRIT_roll(ser):
    log.info(u'Проверка SET_BRIT')
#    rs.set_mode(ser, u'расширенный')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.5)
    brt = 128
    dbrt = 32
    tmin = 0.0328
    tmax = 0.033
    dt = 0.0000001
    t = 0.0329
    while 1:
        if brt < abs(dbrt):
            dbrt = -dbrt
        if brt > 254-abs(dbrt):
            dbrt = -dbrt            
        brt += dbrt
        rs.set_brit(ser, brt)
        
#        log.info(u't = %s' % t)                
        time.sleep(0.1)
#        if t < tmin: dt = -dt
#        if t > tmax: dt = -dt
#        t += dt
    

def VGA_LVDS_SWITCH(ser):
    
    rs.set_mode(ser, u'расширенный')
    time.sleep(0.5)
    t.clear_all_q()
    flag = True
    for n in xrange(1, 1000):
    
#        vid = 2
#        vif = 1
#        #         4     5     6     7     8     9    10    11    12    13    14    15    16    17    18    19
#        param = [vid, 0x46, 0x46, 0x46, 0x0A, 0x0A, 0x0A, 0x58, 0x00, 0x00, 0x00, 0x06, 0x0A, vif, 0x00, 0x00]
#        rs.set_param(ser, param)
#        log.debug(u'VGA')
#        flag = not flag
#        raw_input()

#        vid = 2
#        vif = 2
#        #         4     5     6     7     8     9    10    11    12    13    14    15    16    17    18    19
#        param = [vid, 0x46, 0x46, 0x46, 0x0A, 0x0A, 0x0A, 0x58, 0x00, 0x00, 0x00, 0x06, 0x0A, vif, 0x00, 0x00]
#        rs.set_param(ser, param)
#        log.debug(u'LVDS')
#        flag = not flag
#        raw_input()

        vid = 0xFE
        vif = 3
        #         4     5     6     7     8     9    10    11    12    13    14    15    16    17    18    19
        param = [vid, 0x46, 0x46, 0x46, 0x0A, 0x0A, 0x0A, 0x58, 0x00, 0x00, 0x00, 0x06, 0x0A, vif, 0x00, 0x00]
        rs.set_param(ser, param)
        log.debug(u'ETH')
        flag = not flag
        raw_input()


        #time.sleep(3)

def STS_OUT_ID(ser, ID):
    log.info(u'Проверка идентификатора ПМФ в STS_OUT')
    rs.set_mode(ser, u'технологический')
    time.sleep(0.5)
    t.clear_all_q()
    


def random_flood(ser):
    """
    Посылаются все пакеты в произвольном порядке с
    максимальным темпом. Пытаемся завалить канал RS-232 или
    обработчик пакетов или еще что-нибудь в ПМФ
    """

    LOOPS = 10
    RAND_LOOPS = 1000

    modes = [u'штатный', u'технологический', u'расширенный']
    k_mode = [u'одна кнопка', u'все кнопки']
    sp_mode = [u'вкл', u'выкл']

    log.debug(u"начало DDoS")
    log.debug(u"разогрев")

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        param = [random.randint(0, 254) for x in xrange(16)]
        rs.set_param(ser, param)

    for i in xrange(LOOPS):
        m = random.randint(0, 2)
        rs.set_mode(ser, modes[m])

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        rs.req_sts(ser)

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        rs.save_param(ser)

    rs.set_mode(ser, u'технологический')
    for i in xrange(LOOPS):
        rs.set_default(ser)

    log.debug(u"рандом")

    for i in xrange(RAND_LOOPS):
        test_pick = random.randint(1, 23)
        if test_pick == 1:
            m = random.randint(0, 2)
            rs.set_mode(ser, modes[m])
        elif test_pick == 2:
            param = [random.randint(0, 254) for x in xrange(16)]
            rs.set_param(ser, param)
        elif test_pick == 3:
            rs.req_sts(ser)
        elif test_pick == 4:
            rs.save_param(ser)
        elif test_pick == 5:
            rs.set_default(ser)
        elif test_pick == 6:
            rs.req_sts_eth1(ser)
        elif test_pick == 7:
            rs.req_sts_eth2(ser)
        elif test_pick == 8:
            rs.req_sts_ovhp(ser)
        elif test_pick == 9:
            rs.req_sts_vglv(ser)
        elif test_pick == 10:
            rs.req_sts_vpipe(ser)
        elif test_pick == 11:
            rs.req_sts_vpr1(ser)
        elif test_pick == 12:
            rs.req_sts_vpr2(ser)
        elif test_pick == 13:
            rs.req_sts_vpr3(ser)
        elif test_pick == 14:
            rs.req_sts_vpr4(ser)
        elif test_pick == 15:
            brit = random.randint(0, 254)
            rs.set_brit(ser, brightness=brit)
        elif test_pick == 16:
            param = [random.randint(0, 254) for x in xrange(2)]
            rs.set_heater(ser, param)
        elif test_pick == 17:
            m = random.randint(0, 1)
            rs.set_key_mode(ser, k_mode[m])
        elif test_pick == 18:
            param = [random.randint(0, 254) for x in xrange(2)]
            rs.set_keys(ser, param)
        elif test_pick == 19:
            param = [random.randint(0, 254) for x in xrange(6)]
            rs.set_ovhp(ser, param)
        elif test_pick == 20:
            m = random.randint(0, 1)
            rs.set_splash(ser, sp_mode[m])
        elif test_pick == 21:
            param = [random.randint(0, 254) for x in xrange(9)]
            rs.set_vga(ser, param)
        elif test_pick == 22:
            param = [random.randint(0, 254) for x in xrange(93)]
            rs.set_vpipe(ser, param)
        elif test_pick == 23:
            param = [random.randint(0, 254) for x in xrange(52)]
            rs.set_eth1(ser, param)
    # после проверки возвращаем настройки в исходное состояние
    rs.set_default(ser)

    # чистим приемные очереди
    rs232_sts_out_q.clear()
    rs232_coord_out_q.clear()
    rs232_key_out_q.clear()
    rs232_key_set_out_q.clear()
    rs232_sts_pmf_q.clear()


def kill_sram(ser, ser422):

    LOOPS = 10
    RAND_LOOPS = 1000

    modes = [u'штатный', u'технологический', u'расширенный']
    k_mode = [u'одна кнопка', u'все кнопки']
    sp_mode = [u'вкл', u'выкл']

    log.debug(u"начало DDoS")

    rs.set_mode(ser, u'расширенный')
    for i in xrange(LOOPS):
        rs.req_sts(ser)

    log.debug(u"рандом")

    for i in xrange(RAND_LOOPS):
#        test_pick = random.randint(1, 23)
#        if test_pick == 1:
##            m = random.randint(0, 2)
##            rs.set_mode(ser, modes[m])
#            pass
#        elif test_pick == 2:
##            param = [random.randint(0, 254) for x in xrange(16)]
##            rs.set_param(ser, param)
#            pass
#        elif test_pick == 3:
#            rs.req_sts(ser)
#        elif test_pick == 4:
#            #rs.save_param(ser)
#            pass
#        elif test_pick == 5:
#            rs.set_default(ser)
#        elif test_pick == 6:
#            rs.req_sts_eth1(ser)
#        elif test_pick == 7:
#            rs.req_sts_eth2(ser)
#        elif test_pick == 8:
#            rs.req_sts_ovhp(ser)
#        elif test_pick == 9:
#            rs.req_sts_vglv(ser)
#        elif test_pick == 10:
#            rs.req_sts_vpipe(ser)
#        elif test_pick == 11:
#            rs.req_sts_vpr1(ser)
#        elif test_pick == 12:
#            rs.req_sts_vpr2(ser)
#        elif test_pick == 13:
#            rs.req_sts_vpr3(ser)
#        elif test_pick == 14:
#            rs.req_sts_vpr4(ser)
#        elif test_pick == 15:
#            brit = random.randint(0, 254)
#            rs.set_brit(ser, brightness=brit)
#        elif test_pick == 16:
##            param = [random.randint(0, 254) for x in xrange(2)]
##            rs.set_heater(ser, param)
#            pass
#        elif test_pick == 17:
#            m = random.randint(0, 1)
#            rs.set_key_mode(ser, k_mode[m])
#        elif test_pick == 18:
#            param = [random.randint(0, 254) for x in xrange(2)]
#            rs.set_keys(ser, param)
#        elif test_pick == 19:
#            param = [random.randint(0, 254) for x in xrange(6)]
#            rs.set_ovhp(ser, param)
#        elif test_pick == 20:
#            m = random.randint(0, 1)
#            rs.set_splash(ser, sp_mode[m])
#        elif test_pick == 21:
#            param = [random.randint(0, 254) for x in xrange(9)]
#            rs.set_vga(ser, param)
#        elif test_pick == 22:
#            param = [random.randint(0, 254) for x in xrange(93)]
#            rs.set_vpipe(ser, param)
#        elif test_pick == 23:
#            param = [random.randint(0, 254) for x in xrange(52)]
#            rs.set_eth1(ser, param)
#            
            
            
        test_pick = random.randint(1, 23)
        if test_pick == 1:
            pass
        elif test_pick == 2:
            pass
        elif test_pick == 3:
            rs.req_sts(ser422)
        elif test_pick == 4:
            pass
        elif test_pick == 5:
            rs.set_default(ser422)
        elif test_pick == 6:
            rs.req_sts_eth1(ser422)
        elif test_pick == 7:
            rs.req_sts_eth2(ser422)
        elif test_pick == 8:
            rs.req_sts_ovhp(ser422)
        elif test_pick == 9:
            rs.req_sts_vglv(ser422)
        elif test_pick == 10:
            rs.req_sts_vpipe(ser422)
        elif test_pick == 11:
            rs.req_sts_vpr1(ser422)
        elif test_pick == 12:
            rs.req_sts_vpr2(ser422)
        elif test_pick == 13:
            rs.req_sts_vpr3(ser422)
        elif test_pick == 14:
            rs.req_sts_vpr4(ser422)
        elif test_pick == 15:
            brit = random.randint(0, 254)
            rs.set_brit(ser422, brightness=brit)
        elif test_pick == 16:
            pass
        elif test_pick == 17:
            m = random.randint(0, 1)
            rs.set_key_mode(ser422, k_mode[m])
        elif test_pick == 18:
            param = [random.randint(0, 254) for x in xrange(2)]
            rs.set_keys(ser422, param)
        elif test_pick == 19:
            param = [random.randint(0, 254) for x in xrange(6)]
            rs.set_ovhp(ser422, param)
        elif test_pick == 20:
            m = random.randint(0, 1)
            rs.set_splash(ser422, sp_mode[m])
        elif test_pick == 21:
            param = [random.randint(0, 254) for x in xrange(9)]
            rs.set_vga(ser422, param)
        elif test_pick == 22:
            param = [random.randint(0, 254) for x in xrange(93)]
            rs.set_vpipe(ser422, param)
        elif test_pick == 23:
            param = [random.randint(0, 254) for x in xrange(52)]
            rs.set_eth1(ser422, param)
            
    # после проверки возвращаем настройки в исходное состояние
    rs.set_default(ser)

    # чистим приемные очереди
    rs232_sts_out_q.clear()
    rs232_coord_out_q.clear()
    rs232_key_out_q.clear()
    rs232_key_set_out_q.clear()
    rs232_sts_pmf_q.clear()