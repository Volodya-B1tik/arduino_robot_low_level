# -*- coding: utf-8 -*-
"""
Created on Tue Mar 01 12:14:59 2016

@author: gubatenko
"""

from __future__ import print_function
import binascii
import serial

REGULAR_MODE = 0
TECH_MODE = 1
EXTENDED_MODE = 2

class rs232:
    def __init__(self, port, baudrate):
        self.ser = serial.Serial(port, baudrate)

        # размер пакета из ПМФ в ПЭВМ (в байтах)
        self.packet_size = {
            'OLD_OUT': 5,
            'KEY_OUT': 5,
            'STS_OUT': 36,
            'COORD_OUT': 14,
            'KEY_SET_OUT': 6,
            'KEY_OFF_CLICKED': 5,
            'RECEIPT_OFF': 5,
            'STS_PMF': 44,
            'STS_VPIPE': 97,
            'STS_VPr1': 30,
            'STS_VPr2': 30,
            'STS_VPr3': 30,
            'STS_VPr4': 30,
            'STS_VGLV': 41,
            'STS_ETH1': 65,
            'STS_ETH2': 65,
            'STS_OVHP': 14}
    
        # размер поля данных пакета из ПЭВМ в ПМФ (в байтах)
        self.data_field_size = {
            'REQ_STS': 1,
            'SET_PARAM': 16,
            'SET_DEFAULT': 1,
            'SAVE_PARAM': 1,
            'SET_MODE': 1,
            'SET_BRIT': 1,
            'SET_KEY_MODE': 1,
            'SET_OFF_MODE': 1,
            'CMD_OFF_TIMEOUT': 4,
            'SET_VGA': 9,
            'SET_KEYS': 2,
            'SET_VPIPE': 93,
            'SET_ETH1': 52,
            'SET_ETH2': 52,
            'SET_VPr1': 14,
            'SET_VPr2': 14,
            'SET_VPr3': 14,
            'SET_VPr4': 14,
            'REQ_STS_ETH1': 1,
            'REQ_STS_ETH2': 1,
            'REQ_STS_VPr1': 1,
            'REQ_STS_VPr2': 1,
            'REQ_STS_VPr3': 1,
            'REQ_STS_VPr4': 1,
            'REQ_STS_VPIPE': 1,
            'REQ_STS_VGLV': 1,
            'SET_SPLASH': 1,
            'SET_HEATER': 2,
            'SET_OVHP': 6,
            'SET_ID': 10,
            'REQ_STS_OVHP': 1,
            'REG_MAXBRIT': 1,
            'REG_PWRCODES': 8,
            'SET_BTNBRT': 4}
    
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            self.port.close()
        except:
            pass
 
    def hex2bytes(self, string):
        return binascii.unhexlify(string.replace(' ', ''))
    
    def cs_calc(self, data):
        CS = 0
        for each in data:
            CS = CS ^ each
        return CS
    
    def decode_packet_id(self, pid):
        if pid == 0xe1: s = 'KEY_OUT'
        elif pid == 0xe2: s = 'STS_OUT'
        elif pid == 0xe3: s = 'COORD_OUT'
        elif pid == 0xe4: s = 'KEY_SET_OUT'
        elif pid == 0xe5: s = 'KEY_OFF_CLICKED'
        elif pid == 0xe6: s = 'RECEIPT_OFF'    
        elif pid == 0xd0: s = 'STS_PMF'
        elif pid == 0xd1: s = 'STS_VPIPE'
        elif pid == 0xd2: s = 'STS_VPr1'
        elif pid == 0xd3: s = 'STS_VPr2'
        elif pid == 0xd4: s = 'STS_VPr3'
        elif pid == 0xd5: s = 'STS_VPr4'
        elif pid == 0xd6: s = 'STS_VGLV'
        elif pid == 0xd7: s = 'STS_ETH1'
        elif pid == 0xd8: s = 'STS_ETH2'
        elif pid == 0xd9: s = 'STS_OVHP'
        else: s = u'неизвестный пакет %X' % pid
        return s
    
    
    def packet_cs_check(self, fifo):
        CS_rx = fifo.pop()
        CS = self.cs_calc(fifo)
        if CS != CS_rx:
            return False
        else:
            return True
    
    
    def send_packet(self, data):
        CS = self.cs_calc(data)
        send = 'FF FF '
        for d in data:
            send += "%0.2X " % d
        send += "%0.2X" % CS
        self.ser.write(self.hex2bytes(send))

    
    def req_sts(self):
        data = [0xC1, 0]
        self.send_packet(data)
    
    
    def set_mode(self, mode, bad_mode=False):
        assert (0 <= mode <= 255), 'mode'
        data = [0xC5, mode]
        self.send_packet(data)
    
    
    def set_brit(self, brightness=0xFE):
        assert (0 <= brightness < 0xFF), 'brightness'
        data = [0xC6, brightness]
        self.send_packet(data)
    
    def set_heater(self, data):
        assert (len(data) == self.data_field_size['SET_HEATER']), 'set_heater'
        data.insert(0, 0xB2)
        self.send_packet(data)

        
        
