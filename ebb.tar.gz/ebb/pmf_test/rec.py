# -*- coding: utf-8 -*-
"""
Created on Thu Mar 10 20:28:12 2016

@author: gubatenko
Набор тестов для проверки ПМФ
"""

from __future__ import division, print_function
from PyQt4 import QtCore, QtGui
import serial
import rs
import psh
import vga
import time
import datetime
import logging
import sys
import getcomports
import graphics as gr
import collections as coll
import binascii
import threading
import gui
import random
import math
import chk_nnn
import keyboard_tests as keys
import lcd_tests as lcd
import power_tests as pwr
import test_checklist as chk
import touchscreen_tests as touch
from var import *


def inq(ser, mbx):
    """ Качалка данных из входного буфера COM-порта в FIFO-канала.
    Выполняется бесконечно, должна запускаться в отдельном потоке.
    1) ser - [serial.Serial] COM-порт с которого будем читать
    2) mbx - [collections.deque] FIFO-канала в которую будем писать
    """
    while run:
        if ser.inWaiting() > 0:
            dat = ser.read(ser.inWaiting())
            chunk = coll.deque([int(binascii.hexlify(dat[i]), 16)
                                for i in xrange(len(dat))])
            while True:
                try:
                    mbx.append(chunk.popleft())
                except IndexError:
                    break


def inq_switch(mbx, channel):
    """ Разбиралка FIFO-канала на несколько FIFO с однотипными пакетами.
    Выполняется бесконечно, должна запускаться в отдельном потоке.
    1) mbx - [collections.deque] FIFO-канала из которой будем доставать
             данные, из них лепить пакеты и складывать каждый пакет в
             свою очередь:
             ххх_coord_out_q   - очередь пакетов координат (COORD_OUT)
             ххх_key_out_q     - очередь пакетов нажатых клавиш (KEY_OUT)
             ххх_sts_out_q     - очередь пакетов статуса (STS_OUT)
             ххх_sts_pmf_q     - очередь пакетов статуса (STS_PMF)
             ххх_key_set_out_q - очередь пакетов нажатых клавиш (KEY_SET_OUT)
             , где ххх - название канала (rs232, rs422, can)
             у всех пакетов в этих очередях следующие отличия от протокола:
             а) вместо FF FF в начале каждого пакета идет FF FF FF
             это сделано чтобы индексы слов пакетов совпали с номерами
             слов в протоколе ИЛВ;
             б) последнее слово (контрольная сумма) отброшена, т.к. уже
             проверена на этапе приема пакета и чтобы количество байт в
             пакете не поменялось из-за добавленного FF в начале.
    2) channel - [str] канал которому соответствует очередь
                 ('232', '422', 'CAN')
    """

    ff1 = False
    ff2 = False
    rx_cnt = 0
    packet_in_progress = False
    packet = coll.deque()
    while run:
        if mbx:
            rx_byte = mbx.popleft()
            #rs232_old_q.append(rx_byte)
            if not packet_in_progress:
                if ff1 is False and rx_byte == 0xFF:
                    ff1 = True
                    rx_cnt = 1
                elif ff1 is True and ff2 is False and rx_byte == 0xFF:
                    ff2 = True
                    rx_cnt += 1
                elif ff1 is True and ff2 is False and rx_byte != 0xFF:
                    ff1 = False
                elif ff1 is True and ff2 is True:
                    if rx_byte != 0xFF:
                        rx_cnt += 1
                        packet_id = rs.decode_packet_id(rx_byte)
                        if packet_id != '':
                            packet.append(rx_byte)
                            packet_in_progress = True
                            packet_start_time = time.clock()
                        else:
                            ff1, ff2 = False, False
            else:
                packet.append(rx_byte)
                rx_cnt += 1
                if rx_cnt == rs.packet_size[packet_id]:
                    if  rs.packet_cs_check(packet) or SKIP_CHECKSUM:
                        [packet.appendleft(0xFF) for i in xrange(3)]
                        if channel == '232':
                            if packet_id == 'COORD_OUT': rs232_coord_out_q.append(packet)
                            elif packet_id == 'KEY_OUT': rs232_key_out_q.append(packet)
                            elif packet_id == 'STS_OUT': rs232_sts_out_q.append(packet)
                            elif packet_id == 'KEY_SET_OUT': rs232_key_set_out_q.append(packet)
                            elif packet_id == 'STS_PMF':  rs232_sts_pmf_q.append(packet)
                            elif packet_id == 'STS_VPIPE': rs232_sts_vpipe_q.append(packet)
                            elif packet_id == 'STS_VPr1': rs232_sts_vpr1_q.append(packet)
                            elif packet_id == 'STS_VPr2': rs232_sts_vpr2_q.append(packet)
                            elif packet_id == 'STS_VPr3': rs232_sts_vpr3_q.append(packet)
                            elif packet_id == 'STS_VPr4': rs232_sts_vpr4_q.append(packet)
                            elif packet_id == 'STS_VGLV': rs232_sts_vglv_q.append(packet)
                            elif packet_id == 'STS_ETH1': rs232_sts_eth1_q.append(packet)
                            elif packet_id == 'STS_ETH2': rs232_sts_eth2_q.append(packet)
                            elif packet_id == 'STS_OVHP': rs232_sts_ovhp_q.append(packet)
                            elif packet_id == 'KEY_OFF_CLICKED': rs232_key_off_clicked_q.append(packet)
                            elif packet_id == 'RECEIPT_OFF': rs232_receipt_off_q.append(packet)
                                
                        elif channel == '422': 
                            if packet_id == 'COORD_OUT': rs422_coord_out_q.append(packet)
                            elif packet_id == 'KEY_OUT': rs422_key_out_q.append(packet)
                            elif packet_id == 'STS_OUT': rs422_sts_out_q.append(packet)
                            elif packet_id == 'KEY_SET_OUT': rs422_key_set_out_q.append(packet)
                            elif packet_id == 'STS_PMF': rs422_sts_pmf_q.append(packet)
                            elif packet_id == 'STS_VPIPE': rs422_sts_vpipe_q.append(packet)
                            elif packet_id == 'STS_VPr1': rs422_sts_vpr1_q.append(packet)
                            elif packet_id == 'STS_VPr2': rs422_sts_vpr2_q.append(packet)
                            elif packet_id == 'STS_VPr3': rs422_sts_vpr3_q.append(packet)
                            elif packet_id == 'STS_VPr4': rs422_sts_vpr4_q.append(packet)
                            elif packet_id == 'STS_VGLV': rs422_sts_vglv_q.append(packet)
                            elif packet_id == 'STS_ETH1': rs422_sts_eth1_q.append(packet)
                            elif packet_id == 'STS_ETH2': rs422_sts_eth2_q.append(packet)
                            elif packet_id == 'STS_OVHP': rs422_sts_ovhp_q.append(packet)

                        elif channel == 'CAN':
                            pass  # тут допилить CAN
                        ff1, ff2 = False, False
                        packet_in_progress = False
                        packet = coll.deque()
        else:
            if packet_in_progress:
                if time.clock() > packet_start_time + PACKET_TTL:
                        ff1, ff2 = False, False
                        packet_in_progress = False
                        log.critical(u'Превышено время ожидания пакета, принято: % s' % packet)
                        packet = coll.deque()


def old_packet_parser():
    first_byte = False
    bytes_in_old_packet = 0
    old_packet = coll.deque()
    while run:
        if rs232_old_q:
            rx_old = rs232_old_q.popleft()
            if not first_byte:
                if rx_old == 0xBF or rx_old == 0xFF:
                    first_byte = True
                    flag = rx_old
            else:
                if rx_old == 0xFF:
                    first_byte = True
                    flag = rx_old
                else:
                    old_packet.append(rx_old)
                    bytes_in_old_packet += 1
                    if bytes_in_old_packet == 4:
                        x_coord = (old_packet[2] << 7) + old_packet[3]
                        y_coord = (old_packet[0] << 7) + old_packet[1]
                        old_xy.append((flag, x_coord, y_coord))
                        bytes_in_old_packet = 0
                        old_packet.clear()
                        first_byte = False
                        if len(old_xy) > 100:
                            old_xy.clear()


def fifo_size_out():
    pass
#    while run:
#        if len(rs232_coord_out_q) > 0:
#            log.debug('COORD_OUT: %s' % len(rs232_coord_out_q))
#        if len(rs232_key_out_q) > 0:
#            log.debug('KEY_OUT: %s' % len(rs232_key_out_q))
#        if len(rs232_key_set_out_q) > 0:
#            log.debug('KEY_SET_OUT: %s' % len(rs232_key_set_out_q))            
#        if len(rs232_sts_out_q) > 0:
#            log.debug('STS_OUT: %s' % len(rs232_sts_out_q))
#        if len(rs232_sts_pmf_q) > 0:
#            log.debug('STS_PMF: %s' % len(rs232_sts_pmf_q))            
#        delay = time.time()
#        while run: 
#            if time.time() - delay > 10:
#                break


def rx_specific_packet(packet, channel, timeout=1):
    log = logging.getLogger()
    packet_data = []
    start_time = time.clock()
    
    log.debug(u'ждем пакет %s в приемной очереди канала %s' % (packet, channel))
    while time.clock() < start_time + timeout:
        #QtCore.QCoreApplication.processEvents()
        if channel == '232':
            if packet == 'STS_OUT':
                if rs232_sts_out_q:
                    packet_data = rs232_sts_out_q.pop()
                    log.debug(u'взяли пакет %s из приемной очереди канала %s' % (packet, channel))
                    break
            elif packet == 'STS_PMF':
                if rs232_sts_pmf_q:
                    packet_data = rs232_sts_pmf_q.pop()
                    break
            elif packet == 'KEY_OUT':
                if rs232_key_out_q:
                    packet_data = rs232_key_out_q.pop()
                    break
            elif packet == 'KEY_SET_OUT':
                if rs232_key_set_out_q:
                    packet_data = rs232_key_set_out_q.pop()
                    break
            elif packet == 'COORD_OUT':
                if rs232_coord_out_q:
                    packet_data = rs232_coord_out_q.pop()
                    break
            elif packet == 'KEY_OFF_CLICKED':
                if rs232_key_off_clicked_q:
                    packet_data = rs232_key_off_clicked_q.pop()
                    break
                
            elif packet == 'STS_VGLV':
                if rs232_sts_vglv_q:
                    packet_data = rs232_sts_vglv_q.pop()
                    break
            elif packet == 'STS_ETH1':
                if rs232_sts_eth1_q:
                    packet_data = rs232_sts_eth1_q.pop()
                    break
            elif packet == 'STS_ETH2':
                if rs232_sts_eth2_q:
                    packet_data = rs232_sts_eth2_q.pop()
                    break
            elif packet == 'STS_VPr1':
                if rs232_sts_vpr1_q:
                    packet_data = rs232_sts_vpr1_q.pop()
                    break
            elif packet == 'STS_VPr2':
                if rs232_sts_vpr2_q:
                    packet_data = rs232_sts_vpr2_q.pop()
                    break
            elif packet == 'STS_VPr3':
                if rs232_sts_vpr3_q:
                    packet_data = rs232_sts_vpr3_q.pop()
                    break
            elif packet == 'STS_VPr4':
                if rs232_sts_vpr4_q:
                    packet_data = rs232_sts_vpr4_q.pop()
                    break
            elif packet == 'STS_VPIPE':
                if rs232_sts_vpipe_q:
                    packet_data = rs232_sts_vpipe_q.pop()
                    break
            elif packet == 'STS_OVHP':
                if rs232_sts_ovhp_q:
                    packet_data = rs232_sts_ovhp_q.pop()
                    break

        elif channel == '422':
            if packet == 'STS_OUT':
                if rs422_sts_out_q:
                    packet_data = rs422_sts_out_q.pop()
                    break
            elif packet == 'STS_PMF':
                if rs422_sts_pmf_q:
                    packet_data = rs422_sts_pmf_q.pop()
                    break
            elif packet == 'KEY_OUT':
                if rs422_key_out_q:
                    packet_data = rs422_key_out_q.pop()
                    break
            elif packet == 'KEY_SET_OUT':
                if rs422_key_set_out_q:
                    packet_data = rs422_key_set_out_q.pop()
                    break
            elif packet == 'COORD_OUT':
                if rs422_coord_out_q:
                    packet_data = rs422_coord_out_q.pop()
                    break
        elif channel == 'CAN':
            pass  # допилить CAN
        else:
            log.exception('BAD CHANNEL')
    return packet_data


def clear_all_q():
    # чистим приемные очереди
    rs232_coord_out_q.clear()
    rs232_key_out_q.clear()
    rs232_key_set_out_q.clear()
    rs232_sts_out_q.clear()
    rs232_sts_pmf_q.clear()
    rs232_sts_vpipe_q.clear()
    rs232_sts_vpr1_q.clear()
    rs232_sts_vpr2_q.clear()
    rs232_sts_vpr3_q.clear()
    rs232_sts_vpr4_q.clear()
    rs232_sts_vglv_q.clear()
    rs232_sts_eth1_q.clear()
    rs232_sts_eth2_q.clear()
    rs232_sts_ovhp_q.clear()
    rs422_coord_out_q.clear()
    rs422_key_out_q.clear()
    rs422_key_set_out_q.clear()
    rs422_sts_out_q.clear()
    rs422_sts_pmf_q.clear()
    rs422_sts_vpipe_q.clear()
    rs422_sts_vpr1_q.clear()
    rs422_sts_vpr2_q.clear()
    rs422_sts_vpr3_q.clear()
    rs422_sts_vpr4_q.clear()
    rs422_sts_vglv_q.clear()
    rs422_sts_eth1_q.clear()
    rs422_sts_eth2_q.clear()
    rs422_sts_ovhp_q.clear()
    old_xy.clear()


def stop_threads(th_list):
    for th in th_list:
        th.join()

def full_brt(ser):
    while 1:
        rs.set_brit(ser, 0xFE)
        time.sleep(1)
        rs.set_brit(ser, 0xFD)
        time.sleep(1)        


def main():
    log.critical(u'<<< НАЧАЛО ТЕСТИРОВАНИЯ >>>')
    global run

    def launch_threads(ser_rs232, ser_mdc):
        th1 = threading.Thread(name='rs232', target=inq, args=(ser_rs232, mbx_232))
        th3 = threading.Thread(name='switch_232', target=inq_switch, args=(mbx_232, '232'))
        th31 = threading.Thread(name='old', target=old_packet_parser)
        th4 = threading.Thread(name='size', target=fifo_size_out)
        th1.start()
        th3.start()
        th31.start()
        th4.start()
        th_list = []
        th_list.append(th1)
        th_list.append(th3)
        th_list.append(th31)
        th_list.append(th4)
        return th_list

    try:
        
        if True:
            with serial.Serial(COM_RS232, baudrate=9600) as ser:
                th_list = launch_threads(ser, ser)  # загрузка FIFO
                rs.set_mode(ser, u'технологический')
                run = False
                stop_threads(th_list)
        else:
            print(u'Инициализация закончилась с ошибкой')
    except AssertionError as ae:
        print(u'Assertion: ', ae)
    except Exception as e:
        print(u'Что-то пошло не так: ', e)
    else:
        print(u'Сбоев в коде не было')
    finally:
        print(u'конец...',)
        logger_close()
        return 0

        
if __name__ == "__main__":
    print(chr(12)) #очистка экрана консоли
    level = logging.DEBUG

    # создаем логгер в консоль и файл
    log = logging.getLogger()
    log.setLevel(level)
    consoleHandler = logging.StreamHandler(sys.stdout)
    consoleHandler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(name)-8s %(levelname)-6s '
                                  '%(message)s') #datefmt='%H:%M:%S'
    consoleHandler.setFormatter(formatter)
    log.addHandler(consoleHandler)
    now = datetime.datetime.now()
    filename = now.strftime("%Y_%m_%d %H-%M-%S") + '.log'
    fileHandler = logging.FileHandler(filename, mode='w')
    fileHandler.setFormatter(formatter)
    log.addHandler(fileHandler)
    
    main()
