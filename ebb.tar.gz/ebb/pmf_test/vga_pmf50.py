# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 17:51:24 2019

@author: gubatenko
"""

import vga
import time

def get_vga_modes(dev_num):
    devices = vga.devlist()
    mode_list = vga.modelist(devices[dev_num])
    return mode_list, devices


def set_vga_resolution(x, y, mode_list, devices, dev_num):
    vga.change_resolution(devices[dev_num], mode_list,
                          mode_required=(32, x, y, 60, 0))


def chk_vga_resolution():
    dev_num = 0
    mode_list, devices = get_vga_modes(dev_num)
    set_vga_resolution(1024, 768, mode_list, devices, dev_num)
    time.sleep(5)
    set_vga_resolution(1920, 1080, mode_list, devices, dev_num)
    
    
chk_vga_resolution()