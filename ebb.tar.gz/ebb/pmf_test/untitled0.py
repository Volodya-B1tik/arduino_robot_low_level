import time

time.sleep(1)
print(time.monotonic_ns())