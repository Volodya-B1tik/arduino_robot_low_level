# -*- coding: utf-8 -*-
"""
Created on Thu Mar 03 20:20:58 2016

@author: User
"""
from __future__ import absolute_import, division, print_function, unicode_literals
import socket
import time
import numpy as np
import struct
import collections as coll
import threading

rtp_q = coll.deque()
run = True

class RtpPacket(object):
#Constants
    HEADER_LENGTH = 12
    V_MASK = 0xc0
    V_SHIFT = 6
    P_MASK = 0x20
    X_MASK = 0x10
    CC_MASK = 0x0f
    M_MASK = 0x80
    PT_MASK = 0x7f
    DYNAMIC_PT = 96  # Dynamic payload type
    PT = DYNAMIC_PT & PT_MASK
    MP2T_CLK = 90000  # TS clock rate [Hz]
    S_MASK = 0x0000ffff
    TS_MASK = 0xffffffff

    @property
    def header_bytes(self):
        by = bytearray(RtpPacket.HEADER_LENGTH)
        by[0] = (((self.version << RtpPacket.V_SHIFT) & RtpPacket.V_MASK) +
                    (0) + (0) + (0))
        by[1] = ((RtpPacket.M_MASK if self.marker else 0) +
                    (self.payload_type & RtpPacket.PT_MASK))
        struct.pack_into(b'!H', by, 2, self.sequence)
        struct.pack_into(b'!I', by, 4, self.timestamp)
        struct.pack_into(b'!I', by, 8, self.ssrc)
        return by

#Constructor 
    def __init__(self, bytes):
        # Fields default values
        self.version = 2
        self.padding = False
        self.extension = False
        self.marker = False
        self.payload_type = 0
        self.sequence = 0
        self.timestamp = 0
        self.ssrc = 0xabcd1000
        self.csrc = []
        self.payload = []

    @staticmethod
    def create(sequence, marker, ts):
        rtp = RtpPacket(None)
        rtp.marker = marker
        rtp.payload_type = rtp.PT
        rtp.sequence = sequence & RtpPacket.S_MASK
        rtp.timestamp = ts
        return rtp


def main():
    global run
    
    MCAST_GRP = '224.2.127.254'
    MCAST_PORT = 9875
    
    session_id_1 = 55
    session_id_2 = 56
    s_my_ip_addr = socket.gethostbyname(socket.gethostname())
    s_ImyaVIs_1 = 'PMF_6_0'
    s_ImyaVIs_2 = 'PMF_6_0_'
    
    s_IPAdrPotoka_1 = '239.192.1.9'
    s_IPAdrPotoka_2 = '239.192.1.10'
    UDPPortPotoka = 5004
    pt = 96
    s_encoding_name = 'raw'
    freq = 90000
    s_sampling = 'GRAYSCALE'
    Gor = 1024
    Vert = 768
    #Gor = 1024
    #Vert = 768
    BitNaKomp = 8
    s_interlace = ";"
    KadrVSek = 25
    
    ts_mult = freq / KadrVSek
    
    header = np.zeros((8,1), dtype = np.uint8)
    header[0] = (1<<5)|(0<<2)
    header[2] = (session_id_1 >> 8)
    header[3] = (session_id_1 & 0xFF)
    
    data, s, part = s_my_ip_addr.partition('.')
    header[4] = np.uint8(data)
    data, s, part = part.partition('.')
    header[5] = np.uint8(data)
    data, s, part = part.partition('.')
    header[6] = np.uint8(data)
    header[7] = np.uint8(part)
    
    subheader = "application/sdp\0"
    
   
    msg_1 = ("v=%d\n\
o=- %u %u IN IP4 %s\n\
s=%s\n\
c=IN IP4 %s/%d\n\
t=0 0\n\
m=video %d RTP/AVP %d\n\
a=rtpmap:%d %s/%d\n\
a=fmtp:%d %s; %d; %d; %d%s\n\
a=framerate:%d\n" %(\
    0\
    ,session_id_1,session_id_1,s_my_ip_addr\
    ,s_ImyaVIs_1\
    ,s_IPAdrPotoka_1,15\
    \
    ,UDPPortPotoka,pt\
    ,pt,s_encoding_name,freq\
    ,pt,s_sampling,Gor,Vert,BitNaKomp,s_interlace\
    ,KadrVSek))
    
    msg_ascii = msg_1.encode('ascii')
    
    
    sock_sap = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock_sap.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 32)
    sock_sap.bind((s_my_ip_addr, 0))
    sap_sdp = header.tostring()+subheader+msg_ascii
    
    def send_sap():
        global run
        while run:
            sock_sap.sendto(sap_sdp, (MCAST_GRP, MCAST_PORT))
            time.sleep(1)
        
    def send_rtp():
        global run
        while run:        
            if rtp_q:
                #sock.sendto(rtp_packet, (ip, port))
                print(len(rtp_q))
                sock.sendto(rtp_q.popleft(), (ip, port))
                
    
    ip = '239.192.1.9'
    port = 5004
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((s_my_ip_addr, 0))

    rtp_sequence = 0
    line_num = 1
    frame_number = 0
    a = 0
    
    line = [i % 256 for i in xrange(Gor)]
    frame = []
    for i in xrange(Vert):
        frame.append(line)
        pix = line[0]
        line = line[1:]
        line.append(pix)
    
    for i in xrange(Vert):
        for n in xrange(8):
            frame[i].insert(0, 0)
    
#    th1 = threading.Thread(name='sap', target=send_sap)
#    th1.start()
#    th2 = threading.Thread(name='rtp', target=send_rtp)
#    th2.start()

    tstart = time.clock()
    while time.clock() < tstart + 1500:
        a = time.clock()    
        for ln in xrange(Vert):
            rtp_packet = bytearray()
            if line_num == Vert:
                last_line_in_frame = True
                c = 0x80
            else:
                last_line_in_frame = False
                c = 0x00
            
            payload_dat = bytearray(frame[(ln + frame_number) % Vert])
                    
            rtp_sequence_low16 = rtp_sequence & 0x0000ffff
            rtp_sequence_hi16 = (rtp_sequence & 0xffff0000) >> 16
            payload_dat[0] = (rtp_sequence_hi16 & 0xff00) >> 8    
            payload_dat[1] = rtp_sequence_hi16 & 0x00ff
            payload_dat[2] = (Gor & 0xff00) >> 8   #0x04 # 0x0400 = 1024 big-endian
            payload_dat[3] = Gor & 0x00ff
            payload_dat[4] = (line_num & 0x7f00) >> 8
            payload_dat[5] = (line_num & 0x00ff)
            payload_dat[6] = c
            payload_dat[7] = 0
            
            ts = int(frame_number * ts_mult)   #ts = int(time.clock() * 90000) & 0xffffffff
            rtp = RtpPacket.create(rtp_sequence_low16, last_line_in_frame, ts)
            rtp_packet = rtp_packet + rtp.header_bytes + payload_dat
            
            if last_line_in_frame:
                frame_number += 1
                line_num = 1
            else:
                line_num += 1
            rtp_sequence += 1
            rtp_q.append(rtp_packet)
            #if len(rtp_q) > 500000:
            #    time.sleep(1)
       # print(time.clock() - a)
    run = False
#    th1.join()
#    th2.join()


def opa():
    
    s_my_ip_addr = socket.gethostbyname(socket.gethostname())
    sock_opu = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock_opu.bind((s_my_ip_addr, 0))

    npak = 0        
    while 1:
        npak += 1
        print(npak)
        npak_h = (npak >> 8) & 0xFF
        npak_l = npak & 0xFF
        
        strt_1 = np.zeros((16,1), dtype = np.uint8)
        strt_1[0] = 0x00
        strt_1[1] = 0x10
        strt_1[2] = 0x10
        strt_1[3] = 0x03
        strt_1[4] = 0x01
        strt_1[5] = 0x01
        strt_1[6] = npak_h
        strt_1[7] = npak_l
        strt_1[8] = 0x01
        strt_1[9] = 0x01
        strt_1[10] = 0x13
        strt_1[11] = 0x8C
        strt_1[12] = 239
        strt_1[13] = 192
        strt_1[14] = 1
        strt_1[15] = 57
    
        strt_2 = np.zeros((16,1), dtype = np.uint8)
        strt_2[0] = 0x00
        strt_2[1] = 0x10
        strt_2[2] = 0x10
        strt_2[3] = 0x03
        strt_2[4] = 0x01
        strt_2[5] = 0x01
        strt_2[6] = npak_h
        strt_2[7] = npak_l
        strt_2[8] = 0x01
        strt_2[9] = 0x01
        strt_2[10] = 0x13
        strt_2[11] = 0x8C
        strt_2[12] = 239
        strt_2[13] = 192
        strt_2[14] = 3
        strt_2[15] = 49    
        
        if npak % 2 == 0:
            coma = strt_2.tostring()
        else:
            coma = strt_1.tostring()

#            coma = strt_1.tostring()
        
#            sock_opu.sendto(coma, ('192.168.208.17', 32820)) # PMF-T
#            sock_opu.sendto(coma, ('192.168.208.1', 32820)) # PMF-K
#            sock_opu.sendto(coma, ('192.168.208.5', 32820)) # PMF-N
#            sock_opu.sendto(coma, ('192.168.208.21', 32820)) # PMF-IUS-Vz1
#            sock_opu.sendto(coma, ('192.168.208.25', 32820)) # PMF-IUS-Vz2
        sock_opu.sendto(coma, ('192.168.208.29', 32820)) # PMF-D1
#            sock_opu.sendto(coma, ('192.168.208.33', 32820)) # PMF-D2
#            sock_opu.sendto(coma, ('192.168.208.93', 32820)) # PMF-Ispyt(D3)
#            sock_opu.sendto(coma, ('192.168.208.97', 32820)) # PMF-Ispyt(D4)
        time.sleep(2.8)





    
if __name__ == "__main__":
    opa() 
    
    
    
#def opa2():
#    
#    s_my_ip_addr = socket.gethostbyname(socket.gethostname())
#    sock_opu = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#    sock_opu.bind((s_my_ip_addr, 0))
#    
#    def send_opu():
#        npak = 0        
#        while 1:
#            npak += 1
#            print(npak)
#            npak_h = (npak >> 8) & 0xFF
#            npak_l = npak & 0xFF
#            
#            strt_1 = np.zeros((16,1), dtype = np.uint8)
#            strt_1[0] = 0x00
#            strt_1[1] = 0x10
#            strt_1[2] = 0x10
#            strt_1[3] = 0x03
#            strt_1[4] = 0x01
#            strt_1[5] = 0x01
#            strt_1[6] = npak_h
#            strt_1[7] = npak_l
#            strt_1[8] = 0x01
#            strt_1[9] = 0x01
#            strt_1[10] = 0x13
#            strt_1[11] = 0x8C
#            strt_1[12] = 239
#            strt_1[13] = 192
#            strt_1[14] = 1
#            strt_1[15] = 9
#        
#            strt_2 = np.zeros((16,1), dtype = np.uint8)
#            strt_2[0] = 0x00
#            strt_2[1] = 0x10
#            strt_2[2] = 0x10
#            strt_2[3] = 0x03
#            strt_2[4] = 0x01
#            strt_2[5] = 0x01
#            strt_2[6] = npak_h
#            strt_2[7] = npak_l
#            strt_2[8] = 0x01
#            strt_2[9] = 0x01
#            strt_2[10] = 0x13
#            strt_2[11] = 0x8C
#            strt_2[12] = 239
#            strt_2[13] = 192
#            strt_2[14] = 1
#            strt_2[15] = 10    
#            
#            strt_3 = np.zeros((16,1), dtype = np.uint8)
#            strt_3[0] = 0x00
#            strt_3[1] = 0x10
#            strt_3[2] = 0x10
#            strt_3[3] = 0x03
#            strt_3[4] = 0x01
#            strt_3[5] = 0x01
#            strt_3[6] = npak_h
#            strt_3[7] = npak_l
#            strt_3[8] = 0x01
#            strt_3[9] = 0x01
#            strt_3[10] = 0x13
#            strt_3[11] = 0x8C
#            strt_3[12] = 239
#            strt_3[13] = 192
#            strt_3[14] = 1
#            strt_3[15] = 11                
#            
##            if npak % 2 == 0:
##                coma = strt_2.tostring()
##            else:
##                if npak % 3 == 0:
##                    coma = strt_3.tostring()
##                else:
##                    coma = strt_1.tostring()
#
##            if npak % 2 == 0:
##                coma = strt_2.tostring()
##            else:
##                coma = strt_1.tostring()
#
#            coma = strt_1.tostring()
#            
#            sock_opu.sendto(coma, ('192.168.208.17', 32820)) # PMF-T
#            sock_opu.sendto(coma, ('192.168.208.1', 32820)) # PMF-K
#            sock_opu.sendto(coma, ('192.168.208.5', 32820)) # PMF-N
#            sock_opu.sendto(coma, ('192.168.208.21', 32820)) # PMF-IUS-Vz1
#            sock_opu.sendto(coma, ('192.168.208.25', 32820)) # PMF-IUS-Vz2
#            sock_opu.sendto(coma, ('192.168.208.29', 32820)) # PMF-D1
#            sock_opu.sendto(coma, ('192.168.208.33', 32820)) # PMF-D2
#            sock_opu.sendto(coma, ('192.168.208.93', 32820)) # PMF-Ispyt(D3)
#            sock_opu.sendto(coma, ('192.168.208.97', 32820)) # PMF-Ispyt(D4)
#            
    
#            time.sleep(1000)
#
#    th3 = threading.Thread(name='ou', target=send_opu)
#    th3.start()