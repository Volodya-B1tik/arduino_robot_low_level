# -*- coding: utf-8 -*-
"""
Created on Sun Mar 13 18:18:47 2016

@author: User
"""

from distutils.core import setup
import py2exe

setup(console=['test.py'])