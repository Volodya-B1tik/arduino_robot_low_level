# -*- coding: utf-8 -*-
from __future__ import division, print_function

from PyQt4 import QtCore, QtGui

import serial
import rs
import psh
import vga
import time
import logging
import sys
import getcomports
import graphics as gr
import collections as coll
import binascii
import threading
import gui
import random
from var import *

# цвета
cBlack = gr.color_rgb(0, 0, 0)
cGrey = gr.color_rgb(80, 80, 80)
cRed = gr.color_rgb(255, 0, 0)
cBlue = gr.color_rgb(0, 0, 255)
cWhite = gr.color_rgb(255, 255, 255)
cGreen = gr.color_rgb(0, 255, 0)
cYellow = gr.color_rgb(255, 255, 0)
cCian = gr.color_rgb(0, 255, 255)

rs232_coord_out_q = coll.deque()

run = True  # переменная для остановки потоков перед выходом

# очереди входных каналов для развязки потоков
mbx_232 = coll.deque()

def inq(ser, mbx):
    """ Качалка данных из входного буфера COM-порта в FIFO-канала.
    """
    while run:
        if ser.inWaiting() > 0:
            dat = ser.read(ser.inWaiting())
            chunk = coll.deque([int(binascii.hexlify(dat[i]), 16)
                                for i in xrange(len(dat))])
            while True:
                try:
                    mbx.append(chunk.popleft())
                except IndexError:
                    break

def inq_switch(mbx, channel):
    rx_cnt = 0
    packet_in_progress = False
    packet = coll.deque()
    while run:
        if mbx:
            rx_byte = mbx.popleft()
            if not packet_in_progress:
                if (rx_byte == 0xFF) or (rx_byte == 0xBF) or (rx_byte == 0xDF) or (rx_byte == 0x9F) :
                    rx_cnt = 1
                    packet.append(rx_byte)
                    packet_in_progress = True
            else:
                packet.append(rx_byte)
                rx_cnt += 1
                if rx_cnt == 10:
                    rs232_coord_out_q.append(packet)
                    rx_cnt = 0
                    packet_in_progress = False
                    packet = coll.deque()


def coord_q2(coord_out, lx1, ly1, lx2, ly2, lflag1, lflag2):
    if coord_out[0] == 0xBF:
        flag1 = 1
        flag2 = 0
    if coord_out[0] == 0x9F:
        flag1 = 1
        flag2 = 1
    if coord_out[0] == 0xFF:
        flag1 = 0
        flag2 = 0
    if coord_out[0] == 0xDF:
        flag1 = 0
        flag2 = 1

    y1h = coord_out[3]
    y1l = coord_out[4]
    x1h = coord_out[1]
    x1l = coord_out[2]

    y2h = coord_out[7]
    y2l = coord_out[8]
    x2h = coord_out[5]
    x2l = coord_out[6]

    x1 = (x1h << 7) + x1l
    x2 = (x2h << 7) + x2l
    y1 = (y1h << 7) + y1l
    y2 = (y2h << 7) + y2l
    if (lx1 == x1) and (ly1 == y1) and (lx2 == x2) and (ly2 == y2) and (lflag1 == flag1) and (lflag2 == flag2):
        pass
    else:
        print('f1 = %.5s, f2 = %.5s, x1,y1 = (%.5s, %.5s), x2,y2 = (%.5s, %.5s) ' % (flag1, flag2, x1, y1, x2, y2))
    return x1, y1, x2, y2, flag1, flag2

def coord_q(coord_out):
    if coord_out[0] == 0xBF:
        flag1 = 1
        flag2 = 0
    if coord_out[0] == 0x9F:
        flag1 = 1
        flag2 = 1
    if coord_out[0] == 0xFF:
        flag1 = 0
        flag2 = 0
    if coord_out[0] == 0xDF:
        flag1 = 0
        flag2 = 1

    y1h = coord_out[3]
    y1l = coord_out[4]
    x1h = coord_out[1]
    x1l = coord_out[2]

    y2h = coord_out[7]
    y2l = coord_out[8]
    x2h = coord_out[5]
    x2l = coord_out[6]

    x1 = (x1h << 7) + x1l
    x2 = (x2h << 7) + x2l
    y1 = (y1h << 7) + y1l
    y2 = (y2h << 7) + y2l
    print('f1 = %.5s, f2 = %.5s, x1,y1 = (%.5s, %.5s), x2,y2 = (%.5s, %.5s) ' % (flag1, flag2, x1, y1, x2, y2))
    return x1, y1, x2, y2, flag1, flag2


def coord_drawer_232():

    class CoordWindow:
        def __init__(self, width, height):
            self.dot1_pressed_color = gr.color_rgb(0, 0, 255)
            self.dot1_released_color = gr.color_rgb(255, 255, 255)
            self.dot2_pressed_color = gr.color_rgb(0, 255, 255)
            self.dot2_released_color = gr.color_rgb(255, 128, 128)
            self.rsdot_radius = 24
            self.window = gr.GraphWin("PMF-6.0 Touch Screen", width, height)
            self.window.setCoords(0, 767, 1023, 0)
            self.window.setBackground(cBlack)
            self.maxitems = 1
            self.dot1_pressed = False
            self.dot2_pressed = False

#            self.tt = gr.Text(gr.Point(511, 60), u'Проверка сенсорного '
#                                                 u'экрана №2')
#            self.tt.draw(self.window)
#            self.tt.setTextColor(cWhite)
#            self.tt.setSize(16)

#            brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
#            brdr.setOutline(cWhite)
#            brdr.draw(self.window)


        def dots_process(self, x1, y1, x2, y2, f1, f2):
            if f1 == 1:

                self.dot1_pressed = True
                self.draw_dot(x1, y1, self.dot1_pressed_color)
            else:
                if self.dot1_pressed is True:
                    self.draw_dot(x1, y1, self.dot1_released_color)
                    self.dot1_pressed = False
            if f2 == 1:
                self.dot2_pressed = True
                self.draw_dot(x2, y2, self.dot2_pressed_color)
            else:
                if self.dot2_pressed is True:
                    self.draw_dot(x2, y2, self.dot2_released_color)
                    self.dot2_pressed = False

        def draw_dot(self, x, y, color):
            y_mod = int(y * 0.75)
            rsdot = gr.Circle(gr.Point(x, y_mod), self.rsdot_radius)
            rsdot.setFill(color)
            rsdot.draw(self.window)
            if len(self.window.items[:]) > self.maxitems:
                self.delitem(0)

        def delitem(self, n):
            self.window.delItem(self.window.items[n])

        def close(self):
            self.window.close()

    w = CoordWindow(1024, 768)

    while 1:
        #QtCore.QCoreApplication.processEvents()
        if rs232_coord_out_q:
            pack = rs232_coord_out_q.popleft()
            x1, y1, x2, y2, f1, f2 = coord_q(pack)
            w.dots_process(x1, y1, x2, y2, f1, f2)

    w.close()


def coord_drawer():

    window = gr.GraphWin("PMF-6.0 Touch Screen", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    radius = 30
    window.setBackground(cBlack)

    brdr = gr.Rectangle(gr.Point(0, 0), gr.Point(1023, 767))
    brdr.setOutline(cWhite)
    brdr.draw(window)

    tt = gr.Text(gr.Point(511, 60), u'Проверка сенсорного экрана №1')
    tt.draw(window)
    tt.setTextColor(cWhite)
    tt.setSize(16)

    xi1, yi1 = 2000, 2000
    rsdot1 = gr.Circle(gr.Point(xi1, yi1), radius)
    rsdot1.setFill(rsdot_pressed_color)
    rsdot1.draw(window)

    xi2, yi2 = 2000, 2000
    rsdot2 = gr.Circle(gr.Point(xi2, yi2), radius)
    rsdot2.setFill(rsdot_pressed_color)
    rsdot2.draw(window)

    xi3, yi3 = 2000, 2000
    mdcdot1 = gr.Circle(gr.Point(xi3, yi3), radius)
    mdcdot1.setFill(mdcdot_pressed_color)
    mdcdot1.draw(window)

    xi4, yi4 = 2000, 2000
    mdcdot2 = gr.Circle(gr.Point(xi4, yi4), radius)
    mdcdot2.setFill(mdcdot_pressed_color)
    mdcdot2.draw(window)

    rsdot1_pressed = False
    rsdot2_pressed = False

    lx1, ly1, lx2, ly2, lflag1, lflag2 = 0, 0, 0, 0, 0, 0

    while test_stop is False and test_next is False:
        #QtCore.QCoreApplication.processEvents()

        if rs232_coord_out_q:
            x1, y1, x2, y2, f1, f2 = coord_q2(rs232_coord_out_q.popleft(), lx1, ly1, lx2, ly2, lflag1, lflag2)
            lx1, ly1, lx2, ly2, lflag1, lflag2 = x1, y1, x2, y2, f1, f2
            if f1 == 1:
                rsdot1.setFill(rsdot_pressed_color)
                y1_mod = int(y1 * 0.75)
                if (x1 != xi1) or (y1_mod != yi1):
                    rsdot1.move(x1 - xi1, y1_mod - yi1)
                    xi1 = x1
                    yi1 = y1_mod
                    rsdot1_pressed = True
            else:
                if rsdot1_pressed:
                    rsdot1.setFill(rsdot_released_color)
                    y1_mod = int(y1 * 0.75)
                    rsdot1.move(x1 - xi1, y1_mod - yi1)
                    xi1 = x1
                    yi1 = y1_mod
                    rsdot1_pressed = False
            if f2 == 1:
                rsdot2.setFill(rsdot_pressed_color)
                y2_mod = int(y2 * 0.75)
                rsdot2.move(x2 - xi2, y2_mod - yi2)
                xi2 = x2
                yi2 = y2_mod
                rsdot2_pressed = True
            else:
                if rsdot2_pressed:
                    rsdot2.setFill(rsdot_released_color)
                    y2_mod = int(y2 * 0.75)
                    rsdot2.move(x2 - xi2, y2_mod - yi2)
                    xi2 = x2
                    yi2 = y2_mod
                    rsdot2_pressed = False
    window.close()


def grid():

    window = gr.GraphWin("Grid", 1024, 768)
    window.setCoords(0, 767, 1023, 0)
    window.setBackground(cBlack)
    step = 32

    while 1:
        if rs232_coord_out_q:
            x1, y1, x2, y2, f1, f2 = coord_q(rs232_coord_out_q.popleft())
            if f1 == 0:
                y1 = int(y1 * 0.75)
                x0 = x1 - x1 % step
                y0 = y1 - y1 % step
                brdr = gr.Rectangle(gr.Point(x0, y0), gr.Point(x0 + step, y0 + step))
                brdr.setOutline(cRed)
                brdr.setFill(cWhite)
                brdr.draw(window)
            if f2 == 0 and x2 != 0 and y2 != 0:
                y2 = int(y2 * 0.75)
                x0 = x2 - x2 % step
                y0 = y2 - y2 % step
                brdr = gr.Rectangle(gr.Point(x0, y0), gr.Point(x0 + step, y0 + step))
                brdr.setOutline(cRed)
                brdr.setFill(cBlack)
                brdr.draw(window)

    window.close()


def main():
    global run
    try:
        print(chr(12))
        with serial.Serial('COM17', baudrate=115200) as ser:
            th1 = threading.Thread(name='th_rs232', target=inq, args=(ser, mbx_232))
            th2 = threading.Thread(name='th_sw', target=inq_switch, args=(mbx_232, '232'))
            th3 = threading.Thread(name='th_cd', target=coord_drawer_232,)
            th1.start()
            th2.start()
            th3.start()
            while 1:
                pass
            #coord_drawer_232()
            run = False

    except AssertionError as ae:
        print(u'Assertion: ', ae)
    except Exception as e:
        print(u'Что-то пошло не так: ', e)
    else:
        print(u'Сбоев в коде не было')
    finally:
        print(u'Это конец...',)
        return 0

if __name__ == "__main__":
    main()
