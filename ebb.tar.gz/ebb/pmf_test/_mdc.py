
# def rx_specific_packet(ser, rx_packets_count, packet_to_find = 'STS_OUT',
# timeout = 1):
#    if ser.isOpen():
#        t_start = time.clock()
#        infifo = []
#        packet_id = ''
#        hdr_ff1, hdr_ff2, packet_in_progress, is_packet_found = False,
# False, False, False
#        rx_data_byte_count = 0
#        while time.clock() < t_start + timeout:
#            while ser.inWaiting() > 0:
#                rx_byte = int(binascii.hexlify(ser.read(1)), 16)
#                if not packet_in_progress:
#                    if not hdr_ff1 and rx_byte == 0xff:
#                        hdr_ff1 = True
#                        rx_data_byte_count += 1
#                    elif hdr_ff1 and not hdr_ff2 and rx_byte == 0xff:
#                        hdr_ff2 = True
#                        rx_data_byte_count += 1
#                    elif hdr_ff1 and not hdr_ff2 and rx_byte != 0xff:
#                        hdr_ff1 = False
#                        rx_data_byte_count = 0
#                    elif hdr_ff1 and hdr_ff2:
#                        if rx_byte != 0xff:
#                            rx_data_byte_count += 1
#                            packet_id = decode_packet_id(rx_byte)
#                            if packet_id == packet_to_find:
#                                infifo.append(rx_byte)
#                                packet_in_progress = True
#                            else:
#                                hdr_ff1, hdr_ff2 = False, False
#                                rx_data_byte_count = 0
#                else:
#                    infifo.append(rx_byte)
#                    rx_data_byte_count += 1
#                    if rx_data_byte_count == packets_len[packet_id]:
#                        rx_packets_count += 1
#                        if packet_CS_check(infifo):
#                            is_packet_found = True
#                            infifo.insert(0, 0xFF) # вставляем 3 байта в
# начало списка
#                            infifo.insert(0, 0xFF) # чтобы индексы списка
# соответствовали
#                            infifo.insert(0, 0xFF) # номерам слов в
# протоколе ИЛВ
#                            return (is_packet_found, infifo, packet_id)
#        else:
#            return (is_packet_found, infifo, packet_id)
#    else:
#        log.error(u'Порт закрыт!')

# def rx_vitebsk_all(ser, timeout=1):
#     t_start = time.clock()
#     infifo = []
#     d = collections.deque(maxlen=20)
#     packet_id = ''
#     hdr_ff1, hdr_ff2, packet_in_progress, is_packet_found = False, False, \
#                                                             False, False
#     rx_data_byte_count = 0
#     while time.clock() < t_start + timeout:
#         if ser.inWaiting() > 0:
#             rx_byte = int(binascii.hexlify(ser.read(1)), 16)
#             if not packet_in_progress:
#                 if not hdr_ff1 and rx_byte == 0xff:
#                     hdr_ff1 = True
#                     rx_data_byte_count += 1
#                 elif hdr_ff1 and not hdr_ff2 and rx_byte == 0xff:
#                     hdr_ff2 = True
#                     rx_data_byte_count += 1
#                 elif hdr_ff1 and not hdr_ff2 and rx_byte != 0xff:
#                     hdr_ff1 = False
#                     rx_data_byte_count = 0
#                 elif hdr_ff1 and hdr_ff2:
#                     if rx_byte != 0xff:
#                         rx_data_byte_count += 1
#                         packet_id = decode_packet_id(rx_byte)
#                         if packet_id == packet_to_find:
#                             infifo.append(rx_byte)
#                             packet_in_progress = True
#                         else:
#                             hdr_ff1, hdr_ff2 = False, False
#                             rx_data_byte_count = 0
#             else:
#                 infifo.append(rx_byte)
#                 rx_data_byte_count += 1
#                 if rx_data_byte_count == packets_len[packet_id]:
#                     if packet_cs_check(infifo):
#                         is_packet_found = True
#                         infifo.insert(0,
#                                       0xFF)  # вставляем 3 байта в начало
#                         # списка
#                         infifo.insert(0,
#                                       0xFF)  # чтобы индексы списка
#                         # соответствовали
#                         infifo.insert(0, 0xFF)  # номерам слов в протоколе ИЛВ
#                         return (is_packet_found, infifo, packet_id)
#     return (is_packet_found, infifo, packet_id)


#
# ##TODO доделать обработку когда координаты не пришли за таймаут
# def RX_COORD_OUT(ser):
#     packet_resp_timeout = 10
#     is_packet_found, COORD_OUT, packet_id = rx_specific_packet(ser,
#                                                                rx_packets_count,
#                                                                'COORD_OUT',
#                                                                packet_resp_timeout)
#     if is_packet_found:
#         flag1 = COORD_OUT[4]
#         y1h = COORD_OUT[5]
#         y1l = COORD_OUT[6]
#         x1h = COORD_OUT[7]
#         x1l = COORD_OUT[8]
#
#         flag2 = COORD_OUT[9]
#         y2h = COORD_OUT[10]
#         y2l = COORD_OUT[11]
#         x2h = COORD_OUT[12]
#         x2l = COORD_OUT[13]
#
#         x1 = (x1h << 7) + x1l
#         x2 = (x2h << 7) + x2l
#         y1 = (y1h << 7) + y1l
#         y2 = (y2h << 7) + y2l
#
#         if flag1 == 255:
#             flag1 = 0
#         else:
#             flag1 = 1
#
#         if flag2 == 255:
#             flag2 = 0
#         else:
#             flag2 = 1
#
#             #  print '%.8s f1 = %.5s, f2 = %.5s, x1,y1 = (%.4s, %.4s), x2,
#             # y2 = (%.4s, %.4s) ' % (time.clock(), flag1, flag2, x1, y1, x2,
#             #  y2)
#         return x1, y1, x2, y2, flag1, flag2
#     else:
#         return 0, 0, 0, 0, 0, 0
#         # RX_COORD_OUT(ser)
#
#
# ###============================================================= new coord out
# ###FIXME переделана нумерация байт в пакете
# def RXQ(Q):
#     infifo = []
#     if len(Q) >= 14:
#         #   print len(Q)
#         for i in xrange(14):
#             infifo.append(Q.popleft())
#         return (True, infifo)
#     else:
#         return (False, infifo)





############333333333333333333333333333333333333333333333333333333333333333333
def rx_v(Q):
    infifo = []
    if len(Q) >= 10:
        print len(Q)
        for i in xrange(10):
            infifo.append(Q.popleft())
        return (True, infifo)
    else:
        return (False, infifo)


def mdc_coord(Q):
    is_packet_found, COORD_OUT = rx_v(Q)
    if is_packet_found:
        if (COORD_OUT[0] == 0xBF) or ((COORD_OUT[0] == 0x9F)):
            flag1 = 1
        else:
            flag1 = 0
        if (COORD_OUT[0] == 0xDF) or ((COORD_OUT[0] == 0x9F)):
            flag2 = 1
        else:
            flag2 = 0

        y1h = COORD_OUT[1]
        y1l = COORD_OUT[2]
        x1h = COORD_OUT[3]
        x1l = COORD_OUT[4]

        y2h = COORD_OUT[5]
        y2l = COORD_OUT[6]
        x2h = COORD_OUT[7]
        x2l = COORD_OUT[8]

        x1 = (y1h << 7) + y1l
        x2 = (y2h << 7) + y2l
        y1 = (x1h << 7) + x1l
        y2 = (x2h << 7) + x2l

        # print '%.8s f1 = %.5s, f2 = %.5s, x1,y1 = (%.4s, %.4s), x2,
        # y2 = (%.4s, %.4s) ' % (time.clock(), flag1, flag2, x1, y1, x2, y2)
        return x1, y1, x2, y2, flag1, flag2, is_packet_found
    else:
        return 0, 0, 0, 0, 0, 0, is_packet_found


##############################################################################


def rx_sp(ser, timeout=3):
    if ser.isOpen():
        infifo = []
        sw = ser.inWaiting()
        #    print 'rs ', sw
        if (sw >= 14):
            ififo = ser.read(sw - (sw % 14))
            while len(ififo) > 14:
                if int(binascii.hexlify(ififo[0]), 16) == 0xBF:
                    infifo = [int(binascii.hexlify(i), 16) for i in
                              ififo[0:15]]
                    return (True, infifo)
                else:
                    ififo = ififo[2:]
            else:
                infifo = [int(binascii.hexlify(i), 16) for i in ififo]
                return (True, infifo)
        else:
            return (False, infifo)
    else:
        log.error(u'Порт закрыт!')


def RX_COORD_OUT2(ser):
    packet_resp_timeout = 10
    is_packet_found, COORD_OUT = rx_sp(ser, packet_resp_timeout)
    if is_packet_found:
        flag1 = COORD_OUT[3]
        y1h = COORD_OUT[4]
        y1l = COORD_OUT[5]
        x1h = COORD_OUT[6]
        x1l = COORD_OUT[7]

        flag2 = COORD_OUT[8]
        y2h = COORD_OUT[9]
        y2l = COORD_OUT[10]
        x2h = COORD_OUT[11]
        x2l = COORD_OUT[12]

        x1 = (x1h << 7) + x1l
        x2 = (x2h << 7) + x2l
        y1 = (y1h << 7) + y1l
        y2 = (y2h << 7) + y2l

        if flag1 == 255:
            flag1 = 0
        else:
            flag1 = 1

        if flag2 == 255:
            flag2 = 0
        else:
            flag2 = 1

            #   print '%.8s f1 = %.5s, f2 = %.5s, x1,y1 = (%.4s, %.4s), x2,
            # y2 = (%.4s, %.4s) ' % (time.clock(), flag1, flag2, x1, y1, x2,
            #  y2)
        return x1, y1, x2, y2, flag1, flag2, is_packet_found
    else:
        return 0, 0, 0, 0, 0, 0, is_packet_found
        # RX_COORD_OUT(ser)


##=============================================================================
##VITEBSK
def rx_vitebsk(ser, timeout=3):
    if ser.isOpen():
        infifo = []
        sw = ser.inWaiting()
        # print 'mcd', sw
        if (sw >= 10):
            ififo = ser.read(sw - (sw % 10))
            while len(ififo) > 14:
                if int(binascii.hexlify(ififo[0]), 16) == 0xBF:
                    infifo = [int(binascii.hexlify(i), 16) for i in
                              ififo[0:11]]
                    return (True, infifo)
                else:
                    ififo = ififo[2:]
            else:
                infifo = [int(binascii.hexlify(i), 16) for i in ififo]
                return (True, infifo)
        else:
            return (False, infifo)
    else:
        log.error(u'Порт закрыт!')


def RX_VITEBSK_OUT(ser):
    is_packet_found, COORD_OUT = rx_vitebsk(ser, 10)
    if is_packet_found:
        if (COORD_OUT[0] == 0xBF) or ((COORD_OUT[0] == 0x9F)):
            flag1 = 1
        else:
            flag1 = 0
        if (COORD_OUT[0] == 0xDF) or ((COORD_OUT[0] == 0x9F)):
            flag2 = 1
        else:
            flag2 = 0

        y1h = COORD_OUT[1]
        y1l = COORD_OUT[2]
        x1h = COORD_OUT[3]
        x1l = COORD_OUT[4]

        y2h = COORD_OUT[5]
        y2l = COORD_OUT[6]
        x2h = COORD_OUT[7]
        x2l = COORD_OUT[8]

        x1 = (y1h << 7) + y1l
        x2 = (y2h << 7) + y2l
        y1 = (x1h << 7) + x1l
        y2 = (x2h << 7) + x2l

        #     print '%.8s f1 = %.5s, f2 = %.5s, x1,y1 = (%.4s, %.4s), x2,
        # y2 = (%.4s, %.4s) ' % (time.clock(), flag1, flag2, x1, y1, x2, y2)
        return x1, y1, x2, y2, flag1, flag2, is_packet_found
    else:
        return 0, 0, 0, 0, 0, 0, is_packet_found
        # RX_COORD_OUT(ser)