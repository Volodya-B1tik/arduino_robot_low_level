# -*- coding: utf-8 -*-
"""
Created on Mon Jul 25 16:42:25 2016

@author: gubatenko
"""

import serial
import rs

COM_RS232 = 'COM6'

ETH_BUFs_EN = 0x01
RGB_BUFs_EN = 0x01
MUX_ch0 = 0x00
MUX_ch1 = 0x04
MUX_ch2 = 0x00
MUX_ch3 = 0x00
SEL_DIL = 0x00
SC0_SizeXnew = 1024
SC1_SizeXnew = 640
SC2_SizeXnew = 64
SC3_SizeXnew = 64
SC0_SizeYnew = 768
SC1_SizeYnew = 480
SC2_SizeYnew = 64
SC3_SizeYnew = 64
W0_ENA = 1
W1_ENA = 1
W2_ENA = 0
W3_ENA = 0
W4_ENA = 0
W0_Xsrc = 0
W1_Xsrc = 0
W2_Xsrc = 0
W3_Xsrc = 0
W4_Xsrc = 0
W0_Ysrc = 0
W1_Ysrc = 0
W2_Ysrc = 0
W3_Ysrc = 0
W4_Ysrc = 0
W0_Xsize = 1024
W1_Xsize = 1024
W2_Xsize = 1024
W3_Xsize = 1024
W4_Xsize = 1024
W0_Ysize = 768
W1_Ysize = 768
W2_Ysize = 768
W3_Ysize = 768
W4_Ysize = 768
W0_Xdst = 0
W1_Xdst = 0
W2_Xdst = 0
W3_Xdst = 0
W4_Xdst = 0
W0_Ydst = 0
W1_Ydst = 0
W2_Ydst = 0
W3_Ydst = 0
W4_Ydst = 0
W0_order = 3
W1_order = 4
W2_order = 0
W3_order = 0
W4_order = 0



pipe = [ETH_BUFs_EN,
RGB_BUFs_EN,
MUX_ch0,
MUX_ch1,
MUX_ch2,
MUX_ch3,
SEL_DIL,
(SC0_SizeXnew % 0x007F),
(SC0_SizeXnew % 0x7F80) >> 7,
(SC1_SizeXnew % 0x007F),
(SC1_SizeXnew % 0x7F80) >> 7,
(SC2_SizeXnew % 0x007F),
(SC2_SizeXnew % 0x7F80) >> 7,
(SC3_SizeXnew % 0x007F),
(SC3_SizeXnew % 0x7F80) >> 7,
(SC0_SizeYnew % 0x007F),
(SC0_SizeYnew % 0x7F80) >> 7,
(SC1_SizeYnew % 0x007F),
(SC1_SizeYnew % 0x7F80) >> 7,
(SC2_SizeYnew % 0x007F),
(SC2_SizeYnew % 0x7F80) >> 7,
(SC3_SizeYnew % 0x007F),
(SC3_SizeYnew % 0x7F80) >> 7,
W0_ENA,
W1_ENA,
W2_ENA,
W3_ENA,
W4_ENA,
W0_Xsrc % 0x007F,
(W0_Xsrc % 0x7F80) >> 7,
W1_Xsrc % 0x007F,
(W1_Xsrc % 0x7F80) >> 7,
W2_Xsrc % 0x007F,
(W2_Xsrc % 0x7F80) >> 7,
W3_Xsrc % 0x007F,
(W3_Xsrc % 0x7F80) >> 7,
W4_Xsrc % 0x007F,
(W4_Xsrc % 0x7F80) >> 7,
W0_Ysrc % 0x007F,
(W0_Ysrc % 0x7F80) >> 7,
W1_Ysrc % 0x007F,
(W1_Ysrc % 0x7F80) >> 7,
W2_Ysrc % 0x007F,
(W2_Ysrc % 0x7F80) >> 7,
W3_Ysrc % 0x007F,
(W3_Ysrc % 0x7F80) >> 7,
W4_Ysrc % 0x007F,
(W4_Ysrc % 0x7F80) >> 7,
W0_Xsize % 0x007F,
(W0_Xsize % 0x7F80) >> 7,
W1_Xsize % 0x007F,
(W1_Xsize % 0x7F80) >> 7,
W2_Xsize % 0x007F,
(W2_Xsize % 0x7F80) >> 7,
W3_Xsize % 0x007F,
(W3_Xsize % 0x7F80) >> 7,
W4_Xsize % 0x007F,
(W4_Xsize % 0x7F80) >> 7,
W0_Ysize % 0x007F,
(W0_Ysize % 0x7F80) >> 7,
W1_Ysize % 0x007F,
(W1_Ysize % 0x7F80) >> 7,
W2_Ysize % 0x007F,
(W2_Ysize % 0x7F80) >> 7,
W3_Ysize % 0x007F,
(W3_Ysize % 0x7F80) >> 7,
W4_Ysize % 0x007F,
(W4_Ysize % 0x7F80) >> 7,
W0_Xdst % 0x007F,
(W0_Xdst % 0x7F80) >> 7,
W1_Xdst % 0x007F,
(W1_Xdst % 0x7F80) >> 7,
W2_Xdst % 0x007F,
(W2_Xdst % 0x7F80) >> 7,
W3_Xdst % 0x007F,
(W3_Xdst % 0x7F80) >> 7,
W4_Xdst % 0x007F,
(W4_Xdst % 0x7F80) >> 7,
W0_Ydst % 0x007F,
(W0_Ydst % 0x7F80) >> 7,
W1_Ydst % 0x007F,
(W1_Ydst % 0x7F80) >> 7,
W2_Ydst % 0x007F,
(W2_Ydst % 0x7F80) >> 7,
W3_Ydst % 0x007F,
(W3_Ydst % 0x7F80) >> 7,
W4_Ydst % 0x007F,
(W4_Ydst % 0x7F80) >> 7,
W0_order,
W1_order,
W2_order,
W3_order,
W4_order
]

with serial.Serial(COM_RS232, baudrate=9600) as ser:
    rs.set_mode(ser, u'расширенный')
    rs.set_vpipe(ser, pipe)
    
    